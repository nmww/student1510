package com.yanzheng.hujiang;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class NoticeRemindActivity extends Activity {
			ImageView iv;
			boolean isChanged = false;
			ImageButton btnBanck;
			Button btndpwnload;
			TextView szTime;
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.noticeremind);
				
				
				
				
				 
				
				btndpwnload=(Button) findViewById(R.id.dpwnload_way);
				btndpwnload.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent in=new Intent(NoticeRemindActivity.this,NoticeDpwnLoadWay.class);
						startActivity(in);
					}
				});
				iv=(ImageView) findViewById(R.id.iv_noticestudy);
				iv.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(v==iv){
							if(isChanged){
								iv.setImageDrawable(getResources().getDrawable(R.drawable.switch_off));
							}else{
								iv.setImageDrawable(getResources().getDrawable(R.drawable.switch_on));
							}
							 isChanged = !isChanged;
						}
						Toast.makeText(getApplication(), "�趨�ɹ�", 100).show();
					}
				});

				btnBanck=(ImageButton) findViewById(R.id.notice_banck);
				btnBanck.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent in=new Intent(NoticeRemindActivity.this,MyPageActivity.class);
						startActivity(in);
					}
				});
				
				szTime = (TextView) findViewById(R.id.tv_sztime);
				long time=System.currentTimeMillis();
				final Calendar mCalendar=Calendar.getInstance();
				mCalendar.setTimeInMillis(time);
				int mHour=mCalendar.get(Calendar.HOUR);
				int mMinuts=mCalendar.get(Calendar.MINUTE);
				szTime.setText(mHour+":"+mMinuts);
				
				szTime.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent in = new Intent(NoticeRemindActivity.this, TimePickerActivty.class);
//						startActivity(in);
						startActivityForResult(in, 1001);
					}
				});
			}
			
//			@Override
//			public void startActivityForResult(Intent intent, int requestCode,
//			Bundle options) {
//				Log.e("startActivityForResult", "requestCode  == "+requestCode);
//				
//				if(requestCode == 1001){
//					Log.e("requestCode", "requestCode  == "+requestCode);
//				}
//			}
			@Override
			protected void onActivityResult(int requestCode, int resultCode, Intent data) {
			// TODO Auto-generated method stub
				Log.e("startActivityForResult", "requestCode  == "+requestCode);
				if(requestCode == 1001){
					Log.e("requestCode", "requestCode  == "+requestCode);
					Log.e("requestCode", "Intent data  == "+data.getStringExtra("time"));
					Toast.makeText(NoticeRemindActivity.this, "�趨�ɹ���", Toast.LENGTH_SHORT).show();
					szTime.setText(data.getStringExtra("time"));
				}
			super.onActivityResult(requestCode, resultCode, data);
			}
}
