package com.yanzheng.hujiang;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class TabHostActivity extends ActivityGroup {
			public TabHost myTabHost;
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.tab_host);
				
				
				myTabHost=(TabHost) findViewById(R.id.th_host);
				myTabHost.setup();//����
				
				
				TabSpec tabSpec01=myTabHost.newTabSpec("��ǩ1");
				tabSpec01.setIndicator("�༶");
				
				Intent intent01=new Intent(this,ClassPageActivity.class);
				intent01.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				
				View view01=this.getLocalActivityManager().startActivity("1", intent01).getDecorView();
				LinearLayout layout01=(LinearLayout) findViewById(R.id.layout_class);
				layout01.removeAllViews();
				layout01.addView(view01);
				tabSpec01.setContent(R.id.layout_class);
				myTabHost.addTab(tabSpec01);
				
				
				TabSpec tabSpec02=myTabHost.newTabSpec("��ǩ2");
				tabSpec02.setIndicator("ѡ��");
				
				Intent intent02=new Intent(this,HomePageActivity.class);
				intent02.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				
				View view02=this.getLocalActivityManager().startActivity("2", intent02).getDecorView();
				LinearLayout layout02=(LinearLayout) findViewById(R.id.layout_home);
				layout02.removeAllViews();
				layout02.addView(view02);
				tabSpec02.setContent(R.id.layout_home);
				myTabHost.addTab(tabSpec02);
				
				
				TabSpec tabSpec03=myTabHost.newTabSpec("��ǩ3");
				tabSpec03.setIndicator("�ҵ�");
				
				Intent intent03=new Intent(this,MyPageActivity.class);
				intent03.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				
				View view03=this.getLocalActivityManager().startActivity("3", intent03).getDecorView();
				LinearLayout layout03=(LinearLayout) findViewById(R.id.layout_my);
				layout03.removeAllViews();
				layout03.addView(view03);
				tabSpec03.setContent(R.id.layout_my);
				myTabHost.addTab(tabSpec03);
				
				myTabHost.setCurrentTab(1);
			}
}
