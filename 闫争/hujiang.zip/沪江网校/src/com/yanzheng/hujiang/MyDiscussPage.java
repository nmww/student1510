package com.yanzheng.hujiang;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupExpandListener;

public class MyDiscussPage extends Activity {
	ExpandableListView expandLV;
	String []Groups={"��ϵ����"};
	String[][]Childs={{"�绰��ϵ����","������ϵ����","������ϵ����"}};
	MyExpandAdapter myExAdapter;
	Button myBtnBack;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.my_discuss);
		expandLV=(ExpandableListView) findViewById(R.id.expand_lv);
		
		myExAdapter=new MyExpandAdapter(this,Groups,Childs);
		
		expandLV.setAdapter(myExAdapter);
		for(int i=0;i<myExAdapter.getGroupCount();i++){
			expandLV.expandGroup(i);
		}
		expandLV.setOnChildClickListener(new OnChildClickListener() {
			
			@Override
			public boolean onChildClick(ExpandableListView parent, View v,
					int groupPosition, int childPosition, long id) {
				// TODO Auto-generated method stub
				switch (groupPosition) {
				case 0:
					
					switch (childPosition) {
					case 0:
						Intent intentPhone=new Intent();
						intentPhone.setAction(Intent.ACTION_DIAL);
						Uri uri=Uri.parse("tel:15303584669");
						intentPhone.setData(uri);
						startActivity(intentPhone);
						break;
                    case 1:
                    	sendSms(153035,"��Ҫ�²�");
						
						break;
                    case 2:
                    	Intent intent2=new Intent();
						Uri uriNet=Uri.parse("https://baidu.com");
						intent2.setData(uriNet);
						startActivity(intent2);
						break;		
					
					}
					break;

				
				}
				return false;
			}
		});
		expandLV.setOnGroupExpandListener(new OnGroupExpandListener() {
			
			@Override
			public void onGroupExpand(int groupPosition) {
				// TODO Auto-generated method stub
				
			}
		});
		expandLV.setOnGroupClickListener(new OnGroupClickListener() {
			
			public boolean onGroupClick(ExpandableListView parent, View v,
					int groupPosition, long id) {
				// TODO Auto-generated method stub
				return false;
			}
		});
		myBtnBack=(Button) findViewById(R.id.my_btn_back);
		myBtnBack.setOnClickListener(new OnClickListener() {
		
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(MyDiscussPage.this,MyPageActivity.class);
				startActivity(in);
			}
		});
	}
	private void sendSms(int phoneName,String message){
			Uri uriSms=Uri.parse("smsto:"+phoneName);
			Intent in=new Intent(Intent.ACTION_VIEW,uriSms);
			in.putExtra("sms_body", message);
			startActivity(in);
	}

}
