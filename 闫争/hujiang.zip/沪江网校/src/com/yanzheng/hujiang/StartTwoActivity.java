package com.yanzheng.hujiang;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.TextView;

public class StartTwoActivity extends Activity {
	Integer [] img=null;
	
	Gallery gallery;
	StartTwoAdapter stAdapter;
	TextView tvEntry;
	Button btnLogin;
	Button btnRegister;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_start_two);
		
		getData();
		
		gallery=(Gallery) findViewById(R.id.g_gallery);
		stAdapter=new StartTwoAdapter(this,img);
		gallery.setAdapter(stAdapter);
		
		
		btnLogin=(Button) findViewById(R.id.btn_logo);
		btnLogin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in1=new Intent(StartTwoActivity.this,LogoinActivity.class);
				startActivity(in1);
			}
		});
		btnRegister=(Button) findViewById(R.id.btn_register);
		btnRegister.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in2=new Intent(StartTwoActivity.this,RegisterActivity.class);
				startActivity(in2);
			}
		});
		
		tvEntry=(TextView) findViewById(R.id.tv_entry);
		tvEntry.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent in=new Intent(StartTwoActivity.this,TabHostActivity.class);
				startActivity(in);
			}
		});
	}
	private void getData() {
		// TODO Auto-generated method stub
		img=new Integer[]{R.drawable.pic_1,R.drawable.pic_2,R.drawable.pic_3};
	}
	
	

}
