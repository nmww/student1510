package com.yanzheng.hujiang;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyExpandAdapter extends BaseExpandableListAdapter {
	Context mContext;
	String [] GroupData=null;
	String [][] ChildData=null;
	public MyExpandAdapter(Context c,String[]group,String[][]child){
		mContext=c;
		GroupData=group;
		ChildData=child;
	}
	@Override
	public int getGroupCount() {
		// TODO Auto-generated method stub
		return GroupData.length;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		// TODO Auto-generated method stub
		return ChildData[groupPosition].length;
	}

	@Override
	public Object getGroup(int groupPosition) {
		// TODO Auto-generated method stub
		return GroupData[groupPosition];
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return ChildData[groupPosition][childPosition];
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return true;
	}
	class ViewHolder{
		ImageView ivLogo;
		TextView tvName;
	}
	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.my_discuss_group, null);
			vh.ivLogo=(ImageView) convertView.findViewById(R.id.mydiscuss_group_iv);
			vh.tvName=(TextView) convertView.findViewById(R.id.mydiscuss_group_tv);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		vh.ivLogo.setImageResource(R.drawable.icon_me_active);
		vh.tvName.setText(GroupData[groupPosition]);
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.my_discuss_child, null);
			vh.ivLogo=(ImageView) convertView.findViewById(R.id.mydiscuss_child_iv);
			vh.tvName=(TextView) convertView.findViewById(R.id.mydiscuss_child_tv);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder)convertView.getTag();
		}
		vh.ivLogo.setImageResource(R.drawable.bbs_iconpic_pressed);
		vh.tvName.setText(ChildData[groupPosition][childPosition]);
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return true;
	}

}
