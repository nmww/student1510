package com.yanzheng.hujiang;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

public class ClassPageActivity extends Activity {
	private static final String TAG="ClassPageActivity";
	private ViewPager view_pager;
	private List<ImageView> imgList;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.class_page);
		
		view_pager=(ViewPager) findViewById(R.id.class_view_page);
		view_pager.setOnPageChangeListener(new OnPageChangeListener() {
			
			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub
				
				if(arg0==3){
					Intent in=new Intent(ClassPageActivity.this,ClassSubjectActivity.class);
					startActivity(in);
				}
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		initData();
		view_pager.setAdapter(new MyViewPagerAdapter());
	}
	private void initData() {
		// TODO Auto-generated method stub
		imgList=new ArrayList<ImageView>();
		
		ImageView imageView1=new ImageView(getApplicationContext());
		imageView1.setBackgroundResource(R.drawable.guide_3);
		
		ImageView imageView2=new ImageView(getApplicationContext());
		imageView2.setBackgroundResource(R.drawable.guide_2);
		
		ImageView imageView3=new ImageView(getApplicationContext());
		imageView3.setBackgroundResource(R.drawable.guide_4);
		
		ImageView imageView4=new ImageView(getApplicationContext());
		imageView4.setBackgroundResource(R.drawable.guide_11);
		
		imgList.add(imageView1);
		imgList.add(imageView2);
		imgList.add(imageView3);
		imgList.add(imageView4);
	}
	
	class MyViewPagerAdapter extends PagerAdapter{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return imgList.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0==arg1;
		}
		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			// TODO Auto-generated method stub
			
			container.addView(imgList.get(position));
			return imgList.get(position);
		}
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			// TODO Auto-generated method stub
			 container.removeView((View)object);
		}
		
		
		
	}

}
