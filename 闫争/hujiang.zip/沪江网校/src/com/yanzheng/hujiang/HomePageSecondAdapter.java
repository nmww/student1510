package com.yanzheng.hujiang;

import java.util.ArrayList;
import java.util.Map;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class HomePageSecondAdapter extends BaseAdapter {
	Context mContext;
	ArrayList<Map<String,Object>> secondData;
	public HomePageSecondAdapter(Context c,ArrayList<Map<String,Object>> arrayL){
		mContext=c;
		secondData=arrayL;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return secondData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return secondData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class ViewHolder{
		ImageView iv;
		TextView tv;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=new ViewHolder();
		if(convertView==null){
			convertView=View.inflate(mContext, R.layout.home_page_second, null);
			vh.iv=(ImageView) convertView.findViewById(R.id.second_share_img);
			vh.tv=(TextView) convertView.findViewById(R.id.second_share_tv);
			convertView.setTag(vh);
			
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		vh.iv.setBackgroundResource((Integer) secondData.get(position).get("secondImg"));
		vh.tv.setText((CharSequence) secondData.get(position).get("secondtxt"));
		return convertView;
	}

}
