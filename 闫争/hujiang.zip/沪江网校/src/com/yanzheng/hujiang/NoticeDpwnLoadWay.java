package com.yanzheng.hujiang;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;

public class NoticeDpwnLoadWay extends Activity {
			ImageButton ibtn_way1,ibtn_way2,ibtn_way3;
			boolean isChanged = false;
			Button btnBanck;
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.noticedpwnloadway);
				
				btnBanck=(Button) findViewById(R.id.btn_banck_notice);
				btnBanck.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent in=new Intent(NoticeDpwnLoadWay.this,NoticeRemindActivity.class);
						startActivity(in);
					}
				});
				
				
				ibtn_way1=(ImageButton) findViewById(R.id.ibtn_way1);
				ibtn_way1.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(v==ibtn_way1){
							if(isChanged){
								ibtn_way1.setImageDrawable(getResources().getDrawable(R.drawable.icon_btn_checked));
							}else{
								ibtn_way1.setImageDrawable(getResources().getDrawable(R.drawable.icon_btn_unchecked));
							}
							 isChanged = !isChanged;
						}
					}
				});
				
				ibtn_way2=(ImageButton) findViewById(R.id.ibtn_way2);
				ibtn_way2.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(v==ibtn_way2){
							if(isChanged){
								ibtn_way2.setImageDrawable(getResources().getDrawable(R.drawable.icon_btn_checked));
							}else{
								ibtn_way2.setImageDrawable(getResources().getDrawable(R.drawable.icon_btn_unchecked));
							}
							 isChanged = !isChanged;
						}
					}
				});
				ibtn_way3=(ImageButton) findViewById(R.id.ibtn_way3);
				ibtn_way3.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(v==ibtn_way3){
							if(isChanged){
								ibtn_way3.setImageDrawable(getResources().getDrawable(R.drawable.icon_btn_checked));
							}else{
								ibtn_way3.setImageDrawable(getResources().getDrawable(R.drawable.icon_btn_unchecked));
							}
							 isChanged = !isChanged;
						}
					}
				});
				
			}
			
}
