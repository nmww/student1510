package com.yanzheng.hujiang;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;

public class TimePickerActivty extends Activity implements OnClickListener {

	Button queDing, quXiao;
	TimePicker timepicker ;
	String times, hour, minutes;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.time_picker);
		queDing = (Button) findViewById(R.id.btn_queding);
		quXiao = (Button) findViewById(R.id.btn_quxiao);
		queDing.setOnClickListener(this);
		quXiao.setOnClickListener(this);
		
		timepicker = (TimePicker) findViewById(R.id.timepicker);
	
		timepicker.setOnTimeChangedListener(new OnTimeChangedListener() {
			
			@Override
			public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
				// TODO Auto-generated method stub
				times = hourOfDay + ":"+minute;
				Log.e("onTimeChanged", "times " +times);
			}
		});
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btn_queding:
			Intent intent = new Intent();
			if(null == times){
				
				long time=System.currentTimeMillis();
				final Calendar mCalendar=Calendar.getInstance();
				mCalendar.setTimeInMillis(time);
				int mHour=mCalendar.get(Calendar.HOUR);
				int mMinuts=mCalendar.get(Calendar.MINUTE);

				times =mHour+":"+mMinuts;
			}else{
				times = times;
			}
			intent.putExtra("time", times);
//			startActivity(intent);
			setResult(1001, intent);
			finish();
			
			
			break;
		case R.id.btn_quxiao:
//			startActivity(new Intent(TimePickerActivty.this,
//					NoticeRemindActivity.class));
			break;

		default:
			break;
		}
	}
}
