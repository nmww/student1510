package com.yanzheng.hujiang;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

public class AboutMeActivity extends Activity {
			Button btnbanck;
			Button btnupdate;
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.about_me);
				
				btnbanck=(Button) findViewById(R.id.about_me_banck);
				btnbanck.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent in=new Intent(AboutMeActivity.this,MyPageActivity.class);
						startActivity(in);
					}
				});
				btnupdate=(Button) findViewById(R.id.about_me_renovate);
				btnupdate.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						AlertDialog.Builder alertdialogBuilder=new AlertDialog.Builder(AboutMeActivity.this);
						alertdialogBuilder.setIcon(R.drawable.guide_recommend_category_face);
						alertdialogBuilder.setTitle("���°汾");
						alertdialogBuilder.setMessage("��ȷ���Ƿ���и���");
						alertdialogBuilder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
							
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
								dialog.dismiss();
							}

							
						});
						alertdialogBuilder.setNeutralButton("����", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
								dialog.dismiss();
							}
						});
						alertdialogBuilder.setPositiveButton("����", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
								dialog.dismiss();
							}
						});
						alertdialogBuilder.create();
						alertdialogBuilder.show();
					}
				});
			}
}
