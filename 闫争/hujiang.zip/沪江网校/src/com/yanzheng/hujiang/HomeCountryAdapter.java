package com.yanzheng.hujiang;

import java.util.ArrayList;
import java.util.Map;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class HomeCountryAdapter extends BaseAdapter {
	Context mContext;
	ArrayList<Map<String,Object>> dataList;
	
	public HomeCountryAdapter(Context c,ArrayList<Map<String,Object>>data){
		mContext=c;
		dataList=data;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return dataList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return dataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	class ViewHolder{
		ImageView iv;
		TextView tv;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=new ViewHolder();
		if(convertView==null){
			convertView=View.inflate(mContext, R.layout.home_page_country, null);
			vh.iv=(ImageView) convertView.findViewById(R.id.country_share_img);
			vh.tv=(TextView) convertView.findViewById(R.id.country_share_tv);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		vh.iv.setBackgroundResource((Integer) dataList.get(position).get("img"));
		vh.tv.setText((CharSequence) dataList.get(position).get("txt"));
		return convertView;
	}

}
