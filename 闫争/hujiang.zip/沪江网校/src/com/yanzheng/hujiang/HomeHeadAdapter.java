package com.yanzheng.hujiang;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class HomeHeadAdapter extends BaseAdapter {
	Context mContext;
	Integer[]intData=null;
	public HomeHeadAdapter(Context c,Integer[]data){
		mContext=c;
		intData=data;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return intData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class ViewHolder{
		ImageView iv;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.home_head_img, null);
			vh.iv=(ImageView) convertView.findViewById(R.id.iv_img_head);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		vh.iv.setImageResource(intData[position]);
		return convertView;
	}

}
