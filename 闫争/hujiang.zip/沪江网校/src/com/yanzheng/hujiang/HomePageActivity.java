package com.yanzheng.hujiang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.GridView;

public class HomePageActivity extends Activity {
			Integer []img=null;
			Gallery gallery;
			GridView gvImg,secondImg;
			HomeCountryAdapter homeCountryAdapter;
			HomePageSecondAdapter homeSecondAdapter;
			ArrayList<Map<String,Object>> resData,secondData;
			HomeHeadAdapter hhAdapter;
			
			
			int position=0;
			 
			Handler handler=new Handler(){
				public void handleMessage(android.os.Message msg){
						switch(msg.arg1){
						case 0:
							if(position<img.length-1){
								position++;
							}else{
								position=0;
							}
							gallery.setSelection(position);
							break;
						}
				}
			};
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.home_page);
				
				
				
				
				gvImg=(GridView) findViewById(R.id.country_gv_view);
				getRes();
				homeCountryAdapter=new HomeCountryAdapter(HomePageActivity.this, resData);
				gvImg.setAdapter(homeCountryAdapter);
				
				secondImg=(GridView) findViewById(R.id.second_gv_view);
				getSecondRes();
				homeSecondAdapter=new HomePageSecondAdapter(HomePageActivity.this, secondData);
				secondImg.setAdapter(homeSecondAdapter);
				
				
				
				getData();
				gallery=(Gallery) findViewById(R.id.head_gallery);
				hhAdapter=new HomeHeadAdapter(this,img);
				gallery.setAdapter(hhAdapter);
				
				Timer timer=new Timer();
				TimerTask tt=new TimerTask(){

					@Override
					public void run() {
						// TODO Auto-generated method stub
						Message msg=new Message();
						msg.arg1=0;
						handler.sendMessage(msg);
					}
					
				};
				timer.scheduleAtFixedRate(tt, 2000, 2000);
			}
			private void getSecondRes() {
				// TODO Auto-generated method stub
				secondData=new ArrayList<Map<String,Object>>();
				for(int i=0;i<9;i++){
					Map m2=new HashMap<String,Object>();
					if(i==0){
						m2.put("secondImg", R.drawable.course_classck);
						m2.put("secondtxt", "����");
					}else if(i==1){
						m2.put("secondImg", R.drawable.course_classlx);
						m2.put("secondtxt", "��ѧ");
					}else if(i==2){
						m2.put("secondImg", R.drawable.course_classother);
						m2.put("secondtxt", "����");
					}else if(i==3){
						m2.put("secondImg", R.drawable.course_classk12);
						m2.put("secondtxt", "����");
					}else if(i==4){
						m2.put("secondImg", R.drawable.course_classen);
						m2.put("secondtxt", "Ӣ��");
					}else if(i==5){
						m2.put("secondImg", R.drawable.course_classjp);
						m2.put("secondtxt", "����");
					}else if(i==6){
						m2.put("secondImg", R.drawable.course_classkr);
						m2.put("secondtxt", "����");
					}else if(i==7){
						m2.put("secondImg", R.drawable.course_classfr);
						m2.put("secondtxt", "����");
					}else if(i==8){
						m2.put("secondImg", R.drawable.course_classzc);
						m2.put("secondtxt", "��ѧ");
					}
					secondData.add(m2);
				}
			}
			private void getRes() {
				// TODO Auto-generated method stub
				resData=new ArrayList<Map<String,Object>>();
				for(int i=0;i<16;i++){
					Map m=new HashMap<String,Object>();
					if(i==0){
						m.put("img", R.drawable.country_7);
						m.put("txt", "�й�");
					}else if(i==1){
						m.put("img", R.drawable.country_6);
						m.put("txt", "��������");
					}else if(i==2){
						m.put("img", R.drawable.country_5);
						m.put("txt", "����");
					}else if(i==3){
						m.put("img", R.drawable.country_4);
						m.put("txt", "Խ��");
					}else if(i==4){
						m.put("img", R.drawable.country_3);
						m.put("txt", "Ҳ��");
					}else if(i==5){
						m.put("img", R.drawable.country_2);
						m.put("txt", "̩��");
					}else if(i==6){
						m.put("img", R.drawable.country_1);
						m.put("txt", "Ħ�ɸ�");
					}else if(i==7){
						m.put("img", R.drawable.country_8);
						m.put("txt", "�ϼ���");
					}else if(i==8){
						m.put("img", R.drawable.country_9);
						m.put("txt", "�ձ�");
					}else if(i==9){
						m.put("img", R.drawable.country_10);
						m.put("txt", "���ȱ��");
					}else if(i==10){
						m.put("img", R.drawable.country_11);
						m.put("txt", "����կ");
					}else if(i==11){
						m.put("img", R.drawable.country_12);
						m.put("txt", "������");
					}else if(i==12){
						m.put("img", R.drawable.country_13);
						m.put("txt", "����");
					}else if(i==13){
						m.put("img", R.drawable.country_14);
						m.put("txt", "����");
					}else if(i==14){
						m.put("img", R.drawable.country_15);
						m.put("txt", "������");
					}else if(i==15){
						m.put("img", R.drawable.country_16);
						m.put("txt", "�����");
					}
					resData.add(m);
				}
			}
			private void getData() {
				// TODO Auto-generated method stub
				img=new Integer[]{R.drawable.home2,R.drawable.home4,R.drawable.home3,R.drawable.home1,R.drawable.home5};
			}
}
