package com.yanzheng.hujiang;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

public class LogoinActivity extends Activity {
		Button btnClose;
		Button btnRe;
		Button tvLogoin;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			setContentView(R.layout.login);
			
			btnClose=(Button) findViewById(R.id.btn_close);
			btnClose.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent in=new Intent(LogoinActivity.this,StartTwoActivity.class);
					startActivity(in);
				}
			});
			
			btnRe=(Button) findViewById(R.id.btn_re);
			btnRe.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent in=new Intent(LogoinActivity.this,RegisterActivity.class);
					startActivity(in);
				}
			});
			tvLogoin=(Button) findViewById(R.id.tv_logoin);
			tvLogoin.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent in=new Intent(LogoinActivity.this,TabHostActivity.class);
					startActivity(in);
				}
			});
		}
}
