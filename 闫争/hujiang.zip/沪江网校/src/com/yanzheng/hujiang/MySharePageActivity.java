package com.yanzheng.hujiang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.GridView;

public class MySharePageActivity extends Activity {
		Button btnCancle;
	     GridView gvImg;
	     MyShareAdapter myShareAdapter;
	     ArrayList<Map<String,Object>> resData;
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.my_share);
				
				gvImg=(GridView) findViewById(R.id.my_gv_view);
				getRes();
				myShareAdapter=new MyShareAdapter(MySharePageActivity.this, resData);
				gvImg.setAdapter(myShareAdapter);
				
				btnCancle=(Button) findViewById(R.id.my_share_canle);
				btnCancle.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent in=new Intent(MySharePageActivity.this,MyPageActivity.class);
						startActivity(in);
					}
				});
			}
			private void getRes() {
				// TODO Auto-generated method stub
				resData=new ArrayList<Map<String,Object>>();
				for(int i=0;i<5;i++){
					Map m=new HashMap<String,Object>();
					if(i==0){
						m.put("img", R.drawable.btn_share_qq_normal);
						m.put("txt", "QQ");
					}else if(i==1){
						m.put("img", R.drawable.btn_share_qzone_normal);
						m.put("txt", "QQ�ռ�");
					}else if(i==2){
						m.put("img", R.drawable.btn_share_pyq_normal);
						m.put("txt", "����Ȧ");
					}else if(i==3){
						m.put("img", R.drawable.btn_share_wechat_normal);
						m.put("txt", "΢��");
					}else if(i==4){
						m.put("img", R.drawable.btn_share_sina_normal);
						m.put("txt", "΢��");
					}
					resData.add(m);
				}
			}
}
