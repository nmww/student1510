package com.yanzheng.hujiang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;







import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class MyPageActivity extends Activity implements OnClickListener{
		ListView lvList;
		MyPageAdapter myPageAdapter;
		ArrayList<Map<String,Object>> resData;
		Button myBtnBack,myMenu;
		PopupWindow popupWind;
		TextView tvOpen;
		TextView tvSave;
		TextView tvClose;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			setContentView(R.layout.my_page);
			
			initView();
			initPopuWin();
			
			
			myBtnBack=(Button) findViewById(R.id.btn_my_back);
			myBtnBack.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent in=new Intent(MyPageActivity.this,TabHostActivity.class);
					startActivity(in);
				}
			});
				
			lvList=(ListView) findViewById(R.id.my_lv_list);
			lvList.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					// TODO Auto-generated method stub
					switch (position) {
					case 0:
						Intent in=new Intent(MyPageActivity.this,MyDiscussPage.class);
						startActivity(in);
						break;
                    case 1:
						Intent in1=new Intent(MyPageActivity.this,MyFavourableComment.class);
						startActivity(in1);
						break;
                    case 2:
                    	Intent in2=new Intent(MyPageActivity.this,MySharePageActivity.class);
        				startActivity(in2);
						break;

                    case 3:
                    	Intent in3=new Intent(MyPageActivity.this,NoticeRemindActivity.class);
                    	startActivity(in3);
                    	break;
                    case 4:
                    	Intent in4=new Intent(MyPageActivity.this,AboutMeActivity.class);
                    	startActivity(in4);
                    	break;
					}
				}
			});
			getRes();
			myPageAdapter=new MyPageAdapter(MyPageActivity.this,resData);
			lvList.setAdapter(myPageAdapter);
			
			
		}

		private void getPopuView() {
			// TODO Auto-generated method stub
			View Pview=View.inflate(getApplication(), R.layout.my_page_menu, null);
			tvOpen=(TextView) Pview.findViewById(R.id.tv_open);
			tvOpen.setOnClickListener(this);
			tvSave=(TextView) Pview.findViewById(R.id.tv_save);
			tvSave.setOnClickListener(this);
			tvClose=(TextView) Pview.findViewById(R.id.tv_close);
			tvClose.setOnClickListener(this);
			
			popupWind=new PopupWindow(Pview,100,300);
			popupWind.setFocusable(true);
			popupWind.setBackgroundDrawable(new BitmapDrawable());
			popupWind.setOutsideTouchable(true);
		}

		private void initPopuWin() {
			// TODO Auto-generated method stub
			if(popupWind==null){
				getPopuView();
			}else{
				popupWind.dismiss();
			}
		}

		private void initView() {
			// TODO Auto-generated method stub
			myMenu=(Button) findViewById(R.id.btn_my_set);
			myMenu.setOnClickListener(this);
		}

		private void getRes() {
			// TODO Auto-generated method stub
			resData=new ArrayList<Map<String,Object>>();
			
			for(int i=0;i<5;i++){
				Map m=new HashMap<String,Object>();
			if(i==0){	
			m.put("img",R.drawable.icon_mypost );
			m.put("txt", "��Ҫ�²�");
			}else if(i==1){
			m.put("img", R.drawable.icon_moon);
			m.put("txt", "��������");
			}else if(i==2){
			m.put("img", R.drawable.icon_findmore);
			m.put("txt", "�������Ƽ�");
			}else if(i==3){
			m.put("img", R.drawable.icon_screen_active);
			m.put("txt", "����֪ͨ");
			}else if(i==4){
			m.put("img", R.drawable.icon_hot_active);
			m.put("txt", "��������");
			}
			resData.add(m);
			}
			
		}

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.btn_my_set:
				popupWind.showAsDropDown(v);
				break;
			case R.id.tv_open:
				
				popupWind.dismiss();
				break;
			case R.id.tv_save:
				Intent in=new Intent(MyPageActivity.this,MySharePageActivity.class);
				startActivity(in);
				popupWind.dismiss();
				break;
				
			case R.id.tv_close:
				
				popupWind.dismiss();
				break;	
			}
		}
}
