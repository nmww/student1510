package com.yanzheng.hujiang;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class ClassSubjectActivity extends Activity {
			Spinner spString;
			ArrayAdapter<String> arrayAdapter;
			ArrayList<String> strResources;
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.class_subject);
				getResStr();
				spString=(Spinner) findViewById(R.id.sp_array);
				arrayAdapter=new ArrayAdapter<String>(getApplicationContext(), R.layout.class_subject_child, strResources);
				spString.setAdapter(arrayAdapter);
				
				spString.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> parent,
							View view, int position, long id) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onNothingSelected(AdapterView<?> parent) {
						// TODO Auto-generated method stub
						
					}
				});
			}
			private void getResStr() {
				// TODO Auto-generated method stub
				strResources=new ArrayList<String>();
				strResources.add("Ӣ��");
				strResources.add("����");
				strResources.add("����");
			}
}
