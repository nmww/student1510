package com.yanzheng.hujiang;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;

public class MyFavourableComment extends Activity {
	ProgressDialog progressdialog;
	PopupWindow popupWindow;
	RatingBar rtBarFalse;
	TextView tvComment;
	TextView tvCommentThank;
	Button btn_popu;
	Button btn_back;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		progressdialog=ProgressDialog.show(this, "��ӭ��������", "���ڽ���...");
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				progressdialog.hide();
			}
		},2000);
		setContentView(R.layout.my_favourable_comment);

		initView();
		initPopwindow();
		btn_back=(Button) findViewById(R.id.my_comment_banck);
		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(MyFavourableComment.this,MyPageActivity.class);
				startActivity(in);
				
			}
		});
		tvComment=(TextView) findViewById(R.id.my_comment_text);
		rtBarFalse=(RatingBar) findViewById(R.id.my_rb_false);
		rtBarFalse.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {

			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating,
					boolean fromUser) {
				// TODO Auto-generated method stub
				switch ((int)rating) {
				case 1:
					tvComment.setText("����������:");
					tvComment.setTextColor(Color.RED);
					break;
				case 2:
					tvComment.setText("����������:һ��");
					tvComment.setTextColor(Color.RED);
					break;
				case 3:
					tvComment.setText("����������:����");
					tvComment.setTextColor(Color.RED);
					break;
				case 4:
					tvComment.setText("����������:����");
					tvComment.setTextColor(Color.RED);
					break;	
				case 5:
					tvComment.setText("����������:�ǳ�����");
					tvComment.setTextColor(Color.RED);
					break;

				}
			}
		});
	}
	private void initPopwindow() {
		// TODO Auto-generated method stub
		if(popupWindow==null){
			getPopuw();
		}else{
			popupWindow.dismiss();
		}
	}
	private void getPopuw() {
		// TODO Auto-generated method stub
		View pView=View.inflate(getApplication(), R.layout.my_comment_thank, null);
		tvCommentThank=(TextView) pView.findViewById(R.id.my_comment_thank);
		
		popupWindow=new PopupWindow(pView,350,260);

	}
	private void initView() {
		// TODO Auto-generated method stub
		btn_popu=(Button) findViewById(R.id.my_comment_popupwindow);
		btn_popu.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);
				
			}
		});
	}
}
