package com.example.mybabyapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;

import com.example.mybabyapp.adapter.XSAdapter;

public class XianShiActivity extends Activity {
	ListView lvList;
	ArrayList<Map<String, Object>> resData;
	XSAdapter xsAdapter;
	Button btnfh;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xian_shi_layout);
		lvList = (ListView) findViewById(R.id._lv_xs_list);
		getRes();
		xsAdapter = new XSAdapter(XianShiActivity.this, resData);
        lvList.setAdapter(xsAdapter);
        lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				Intent intent1 = new Intent(XianShiActivity.this,ShangPinActivity.class);
            	Bundle bundle1 = new Bundle();
            	Map map = resData.get(position);
        		bundle1.putString("name", (String) map.get("txt"));
        		bundle1.putInt("img", (Integer) map.get("img"));
        		bundle1.putString("qian", (String) map.get("txq"));
        		intent1.putExtras(bundle1);
            	startActivity(intent1);
				// TODO Auto-generated method stub
            	
			}
		});
        
        
        
        
        btnfh = (Button) findViewById(R.id.btn_xs_fh);
		btnfh.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(XianShiActivity.this,MainActivity.class);
				startActivity(intent);
			}
		});
	}
	private void getRes() {
		// TODO Auto-generated method stub
		resData = new ArrayList<Map<String,Object>>();
    	Map m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_1);
		m.put("txt", "����ʿӤ�׶��������60��*2");
		m.put("txq","��99.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_2);
		m.put("txt", "�׶�����װ������пάD�Ƴ����");
		m.put("txq","��59.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_3);
		m.put("txt", "������ء�ĸ����Ȼ����棨36Ƭ��");
		m.put("txq","��239.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_4);
		m.put("txt", "С������ƿ������HL��0982");
		m.put("txq","��59.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_5);
		m.put("txt", "�°�����ʿ��װPES��ƿ��125ML��");
		m.put("txq","��139.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_6);
		m.put("txt", "�ظ��һ��ˮ���裨ˮ��������");
		m.put("txq","��59.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_7);
		m.put("txt", "ʩ��Ӥ������¶500ml");
		m.put("txq","��99.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_8);
		m.put("txt", "�����ˮʵ��������ļ��ף��������䣩");
		m.put("txq","��39.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_9);
		m.put("txt", "С������ͷ�������¼�GH312");
		m.put("txq","��89.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_10);
		m.put("txt", "���˫��˫��ζC����Ƭ3ֻװ");
		m.put("txq","��59.00");
		resData.add(m);
	}
}
