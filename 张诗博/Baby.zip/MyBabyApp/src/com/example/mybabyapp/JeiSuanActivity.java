package com.example.mybabyapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class JeiSuanActivity extends Activity {
	Button btnjixu;
	Button btnchakan;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.jei_suan_layout);
		btnjixu = (Button) findViewById(R.id.btn_js_ji_su_gou_wu);
		btnjixu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(JeiSuanActivity.this,MainActivity.class);
				startActivity(intent);
			}
		});
		btnchakan = (Button) findViewById(R.id.btn_js_cha_kan_ding_dan);
		btnchakan.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent1=new Intent(JeiSuanActivity.this,DingDanActivity.class);
				startActivity(intent1);
			}
		});
	}
}
