package com.example.mybabyapp;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class PagerActivity extends Activity {
	public static final String TAG="log";
	private ViewPager view_pager;
	private List<ImageView> imgList;
	private int pagescrolled ;
	private float pagescrolled1 ;
	private int pagescrolled2 ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.pages_layout);
		
		view_pager = (ViewPager) findViewById(R.id.view_pager);
		
		//��ʼ������
		initData();
		
		//viewpager����һ������������
		view_pager.setAdapter(new MyPagerAdapter());
		view_pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			
			@Override
			public void onPageSelected(int arg0) {
				Log.e(TAG, "onPageSelected==="+arg0);
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				Log.e(TAG, "onPageScrolled==="+arg0);
				Log.e(TAG, "onPageScrolled==="+arg1);
				Log.e(TAG, "onPageScrolled==="+arg2);
				 pagescrolled = arg0;
				 pagescrolled1 = arg1;
				 pagescrolled2 = arg2;
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub
				Log.e(TAG, "onPageScrollStateChanged==="+arg0);
				if(pagescrolled==2&&pagescrolled1==0.0&&pagescrolled2==0&&arg0==0){
					GoToMainActivity(); 
				}
				
			}

			private void GoToMainActivity() {
				// TODO Auto-generated method stub
				Intent intent = new Intent(PagerActivity.this, MainActivity.class); 
				startActivity(intent); 
				
			}	
			});
	


	}
	private void initData() {
		imgList = new ArrayList<ImageView>();
		
		ImageView imageView1 = new ImageView(getApplicationContext());
		imageView1.setBackgroundResource(R.drawable.guide_1);
		
		ImageView imageView2 = new ImageView(getApplicationContext());
		imageView2.setBackgroundResource(R.drawable.guide_2);
		
		ImageView imageView3 = new ImageView(getApplicationContext());
		imageView3.setBackgroundResource(R.drawable.welcome);
		
		imgList.add(imageView1);
		imgList.add(imageView2);
		imgList.add(imageView3);
	}
	
	class MyPagerAdapter extends PagerAdapter{
		@Override
		public int getCount() {
			return imgList.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
		
		//��viewpager����һ����Ŀ�Ĳ���
		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			
			container.addView(imgList.get(position));
			return imgList.get(position);
		}
		
		//��viewpagerɾ��һ����Ŀ����
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View)object);
		}
	}
}


