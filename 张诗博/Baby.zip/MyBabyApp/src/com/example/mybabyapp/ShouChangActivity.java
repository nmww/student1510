package com.example.mybabyapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.example.mybabyapp.adapter.SCAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class ShouChangActivity extends Activity {
	ListView lvList;
	ArrayList<Map<String, Object>> resData;
	SCAdapter scAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shou_cang_layout);
		lvList = (ListView) findViewById(R.id.lv_sc_list);
		getRes();
		scAdapter = new SCAdapter(ShouChangActivity.this, resData);
        lvList.setAdapter(scAdapter);
	}
	private void getRes() {
		//��������
		resData = new ArrayList<Map<String,Object>>();
    	Map m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_1);
		m.put("txt", "С������ƿ������HL-0982");
		m.put("txq","��99.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_2);
		m.put("txt", "���˫��ζC����Ƭ3ֻװ");
		m.put("txq","��59.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_3);
		m.put("txt", "�ظ��һ��ˮ���裨ˮ��������");
		m.put("txq","��239.00");
		resData.add(m);
	}
}
