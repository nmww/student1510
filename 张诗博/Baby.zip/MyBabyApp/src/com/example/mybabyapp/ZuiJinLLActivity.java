package com.example.mybabyapp;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mybabyapp.adapter.ZJAdapter;

public class ZuiJinLLActivity extends Activity {
	ListView lvList;
	ArrayList<Map<String, Object>> resData;
	ZJAdapter zjAdapter;
	Button btnfh;
	Button btnqk;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zui_jin_layout);
		lvList = (ListView) findViewById(R.id._lv_zj_list);
		getRes();
		zjAdapter = new ZJAdapter(ZuiJinLLActivity.this, resData);
        lvList.setAdapter(zjAdapter);
        btnfh = (Button) findViewById(R.id.btn_zj_fh);
		btnfh.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(ZuiJinLLActivity.this,GenDuoActivity.class);
				startActivity(intent);
			}
		});
		btnqk = (Button) findViewById(R.id.btn_zj_qk);
		btnqk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(ZuiJinLLActivity.this, "������", 100)
				.show();
			}
		});
			
	}
	private void getRes() {
		// TODO Auto-generated method stub
		resData = new ArrayList<Map<String,Object>>();
    	Map m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_1);
		m.put("txt", "С������ƿ������HL-0982");
		m.put("txq","��99.00");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.limit_2);
		m.put("txt", "���˫��ζC����Ƭ3ֻװ");
		m.put("txq","��59.00");
		resData.add(m);
	}
}
