package com.example.mybabyapp;

import java.util.Calendar;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class GuanYuActivity extends Activity {
	 private TextView text;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.guan_yu_layout);
		Calendar c=Calendar.getInstance();

		String time=c.get(Calendar.YEAR)+"-"+ //�õ���
		formatTime(c.get(Calendar.MONTH)+1)+"-"+//month��һ //��
		formatTime(c.get(Calendar.DAY_OF_MONTH))+" "+ //��
		formatTime(c.get(Calendar.HOUR_OF_DAY)+8)+":"+ //ʱ
		formatTime(c.get(Calendar.MINUTE))+":"+ //��
		formatTime(c.get(Calendar.SECOND)); //��
		text = (TextView) findViewById(R.id.tv_gu_shi_jian);
		text.setText("ʱ�䣺 "+time);
	}

	private String formatTime(int t) {
		// TODO Auto-generated method stub
		return t>=10? ""+t:"0"+t;//��Ԫ����� t>10ʱȡ ""+t
	}
}
