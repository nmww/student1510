package com.example.mybabyapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.example.mybabyapp.adapter.GDAdapter;

public class GenDuoActivity extends Activity {
	ListView lvList;
	ArrayList<Map<String, Object>> resData;
	GDAdapter gdAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gen_duo_layout);
		lvList = (ListView) findViewById(R.id._lv_list_gd);
		getRes();
        gdAdapter = new GDAdapter(GenDuoActivity.this, resData);
        lvList.setAdapter(gdAdapter);
        lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// 
				if(position==0){
                	Intent intent = new Intent(GenDuoActivity.this,DengLvActivity.class);
                	startActivity(intent);
                }
                if(position==1){
                Intent intent = new Intent(GenDuoActivity.this,DingDanActivity.class);
                startActivity(intent);
             }
                if(position==2){
                Intent intent = new Intent(GenDuoActivity.this,DengLvActivity.class);
                startActivity(intent);
            }
                if(position==3){
                    Intent intent = new Intent(GenDuoActivity.this,ShouChangActivity.class);
                    startActivity(intent);
                }
                if(position==4){
                    Intent intent = new Intent(GenDuoActivity.this,ZuiJinLLActivity.class);
                    startActivity(intent);
                }
                if(position==5){
                    Intent intent = new Intent(GenDuoActivity.this,GuanYuActivity.class);
                    startActivity(intent);
                }
                if(position==6){
                    Intent intent = new Intent(GenDuoActivity.this,GuanYuActivity.class);
                    startActivity(intent);
                }
			}
		});
	}
	private void getRes() {
		// TODO Auto-generated method stub
		resData = new ArrayList<Map<String,Object>>();
    	Map m = new HashMap<String, Object>();
		m.put("txt", "�ҵ��˻�");
		m.put("img", R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "�ҵĶ���");
		m.put("img", R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "��ַ����");
		m.put("img", R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "�ղؼ�");
		m.put("img", R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "������");
		m.put("img", R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "��������");
		m.put("img", R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "����");
		m.put("img", R.drawable.arrow);
		resData.add(m);
	}
}
