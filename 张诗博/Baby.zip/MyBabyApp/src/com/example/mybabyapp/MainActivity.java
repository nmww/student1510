package com.example.mybabyapp;



import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

public class MainActivity extends TabActivity implements OnTabChangeListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_tab_hosts);
		// �̳� tabActivity���õ�tabHost
		TabHost tabhost = getTabHost();
		

				// �����һ��tab ������ť
				TabSpec tabSpec01 = tabhost.newTabSpec("tab1");
				// ����tab ������ť�Ĳ���
				tabSpec01.setIndicator(View.inflate(MainActivity.this,
						R.layout.tab_home, null));
				Intent intent01 = new Intent(this, ShouYeActivity.class);
				tabSpec01.setContent(intent01);
				tabhost.addTab(tabSpec01);
		
		//02
		TabSpec tabSpec02 = tabhost.newTabSpec("��ǩ2");
		tabSpec02.setIndicator(View.inflate(MainActivity.this,
				R.layout.tab_fenlei, null));
		Intent intent02 = new Intent(this, FenLeiActivity.class);
		tabSpec02.setContent(intent02);
		tabhost.addTab(tabSpec02);
		//03
		TabSpec tabSpec03 = tabhost.newTabSpec("��ǩ3");
		tabSpec03.setIndicator(View.inflate(MainActivity.this,
				R.layout.tab_sousuo, null));
		Intent intent03 = new Intent(this, SouSuoActivity.class);
		tabSpec03.setContent(intent03);
		tabhost.addTab(tabSpec03);
		//04
		TabSpec tabSpec04 = tabhost.newTabSpec("��ǩ4");
		tabSpec04.setIndicator(View.inflate(MainActivity.this,
				R.layout.tab_gouwu, null));
		Intent intent04 = new Intent(this, GouWuCheActivity.class);
		tabSpec04.setContent(intent04);
		tabhost.addTab(tabSpec04);
		//05
		TabSpec tabSpec05 = tabhost.newTabSpec("��ǩ5");
		tabSpec05.setIndicator(View.inflate(MainActivity.this,
				R.layout.tab_genduo, null));
		Intent intent05 = new Intent(this, GenDuoActivity.class);
		tabSpec05.setContent(intent05);
		tabhost.addTab(tabSpec05);
		
		
		

	}

	@Override
	public void onTabChanged(String tabId) {
		// TODO Auto-generated method stub
		Log.e("", "tabId");
	}
	
	
	
}
