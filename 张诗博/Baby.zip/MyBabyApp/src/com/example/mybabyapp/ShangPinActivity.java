package com.example.mybabyapp;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.Toast;

import com.example.mybabyapp.adapter.SPAdapter;


public class ShangPinActivity extends Activity {
	Button btn1;
	Button btn2;
	ListView lvList;
	ArrayList<Map<String, Object>> resData;
	SPAdapter spAdapter;
	Button btnfh;
	RatingBar ratingBarTure;
	private TextView text;
	private TextView text1;
	private ImageView imglogo; 
	private TextView text2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shang_pin_layout);
		lvList = (ListView) findViewById(R.id.lv_sp_miao_shu);
		getRes();
		spAdapter = new SPAdapter(ShangPinActivity.this, resData);
        lvList.setAdapter(spAdapter);
        btnfh = (Button) findViewById(R.id.btn_sp_fh);
		btnfh.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(ShangPinActivity.this,XianShiActivity.class);
				startActivity(intent);
			}
		});
		ratingBarTure = (RatingBar) findViewById(R.id.rb_true);
		ratingBarTure.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
			
			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
				Toast toast = Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT);
				int i = (int)rating;
				switch (i) {
				case 1:
					toast.setText("���ز�����");
					toast.show();
					break;
					
				case 2:
					toast.setText("������");
					toast.show();
					break;
				case 3:
					toast.setText("һ��");
					toast.show();
					break;
				case 4:
					toast.setText("����");
					toast.show();
					break;
				case 5:
					toast.setText("�ǳ�����");
					toast.show();
					break;
				default:
					break;
				}
			}
		});
		  dialog();	
		  Intent intent = this.getIntent();
			Bundle bundle = intent.getExtras();
			String tagname = bundle.getString("name");
			text = (TextView) findViewById(R.id.tv_sp_name_sp);
			text.setText(tagname);
			int imglog = bundle.getInt("img");
			imglogo = (ImageView) findViewById(R.id.img_LOGO);
			imglogo.setImageResource(imglog);
			String jiaqian = bundle.getString("qian");
			text2 = (TextView) findViewById(R.id.tv_sp_shou_jia_num);
			text2.setText(jiaqian);
	}

	private void dialog() {
		btn1 = (Button) findViewById(R.id.btn_sp_gou_wu);
	        btn1.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					AlertDialog.Builder dialog=new AlertDialog.Builder(ShangPinActivity.this);
					dialog.setIcon(R.drawable.ic_launcher);
					dialog.setTitle("��ܰ��ʾ");
					dialog.setMessage("�Ѽ��빺�ﳵ��");
					dialog.setNegativeButton("ȷ��", 
							new  DialogInterface.OnClickListener() {
								
								@Override
								public void onClick(DialogInterface dialog, int which) {
									Toast.makeText(ShangPinActivity.this, "*-*", 100)
									.show();
									dialog.dismiss();
								}
							});
					// ����һ��AlertDialog
					dialog.create();
					// ��ʾһ��AlertDialog
					dialog.show();
				}
	        });
	        btn2 = (Button) findViewById(R.id.btn_sp_shou_cang);
	        btn2.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					AlertDialog.Builder dialog=new AlertDialog.Builder(ShangPinActivity.this);
					dialog.setIcon(R.drawable.ic_launcher);
					dialog.setTitle("��ܰ��ʾ");
					dialog.setMessage("�ղسɹ���");
					dialog.setNegativeButton("ȷ��", 
							new  DialogInterface.OnClickListener() {
								
								@Override
								public void onClick(DialogInterface dialog, int which) {
									Toast.makeText(ShangPinActivity.this, "*-*", 100)
									.show();
									dialog.dismiss();
								}
							});
					// ����һ��AlertDialog
					dialog.create();
					// ��ʾһ��AlertDialog
					dialog.show();
				}
	        });
	}

	private void getRes() {
		// TODO Auto-generated method stub
		resData = new ArrayList<Map<String,Object>>();
    	Map m = new HashMap<String, Object>();
		m.put("txt", "��Ʒ����");
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "��Ʒ��� �� �����֣��л���");
		resData.add(m);
		m = new HashMap<String, Object>();
		m.put("txt", "�������ۣ�100��");
		resData.add(m);
	}
}
