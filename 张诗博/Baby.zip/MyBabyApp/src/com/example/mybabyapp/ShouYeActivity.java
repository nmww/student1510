package com.example.mybabyapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.ViewSwitcher.ViewFactory;

import com.example.mybabyapp.adapter.GarrleryAdapter;
import com.example.mybabyapp.adapter.LVAdapter;

public class ShouYeActivity extends Activity implements ViewFactory {
Integer[] imageData = null;
	
	Gallery galleryView;
	GarrleryAdapter garrAdapter;
	int num = 0;
	ListView lvList;
	ArrayList<Map<String, Object>> resData;
	LVAdapter lvAdapter;
	Button btnPhone;
	int position=0;
		
		Handler handler=new Handler(){
			public void handleMessage(android.os.Message msg){
				switch (msg.arg1) {
				case 0:
					if(position<imageData.length-1){
						position++;
					}else{
						position=0;
					}
					galleryView.setSelection(position);
					break;
	
				default:
					break;
				}
			}
		};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shou_ye_layout);
        getData();
        galleryView = (Gallery) findViewById(R.id.gallery_view);
        garrAdapter = new GarrleryAdapter(this, imageData);
        galleryView.setAdapter(garrAdapter);
        Timer timer=new Timer();
		TimerTask tt=new TimerTask(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				Message msg=new Message();
				msg.arg1=0;
				handler.sendMessage(msg);
			}
			
		};
		timer.schedule(tt, 2000,2000);
        lvList = (ListView) findViewById(R.id._lv_list);
        getRes();
        lvAdapter = new LVAdapter(ShouYeActivity.this, resData);
        lvList.setAdapter(lvAdapter);
        lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(position==0){
                	Intent intent = new Intent(ShouYeActivity.this,XianShiActivity.class);
                	startActivity(intent);
                }
                if(position==1){
                Intent intent = new Intent(ShouYeActivity.this,CuXiaoActivity.class);
                startActivity(intent);
             }
                if(position==2){
                	Toast.makeText(ShouYeActivity.this, "��Ʒ�ϼ�", 100)
    				.show();
            }
                if(position==3){
                	Toast.makeText(ShouYeActivity.this, "���ŵ�Ʒ", 100)
    				.show();
                }
                if(position==4){
                	Toast.makeText(ShouYeActivity.this, "�Ƽ�Ʒ��", 100)
    				.show();
                }
			}
        	
        });
        btnPhone = (Button) findViewById(R.id.btn_phone);
		btnPhone.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intentPhone = new Intent();
				intentPhone.setAction(Intent.ACTION_DIAL);
				Uri uri =Uri.parse("tel:15135628138");
				intentPhone.setData(uri);
				startActivity(intentPhone);
			}
		});



    }


    private void getRes() {
		// TODO Auto-generated method stub
    	resData = new ArrayList<Map<String,Object>>();
    	Map m = new HashMap<String, Object>();
    	m.put("img", R.drawable.home_classify_01);
		m.put("txt", "��ʱ����");
		m.put("log",R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.home_classify_02);
		m.put("txt", "�����챨");
		m.put("log",R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.home_classify_03);
		m.put("txt", "��Ʒ�ϼ�");
		m.put("log",R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.home_classify_04);
		m.put("txt", "���ŵ�Ʒ");
		m.put("log",R.drawable.arrow);
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.home_classify_05);
		m.put("txt", "�Ƽ�Ʒ��");
		m.put("log",R.drawable.arrow);
		resData.add(m);
	}


	private void getData() {
		// TODO Auto-generated method stub
    	imageData = new Integer[] {R.drawable.gallery_3,
    		R.drawable.gallery_2,R.drawable.gallery_1,R.drawable.gallery_4,
    		R.drawable.gallery_5
    	};
	}
    public View makeView() {
		// TODO Auto-generated method stub
		ImageView iv = new ImageView(this);
		return iv;
	}

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	
	
    
}
