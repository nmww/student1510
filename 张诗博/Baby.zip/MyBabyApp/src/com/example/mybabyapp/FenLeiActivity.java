package com.example.mybabyapp;

import java.util.ArrayList;


import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mybabyapp.adapter.FLAdapter;


public class FenLeiActivity extends Activity {
	
	ListView lvList;
	ArrayList<Map<String, Object>> resData;
	FLAdapter flAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fenlei);
		lvList = (ListView) findViewById(R.id._lv_list);
		getRes();
        flAdapter = new FLAdapter(FenLeiActivity.this, resData);
        lvList.setAdapter(flAdapter);
	}
	private void getRes() {
		// TODO Auto-generated method stub
		resData = new ArrayList<Map<String,Object>>();
    	Map m = new HashMap<String, Object>();
    	m.put("img", R.drawable.pregnant);
		m.put("txt", "����ר��");
		m.put("txi","��ӤӪ��Ʒ/�̷�");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.food);
		m.put("txt", "Ӫ��ʳƷ");
		m.put("txi","�̷�");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.baby_cloth);
		m.put("txt", "���ϴ��");
		m.put("txi","���/ֽ�� Ӥ�׶�ϴԡ����");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.paper_diaper);
		m.put("txt", "������Ʒ");
		m.put("txi","ι����Ʒ �ճ�����");
		resData.add(m);
		m = new HashMap<String, Object>();
    	m.put("img", R.drawable.toy);
		m.put("txt", "���ͯ��");
		m.put("txi","������� Ӥ����");
		resData.add(m);
	}
}
