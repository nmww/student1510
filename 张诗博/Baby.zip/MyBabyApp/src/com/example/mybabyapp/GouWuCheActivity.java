package com.example.mybabyapp;






import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class GouWuCheActivity extends Activity {
	Button btnsbgg;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.gwc_layout);
		 btnsbgg = (Button) findViewById(R.id.but_ss);
	        btnsbgg.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent=new Intent(GouWuCheActivity.this,MainActivity.class);
					startActivity(intent);
					
				}
			});
	}
}
