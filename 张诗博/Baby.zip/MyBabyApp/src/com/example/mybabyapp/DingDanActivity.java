package com.example.mybabyapp;
import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class DingDanActivity extends Activity {
	Button btnexit;
	Button btnjs;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ding_dan_layout);
		btnexit = (Button) findViewById(R.id.btn_fh);
		btnexit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(DingDanActivity.this,GenDuoActivity.class);
				startActivity(intent);
			}
		});
		btnjs = (Button) findViewById(R.id.btn_js);
		btnjs.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent1=new Intent(DingDanActivity.this,JeiSuanActivity.class);
				startActivity(intent1);
			}
		});
	}
}
