package com.example.mybabyapp;



import java.util.ArrayList;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.example.mybabyapp.adapter.SsExpandAdapter;

public class SouSuoActivity extends Activity {
		Button btn1;
		AutoCompleteTextView autoComTextView;
		ArrayList<String> strResource;
		ArrayAdapter<String> arrayAdapter;
		ExpandableListView ssexpandListView;// �ҵ�view����
		//��ʼ��������ݶ���`
		String[] Groups = { "��������", "������ʷ" };
		//��ʼ����Ա�����ݶ���
		String[][] Childs = {
				{ "ɮ��߸", "���޳�","������" }, { "ɮ��߸", "���޳�","������" } };
		
		//��Ҫ����Զ���������
		SsExpandAdapter ssexpandAdapter = null;//����������
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.sou_suo_layout);
	        ssexpandListView = (ExpandableListView) findViewById(R.id.expand_listview);//���Ҷ���
			
			ssexpandAdapter = new SsExpandAdapter(this, Groups, Childs);//�����Զ�������������
			
			ssexpandListView.setAdapter(ssexpandAdapter);//����������
	        btn1 = (Button) findViewById(R.id.btn1);
	        btn1.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					AlertDialog.Builder dialog=new AlertDialog.Builder(SouSuoActivity.this);
					dialog.setIcon(R.drawable.ic_launcher);
					dialog.setTitle("��ܰ��ʾ");
					dialog.setMessage("����Ʒ�����ڣ�");
					dialog.setNegativeButton("ȷ��", 
							new OnClickListener() {
								
								@Override
								public void onClick(DialogInterface dialog, int which) {
									// TODO Auto-generated method stub
									Toast.makeText(SouSuoActivity.this, "*-*", 100)
									.show();
									dialog.dismiss();
								}
							});
					// ����һ��AlertDialog
					dialog.create();
					// ��ʾһ��AlertDialog
					dialog.show();
				}
	        });	
	        autoComTextView = (AutoCompleteTextView) findViewById(R.id.auto_com_tv);
	        getRsourcesStr();  
	        arrayAdapter = new ArrayAdapter<String>(getApplication(), R.layout.auto_item,strResource);
	        autoComTextView.setAdapter(arrayAdapter);
	    }
		private void getRsourcesStr() {
			// TODO Auto-generated method stub
			strResource =new ArrayList<String>();
	    	strResource.add("qeqr");
			strResource.add("qqr");
			strResource.add("qeqrfasf");
			strResource.add("qqrafaf");
			strResource.add("qeqrzvva");
			strResource.add("qqrafsafa");
			strResource.add("af");
			strResource.add("14314");
			strResource.add("iyoiy");
			strResource.add("afda");
			strResource.add("adafsdf");
			strResource.add("13414124");
			strResource.add("adafsdf");
			strResource.add("qerqr");
			strResource.add("3425432");
			strResource.add("adafsdf");
			strResource.add("qewqr");
			strResource.add("adfafa");
			strResource.add("zadfaf");
			strResource.add("qerq");
			strResource.add("adafsdf");
			strResource.add("qrewq");
			strResource.add("adafsdf");
			strResource.add("adwerwqafsdf");
			strResource.add("14144");
			strResource.add("adafsdf");
			strResource.add("adfaf");
			strResource.add("qewqr");
		}
}
					

				
