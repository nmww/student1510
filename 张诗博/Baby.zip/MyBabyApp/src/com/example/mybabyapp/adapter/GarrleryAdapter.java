package com.example.mybabyapp.adapter;

import com.example.mybabyapp.R;

import com.example.mybabyapp.R.id;
import com.example.mybabyapp.R.layout;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class GarrleryAdapter extends BaseAdapter {
	Context mContext;
	Integer[] intData = null;
	public GarrleryAdapter(Context c,Integer[] str){
		mContext = c;
		intData = str;
	
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return intData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class ViewHolder{
		ImageView iv;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder viewHolder = null;
		if(convertView == null){
			viewHolder = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.qarrlery_it, null);
			viewHolder.iv = (ImageView) convertView.findViewById(R.id.iv_image);
			convertView.setTag(viewHolder);
		}else{
			viewHolder = (ViewHolder) convertView.getTag();
		}
		viewHolder.iv.setImageResource(intData[position]);
		
		// TODO Auto-generated method stub
		return convertView;
		
	}

}
