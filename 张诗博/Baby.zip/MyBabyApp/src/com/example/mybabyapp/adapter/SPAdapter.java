package com.example.mybabyapp.adapter;

import java.util.ArrayList;
import java.util.Map;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.mybabyapp.R;

public class SPAdapter extends BaseAdapter {
	Context mContext;
	ArrayList<Map<String, Object>> dataList;
	public SPAdapter(Context context,ArrayList<Map<String, Object>>data){
		mContext = context;
		dataList =data;
		
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return dataList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return dataList.get(position);
	}
	

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = new ViewHolder();
		if(convertView == null){
			convertView = View.inflate(mContext,R.layout.listview_shangpin, null);
			vh.tvName = (TextView) convertView.findViewById(R.id.tv_sp_item_);

			convertView.setTag(vh);
		}else{
			vh = (ViewHolder)convertView.getTag();
			}
		vh.tvName.setText((CharSequence) dataList.get(position).get("txt"));
		return convertView;
	}
	class ViewHolder{
		TextView tvName;
		
	}

}
