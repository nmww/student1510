package com.example.mybabyapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ZhuCeActivity extends Activity {
	Button btntj;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zhu_ce_layout);
		btntj = (Button) findViewById(R.id.btn_tj);
		btntj.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "�ύ�ɹ�",Toast.LENGTH_LONG).show();
			}
		});
	}
}
