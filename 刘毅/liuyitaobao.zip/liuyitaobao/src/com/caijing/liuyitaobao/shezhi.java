package com.caijing.liuyitaobao;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;

import com.caijing.liuyitaobao.adapter.Shezhiadbpter;
import com.caijing.liuyitaobao.bean.Shezhibear;


public class shezhi extends Activity {
	ListView shezhilv;
	ArrayList<Shezhibear> listdate;
	int []left={R.drawable.shezhi01,R.drawable.shezhi02,R.drawable.shezhi03,R.drawable.shezhi04,
			R.drawable.shezhi05,R.drawable.shezhi06};
	String[] name={"��������","�˻��밲ȫ","��Ϣ","ͨ��","�ҵ�С��","�����ֻ��Ա�"};
	int []right={R.drawable.shezhi07,R.drawable.shezhi07,R.drawable.shezhi07,R.drawable.shezhi07,
			R.drawable.shezhi07,R.drawable.shezhi07};
	ImageButton ib;
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		getMenuInflater().inflate(R.menu.main, menu);
		menu.add(1, 1, 1, "��Ϣ");
		menu.add(1, 2, 1, "��ҳ");
		menu.add(1, 3, 1, "���б�");
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		return super.onOptionsItemSelected(item);
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shezhi);
		indate();
		shezhilv=(ListView) findViewById(R.id.shezhi_listview_one);
		Shezhiadbpter shezhi=new Shezhiadbpter(this, listdate);
		shezhilv.setAdapter(shezhi);
		ib=(ImageButton) findViewById(R.id.shezhi_fanhui);
		ib.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(shezhi.this, daohang.class);
				startActivity(in);
			}
		});
		shezhilv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				if (position==0) {
						Intent in=new Intent(shezhi.this, gerenziliao.class);
						startActivity(in);
					}else if(position==1){
						Intent in=new Intent(shezhi.this, zhanghaoyuanquan.class);
						startActivity(in);
					}else if (position==2) {
						Intent in=new Intent(shezhi.this, xiaoxitongzhi.class);
						startActivity(in);
					}
				
				}
		});
	}
	private void indate() {
		// TODO Auto-generated method stub
		listdate=new ArrayList<Shezhibear>();
		for (int i = 0; i <left.length; i++) {
			Shezhibear sz=new Shezhibear();
			sz.setIntegleft(left[i]);
			sz.setIntegright(right[i]);
			sz.setStr(name[i]);
			listdate.add(sz);
		}
	}

}
