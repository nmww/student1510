package com.caijing.liuyitaobao;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;

import com.caijing.liuyitaobao.adapter.Gouwucheadapter;

public class Gouwuche extends Activity {
	GridView grid;
	Integer gouwuDate;
	Gouwucheadapter gouwu;
	Integer [] gouwuin={R.drawable.gouwuche02,R.drawable.gouwuche03,R.drawable.gouwuche04,R.drawable.gouwuche05};
	@Override
	protected void onCreate(Bundle savedInstanceState) {	
	 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gouwuche );
		grid=(GridView) findViewById(R.id.gouwu_gv);
		gouwu=new Gouwucheadapter(this, gouwuin);
		grid.setAdapter(gouwu);
	}
}
