package com.caijing.liuyitaobao;

import android.app.Activity;
import android.os.Bundle;

public class zhanghaoyuanquan extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zhanghaoyuanquan);
	}
}
