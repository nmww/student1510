package com.caijing.liuyitaobao;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.caijing.liuyitaobao.adapter.mytaobaoAdapter;
import com.caijing.liuyitaobao.shangchuan.ImageYuanJiao;

public class mytaobao extends Activity {
	GridView gridview;
	mytaobaoAdapter myadapter;
	TextView tv;
	ImageView image;
	Integer [] gridDate={R.drawable.mytaobao,R.drawable.mytaobao02,R.drawable.mytaobao03,R.drawable.mytaobao04,
			R.drawable.mytaobao05,R.drawable.mytaobao06,R.drawable.mytaobao07,R.drawable.mytaobao08,R.drawable.mytaobao09,R.drawable.mytaobao10};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mytaobao);
		gridview=(GridView) findViewById(R.id.mytaobao_gv);
		myadapter=new mytaobaoAdapter(mytaobao.this, gridDate);
		gridview.setAdapter(myadapter);
		tv=(TextView) findViewById(R.id.mytaobao_tv_shezhi);
		tv.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(mytaobao.this, shezhi.class);
				startActivity(in);
			}
		});
		image=(ImageView) findViewById(R.id.shangchuan);
		image.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
			    intent.addCategory(Intent.CATEGORY_OPENABLE);
			    intent.setType("image/*");
			    intent.putExtra("crop", "true");
			    intent.putExtra("aspectX", 1);
			    intent.putExtra("aspectY", 1);
			    intent.putExtra("outputX", 80);
			    intent.putExtra("outputY", 80);
			    intent.putExtra("return-data", true);

			    startActivityForResult(intent, 0);
				
			}
		});
	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		  System.out.println(resultCode);
		 
		  try {
			Bitmap cameraBitmap = (Bitmap) data.getExtras().get("data");
			  super.onActivityResult(requestCode, resultCode, data);
			  
			  ImageView ivLogo=(ImageView) findViewById(R.id.shangchuan);
				//Bitmap btUserLogo=ImageYuanJiao.drawableToBitmap(getResources().getDrawable(R.drawable.user_head));
			  cameraBitmap=ImageYuanJiao.toRoundCorner(cameraBitmap, 1000);
				Drawable draimage=ImageYuanJiao.bitmapToDrawble(cameraBitmap, this);
				ivLogo.setBackgroundDrawable(draimage);

			    	Drawable drawable =new BitmapDrawable(cameraBitmap);
			    	image.setBackgroundDrawable(drawable);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		 }

}
