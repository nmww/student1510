package com.caijing.liuyitaobao.bean;


public class Shezhibear {

	 
	int integleft;
	public int getIntegleft() {
		return integleft;
	}
	public void setIntegleft(int integleft) {
		this.integleft = integleft;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public int getIntegright() {
		return integright;
	}
	public void setIntegright(int integright) {
		this.integright = integright;
	}
	String str;
	int integright;
	 
}
