package com.caijing.liuyitaobao;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

public class gerenziliao extends Activity {
	TextView tv;
	PopupWindow pw;
	ImageView iv;
	Button bt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gerenziliao);
		tv=(TextView) findViewById(R.id.erweima);
		tv.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				getPopWind();
				pw.showAsDropDown(v, 0, -210);
			}
		});
	}

	private void getPopWind(){
		if(null == pw){
			initPopupWindw();
		}else{
			pw.dismiss();
		}
	}

	private void initPopupWindw() {
		//��ʼ��popwindow 
		View v = View.inflate(this, R.layout.erweima, null);
		iv = (ImageView) v.findViewById(R.id.erweima);
		bt =(Button) v.findViewById(R.id.quxiao);
		bt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				pw.dismiss();
			}
		});
		pw = new PopupWindow(v, 500, 500);
		pw.setFocusable(true);
		pw.setOutsideTouchable(true);
		pw.setBackgroundDrawable(new BitmapDrawable());
	}
}
