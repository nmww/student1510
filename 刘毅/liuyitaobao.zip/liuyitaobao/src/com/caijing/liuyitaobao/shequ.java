package com.caijing.liuyitaobao;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class shequ extends TabActivity {
	TabHost tabhost;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shequ);
		tabhost=this.getTabHost();
		TabSpec spec1=tabhost.newTabSpec("�ҵ�����");
		spec1.setIndicator(View.inflate(shequ.this, R.layout.shequone, null));
		Intent in1 =new Intent(shequ.this, myshequ.class);
		spec1.setContent(in1);
		tabhost.addTab(spec1);
		
		TabSpec spec2=tabhost.newTabSpec("������");
		spec2.setIndicator(View.inflate(shequ.this, R.layout.shequtwo, null));
		Intent in2 =new Intent(shequ.this, chuandaxiu.class);
		spec2.setContent(in2);
		tabhost.addTab(spec2);
		
		TabSpec spec3=tabhost.newTabSpec("ȫ��û�");
		spec3.setIndicator(View.inflate(shequ.this, R.layout.shequthree, null));
		Intent in3 =new Intent(shequ.this, quanqiuhaohuo.class);
		spec3.setContent(in3);
		tabhost.addTab(spec3);
		
		TabSpec spec4=tabhost.newTabSpec("�����ȱ�");
		spec4.setIndicator(View.inflate(shequ.this, R.layout.shequfour, null));
		Intent in4 =new Intent(shequ.this, lamamengbao.class);
		spec4.setContent(in4);
		tabhost.addTab(spec4);
	}
}
