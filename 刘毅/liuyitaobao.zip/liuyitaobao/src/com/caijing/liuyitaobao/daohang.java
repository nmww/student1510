package com.caijing.liuyitaobao;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class daohang extends TabActivity{
	TabHost tabhost;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tabhost);
		tabhost=this.getTabHost();
		TabSpec spec1=tabhost.newTabSpec("��ҳ");
		spec1.setIndicator(View.inflate(this, R.layout.daohangone, null));
		Intent in=new Intent(daohang.this,shouye.class);
		spec1.setContent(in);
		tabhost.addTab(spec1);
		
		TabSpec spec2=tabhost.newTabSpec("΢��");
		spec2.setIndicator(View.inflate(this, R.layout.daohangtwo, null));
		Intent in2=new Intent(daohang.this,MainActivity.class);
		spec2.setContent(in2);
		tabhost.addTab(spec2);
		
		TabSpec spec3=tabhost.newTabSpec("����");
		spec3.setIndicator(View.inflate(this, R.layout.daohangthree, null));
		Intent in3=new Intent(daohang.this,shequ.class);
		spec3.setContent(in3);
		tabhost.addTab(spec3);
		
		TabSpec spec4=tabhost.newTabSpec("���ﳵ");
		spec4.setIndicator(View.inflate(this, R.layout.daohangfour, null));
		Intent in4=new Intent(daohang.this,Gouwuche.class);
		spec4.setContent(in4);
		tabhost.addTab(spec4);
		
		TabSpec spec5=tabhost.newTabSpec("�ҵ��Ա�");
		spec5.setIndicator(View.inflate(this, R.layout.daohangfive, null));
		Intent in5=new Intent(daohang.this,mytaobao.class);
		spec5.setContent(in5);
		tabhost.addTab(spec5);


	}
}
