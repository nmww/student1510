package com.caijing.liuyitaobao;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Gallery;
import android.widget.GridView;

import com.caijing.liuyitaobao.adapter.shouyegallery;
import com.caijing.liuyitaobao.adapter.shouyegridview;

public class shouye extends Activity {
	GridView gv;
	Gallery gly;
	shouyegridview sg;
	shouyegallery syg;
	Integer[] shouyeDate={R.drawable.shouye01,R.drawable.shouye02,R.drawable.shouye03,R.drawable.shouye04,R.drawable.shouye05,
			R.drawable.shouye06,R.drawable.shouye07,R.drawable.shouye08,R.drawable.shouye09,R.drawable.shouye10,};
	Integer [] glyDate={R.drawable.shouyelunbou1,R.drawable.shouyelunbou2,R.drawable.shouyelunbou3,R.drawable.shouyelunbou4,
			R.drawable.shouyelunbou5,R.drawable.shouyelunbou6,R.drawable.shouyelunbou7,R.drawable.shouyelunbou8,};
	int position = 0;
	Handler handler;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		gv=(GridView) findViewById(R.id.shouye_gridview);
		sg=new shouyegridview(shouye.this, shouyeDate);
		gv.setAdapter(sg);
		gly=(Gallery) findViewById(R.id.shouye_gallery)
				;
		syg=new shouyegallery(shouye.this, glyDate);
		gly.setAdapter(syg);
		
		
		 handler = new Handler(){//ÿ�ε�������ķ���  ����ı�ͼƬ
			public void handleMessage(android.os.Message msg) {
				switch (msg.arg1) {
				case 0:
					if(position < glyDate.length - 1){
						position++;
					}else{
						position = 0;
					}
					gly.setSelection(position);
					break;

				default:
					break;
				}
			};
		};
		Timer timer = new Timer();
		TimerTask timerTask = new TimerTask() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Message msg = new Message();
				msg.arg1 = 0;
				handler.sendMessage(msg);
			}
		};
		timer.schedule(timerTask, 2000, 2000);//���ü���������һ�η���
	}
	
}
