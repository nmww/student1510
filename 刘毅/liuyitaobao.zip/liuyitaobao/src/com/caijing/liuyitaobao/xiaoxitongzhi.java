package com.caijing.liuyitaobao;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class xiaoxitongzhi extends Activity {
	ImageButton	imageb1;
	ImageButton	imageb2;
	ImageButton	imageb3;
	ImageButton	imageb4;
	int i=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xinxitongzhi);
		imageb1=(ImageButton) findViewById(R.id.xiaoxi_one);
		imageb1.setOnClickListener(new OnClickListener() {
			
			
			@Override
			public void onClick(View v) {
				i++;
				// TODO Auto-generated method stub
				if (i%2==0) {
					imageb1.setBackgroundResource(R.drawable.xinxitongzhi);
				}else {
					imageb1.setBackgroundResource(R.drawable.xinxitongzhi1);
				}
				
			}
		});
		imageb2=(ImageButton) findViewById(R.id.xiaoxi_two);
		imageb2.setOnClickListener(new OnClickListener() {
			
			
			@Override
			public void onClick(View v) {
				i++;
				// TODO Auto-generated method stub
				if (i%2==0) {
					imageb2.setBackgroundResource(R.drawable.xinxitongzhi);
				}else {
					imageb2.setBackgroundResource(R.drawable.xinxitongzhi1);
				}
				
			}
		});
		imageb3=(ImageButton) findViewById(R.id.xiaoxi_three);
		imageb3.setOnClickListener(new OnClickListener() {
			
			
			@Override
			public void onClick(View v) {
				i++;
				// TODO Auto-generated method stub
				if (i%2==0) {
					imageb3.setBackgroundResource(R.drawable.xinxitongzhi);
				}else {
					imageb3.setBackgroundResource(R.drawable.xinxitongzhi1);
				}
				
			}
		});
		imageb4=(ImageButton) findViewById(R.id.xiaoxi_four);
		imageb4.setOnClickListener(new OnClickListener() {
			
			
			@Override
			public void onClick(View v) {
				i++;
				// TODO Auto-generated method stub
				if (i%2==0) {
					imageb4.setBackgroundResource(R.drawable.xinxitongzhi);
				}else {
					imageb4.setBackgroundResource(R.drawable.xinxitongzhi1);
				}
				
			}
		});
		
	}
}
