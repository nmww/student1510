package com.caijing.liuyitaobao.adapter;

import com.caijing.liuyitaobao.R;
import com.caijing.liuyitaobao.adapter.shouyegridview.viewHolder;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class shouyegridview extends BaseAdapter {
	Context mcontext;
	Integer []integer;
	public shouyegridview(Context c,Integer[] in) {
		// TODO Auto-generated constructor stub
		mcontext = c;
		integer = in;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return integer.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class viewHolder{
		ImageView iv;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		viewHolder vh = null;
		if (convertView==null) {
			vh=new viewHolder();
			convertView=View.inflate(mcontext, R.layout.shouyegrid, null);
			vh.iv=(ImageView) convertView.findViewById(R.id.shouyegrid_iv);
			convertView.setTag(vh);
		}else {
			vh=(viewHolder) convertView.getTag();
		}
		vh.iv.setImageResource(integer[position]);
		return convertView;
	}

}
