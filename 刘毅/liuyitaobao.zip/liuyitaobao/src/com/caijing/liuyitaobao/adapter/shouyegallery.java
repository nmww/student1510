package com.caijing.liuyitaobao.adapter;

import com.caijing.liuyitaobao.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class shouyegallery extends BaseAdapter {
	Context mcontext;
	Integer[] gallery;
	public shouyegallery(Context c,Integer[] in) {
		// TODO Auto-generated constructor stub
		mcontext = c;
		gallery = in;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return gallery.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class viewHolder{
		ImageView iv;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		viewHolder vh=null;
		if (convertView==null) {
			vh=new viewHolder();
			convertView=View.inflate(mcontext, R.layout.shouyegall, null);
			vh.iv=(ImageView) convertView.findViewById(R.id.shouyegall_iv);
			convertView.setTag(vh);
		}else {
			vh=(viewHolder) convertView.getTag();
		}
		vh.iv.setImageResource(gallery[position]);
		return convertView;
	}

}
