package com.caijing.liuyitaobao.adapter;

import java.util.ArrayList;

import com.caijing.liuyitaobao.R;
import com.caijing.liuyitaobao.bean.Shezhibear;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Shezhiadbpter extends BaseAdapter {
	Context mcontext;
	ArrayList<Shezhibear> bear;
	public Shezhiadbpter(Context c,ArrayList<Shezhibear> Bear ) {
		mcontext = c;
		bear = Bear;
	}
	@Override
	public int getCount() {
		
		return bear.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class viewHolder{
		ImageView ivlift;
		TextView tv;
		ImageView ivright;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		viewHolder vh=null;
		if (convertView==null) {
			vh=new viewHolder();
			convertView=View.inflate(mcontext, R.layout.shezhilistview, null);
			vh.ivlift=(ImageView) convertView.findViewById(R.id.shezhilistview_iv_lift);
			vh.ivright=(ImageView) convertView.findViewById(R.id.shezhilistview_iv_right);
			vh.tv=(TextView) convertView.findViewById(R.id.shezhilistview_tv);
			convertView.setTag(vh);
		}else {
			vh=(viewHolder) convertView.getTag();
		}
		vh.ivlift.setImageResource(bear.get(position).getIntegleft());
		vh.ivright.setImageResource(bear.get(position).getIntegright());
		vh.tv.setText(bear.get(position).getStr());
		return convertView;
		
	}

}
