package com.caijing.liuyitaobao.adapter;

import com.caijing.liuyitaobao.R;
import com.caijing.liuyitaobao.R.layout;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class mytaobaoAdapter extends BaseAdapter {
	Context mcontext;
	Integer [] integerDate;
	public mytaobaoAdapter(Context c,Integer[] Date){
		mcontext = c;
		integerDate = Date;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return integerDate.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return integerDate[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class viewHoder{
		ImageView iv;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		viewHoder vh=null;
		if(convertView==null){
			vh=new viewHoder();
			convertView=View.inflate(mcontext,R.layout.mytaobaogridview, null);
			vh.iv=(ImageView) convertView.findViewById(R.id.mytaobaogridview_iv);
			convertView.setTag(vh);
		}else{
			vh=(viewHoder) convertView.getTag();
		}
		vh.iv.setImageResource(integerDate[position]);
		return convertView;
	}

}
