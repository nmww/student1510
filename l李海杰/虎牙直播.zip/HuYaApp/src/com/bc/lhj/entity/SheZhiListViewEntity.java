package com.bc.lhj.entity;

public class SheZhiListViewEntity {

	int img;
	String txtShang;
	String txtZhong;
	String txtXia;

	public int getImg() {
		return img;
	}

	public void setImg(int img) {
		this.img = img;
	}

	public String getTxtShang() {
		return txtShang;
	}

	public void setTxtShang(String txtShang) {
		this.txtShang = txtShang;
	}

	public String getTxtZhong() {
		return txtZhong;
	}

	public void setTxtZhong(String txtZhong) {
		this.txtZhong = txtZhong;
	}

	public String getTxtXia() {
		return txtXia;
	}

	public void setTxtXia(String txtXia) {
		this.txtXia = txtXia;
	}

}
