package com.bc.lhj.entity;

public class ZhiBoPopupWindowEntity {

	int img;
	String text;

	public int getImg() {
		return img;
	}

	public void setImg(int img) {
		this.img = img;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
