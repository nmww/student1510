package com.bc.lhj.entity;

public class BangZhuListViewEntity {

	String text;
	int img;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getImg() {
		return img;
	}

	public void setImg(int img) {
		this.img = img;
	}

}
