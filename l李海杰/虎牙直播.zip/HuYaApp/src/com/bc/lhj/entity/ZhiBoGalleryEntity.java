package com.bc.lhj.entity;

/**
 * ֱ������Galleryʵ����
 * 
 * @author Tar
 * 
 */
public class ZhiBoGalleryEntity {

	int img;

	public int getImg() {
		return img;
	}

	public void setImg(int img) {
		this.img = img;
	}

}
