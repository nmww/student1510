package com.bc.lhj.entity;

/**
 * ֱ��ҳ��GridViewʵ����
 * @author Tar
 *
 */
public class ZhiBoGridViewEntity {

	int img;
	String text;

	public int getImg() {
		return img;
	}

	public void setImg(int img) {
		this.img = img;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
