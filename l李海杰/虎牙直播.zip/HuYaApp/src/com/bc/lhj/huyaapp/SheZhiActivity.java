package com.bc.lhj.huyaapp;

import java.util.ArrayList;

import com.bc.lhj.adapter.YaoQingAdapter;
import com.bc.lhj.entity.YaoQingEntity;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

public class SheZhiActivity extends Activity implements OnClickListener {

	PopupWindow popupWindow;
	LinearLayout layoutYaoQing, layoutBangZhu, layoutBanBen, layoutQingChu;
	AlertDialog.Builder builder;
	GridView gridView;
	CheckBox checkBox1, checkBox2;
	ArrayList<YaoQingEntity> datalist;
	YaoQingAdapter yaoQingAdapter;
	int[] img = { R.drawable.btn_share_wechat_small,
			R.drawable.btn_share_pyq_small, R.drawable.btn_share_qq_small,
			R.drawable.btn_share_sina_small, R.drawable.btn_share_qzone_small };
	String[] text = {"΢��","����Ȧ","QQ","����΢��","QQ�ռ�"};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_wode_layout_shezhi);
		init();
	}

	private void init() {
		layoutYaoQing = (LinearLayout) findViewById(R.id.layout05);
		layoutYaoQing.setOnClickListener(this);

		layoutBangZhu = (LinearLayout) findViewById(R.id.l1);
		layoutBangZhu.setOnClickListener(this);

		layoutBanBen = (LinearLayout) findViewById(R.id.layout08);
		layoutBanBen.setOnClickListener(this);

		layoutQingChu = (LinearLayout) findViewById(R.id.layout07);
		layoutQingChu.setOnClickListener(this);
		
		checkBox1 = (CheckBox) findViewById(R.id.checkbox1);//����checkBoxĬ��Ϊѡ��
		checkBox1.setChecked(true);
		
		checkBox2 = (CheckBox) findViewById(R.id.checkbox2);
		checkBox2.setChecked(true);
	}

	private void qingChu() {
		builder = new AlertDialog.Builder(SheZhiActivity.this);
		TextView tv = new TextView(this);
		tv.setText("ȷ��Ҫ���������");
		tv.setPadding(50, 40, 50, 20);
		tv.setGravity(Gravity.CENTER);

		builder.setView(tv);
		builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

			}
		});

		builder.setPositiveButton("�������",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub

					}
				});
		builder.create();
		builder.show();
	}

	// ��ȡPopupWindow������
	private void initPopWindow() {
		if (popupWindow == null) {
			getPopupWindow();// �õ�window����
		} else {
			popupWindow.dismiss();// ��ʧ
		}
	}

	// ����PopupWindow�е�����
	private void getPopupWindow() {
		View v1 = View.inflate(this, R.layout.tab_wode_layout_yaoqing_gridview,
				null);
		gridView = (GridView) v1.findViewById(R.id.gridView2);
		gridView();
		yaoQingAdapter = new YaoQingAdapter(this, datalist);
		gridView.setAdapter(yaoQingAdapter);
		//gridView.setBackgroundColor(Color.BLACK);

		popupWindow = new PopupWindow(v1, 720, 330);//���÷���Ĳ���,���ÿ������ø�
		popupWindow.setFocusable(true);// ���Ի�ý���
		popupWindow.setOutsideTouchable(true);// ������Դ���
		popupWindow.setBackgroundDrawable(new BitmapDrawable());// �������֮�������ʧ
	}

	// ��GridView�ļ�������������
	private void gridView() {
		datalist = new ArrayList<YaoQingEntity>();
		for (int i = 0; i < img.length; i++) {
			YaoQingEntity yaoQingEntity = new YaoQingEntity();
			yaoQingEntity.setImg(img[i]);
			yaoQingEntity.setText(text[i]);
			datalist.add(yaoQingEntity);
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.layout05:
			initPopWindow();
			popupWindow.showAtLocation(v, Gravity.CENTER, 0, 1200);
			break;

		case R.id.l1:
			Intent intent = new Intent(SheZhiActivity.this,
					BangZhuActivity.class);
			startActivity(intent);
			break;

		case R.id.layout08:
			Intent i = new Intent(SheZhiActivity.this, BanBenActivity.class);
			startActivity(i);
			break;

		case R.id.layout07:
			qingChu();
			break;
		}
	}
}
