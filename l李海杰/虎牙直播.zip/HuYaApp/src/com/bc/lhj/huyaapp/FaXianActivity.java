package com.bc.lhj.huyaapp;

import java.util.ArrayList;
import java.util.List;

import com.bc.lhj.adapter.FaXianListViewAdapter;
import com.bc.lhj.adapter.FaXianYYListViewAdapter;
import com.bc.lhj.entity.FaXianListViewEntity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;

/**
 * ����Activity��
 * 
 * @author Tar
 * 
 */
public class FaXianActivity extends Activity implements OnClickListener {

	ListView listView, listViewYY;
	List<FaXianListViewEntity> datalist;
	LinearLayout layoutYingYong;
	FaXianListViewAdapter faXianListViewAdapter;
	int[] img = { R.drawable.background_setting_seek_thumb_down,
			R.drawable.background_setting_seek_thumb_down,
			R.drawable.background_setting_seek_thumb_down,
			R.drawable.background_setting_seek_thumb_down, };
	String[] text = { "�ҵ��������", "���淹��", "��������", "�ö�Ȧ" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_faxian_layout);
		init();
	}

	private void init() {
		listView = (ListView) findViewById(R.id.tab_faxian_layout_listview);
		addData();
		faXianListViewAdapter = new FaXianListViewAdapter(this, datalist);
		listView.setAdapter(faXianListViewAdapter);

		layoutYingYong = (LinearLayout) findViewById(R.id.tab_faxian_layout_yingyong);
		layoutYingYong.setOnClickListener(this);

		
	}

	// ����ҳ���ListView�������
	private void addData() {
		datalist = new ArrayList<FaXianListViewEntity>();
		for (int i = 0; i < img.length; i++) {
			FaXianListViewEntity listViewEntity = new FaXianListViewEntity();
			listViewEntity.setImg(img[i]);
			listViewEntity.setText(text[i]);
			datalist.add(listViewEntity);
		}
	}


	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.tab_faxian_layout_yingyong:
			Intent intent = new Intent(FaXianActivity.this, YingYong.class);
			startActivity(intent);
			break;

		}
	}

}
