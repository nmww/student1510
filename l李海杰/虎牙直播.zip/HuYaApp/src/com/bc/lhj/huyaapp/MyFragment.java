package com.bc.lhj.huyaapp;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

public class MyFragment extends Fragment{
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v=inflater.inflate(R.layout.tab_zhibo_layout, null);
		ImageButton imgLeft=(ImageButton) v.findViewById(R.id.tab_zhibo_layout_gallery_imgLeft);
		imgLeft.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getActivity(), "fsjadfkljasdfjk", Toast.LENGTH_SHORT);
				
			}
		});
		
		
		// TODO Auto-generated method stub
		return v;
	}
	
}
