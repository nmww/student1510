package com.bc.lhj.huyaapp;

import android.app.ActivityGroup;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class ZhiBoGridViewItem extends ActivityGroup {

	TabHost tabHost;
	//FragmentManager fm=getFragmentManager();
	MyFragment my=new MyFragment();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_zhibo_layout_grid_item_tab);
	//	 FragmentTransaction ft=fm.beginTransaction();
	//	ft.add(my, "11");
	//	ft.show(my);
		tabHost = (TabHost) findViewById(R.id.tab_zhibo_layout_grid_item_tabHost);
		tabHost.setup();
		
		TabSpec tab = tabHost.newTabSpec("��ǩҳ1");
		tab.setIndicator("����",
				this.getResources().getDrawable(R.drawable.grid_3));
//		Intent intent = new Intent(this, LiaoTianTab.class);
//		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//		View v = this.getLocalActivityManager().startActivity("1", intent)
//				.getDecorView();
//		LinearLayout layout = (LinearLayout) this.findViewById(R.id.tab1);
//		layout.removeAllViews();
//		layout.addView(v);
		tab.setContent(R.id.tab1);
		tabHost.addTab(tab);

		TabSpec tab2 = tabHost.newTabSpec("��ǩҳ2");
		tab2.setIndicator("����",
				this.getResources().getDrawable(R.drawable.grid_3));
//		Intent intent2 = new Intent(this, ZhuBoTab.class);
//		intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//		View v2 = this.getLocalActivityManager().startActivity("1", intent)
//				.getDecorView();
//		LinearLayout layout2 = (LinearLayout) this.findViewById(R.id.tab2);
//		layout2.removeAllViews();
//		layout2.addView(v2);
		tab2.setContent(R.id.tab2);
		tabHost.addTab(tab2);

		TabSpec tab3 = tabHost.newTabSpec("��ǩҳ3");
		tab3.setIndicator("����",
				this.getResources().getDrawable(R.drawable.grid_3));
//		Intent intent3 = new Intent(this, PaiHangTab.class);
//		intent3.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//		View v3 = this.getLocalActivityManager().startActivity("1", intent3)
//				.getDecorView();
//		LinearLayout layout3 = (LinearLayout) this.findViewById(R.id.tab3);
//		layout3.removeAllViews();
//		layout3.addView(v3);
		tab3.setContent(R.id.tab3);
		tabHost.addTab(tab3);

		TabSpec tab4 = tabHost.newTabSpec("��ǩҳ4");
		tab4.setIndicator("���",
				this.getResources().getDrawable(R.drawable.grid_3));
//		Intent intent4 = new Intent(this, GuiBingTab.class);
//		intent4.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//		View v4 = this.getLocalActivityManager().startActivity("1", intent4)
//				.getDecorView();
//		LinearLayout layout4 = (LinearLayout) this.findViewById(R.id.tab4);
//		layout4.removeAllViews();
//		layout4.addView(v4);
		tab4.setContent(R.id.tab4);
		tabHost.addTab(tab4);

		
		TabSpec tab5 = tabHost.newTabSpec("��ǩҳ5");
		tab5.setIndicator("����",
				this.getResources().getDrawable(R.drawable.grid_3));
		tab5.setContent(R.id.tab5);
		tabHost.addTab(tab5);

	}

}
