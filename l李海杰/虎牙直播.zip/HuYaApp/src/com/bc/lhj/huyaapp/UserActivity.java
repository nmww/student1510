package com.bc.lhj.huyaapp;

import android.app.Activity;
import android.os.Bundle;

public class UserActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_wode_layout_user);
		
	}

}
