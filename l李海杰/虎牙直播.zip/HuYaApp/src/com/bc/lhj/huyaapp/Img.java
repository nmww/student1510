package com.bc.lhj.huyaapp;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.ViewSwitcher.ViewFactory;

public class Img extends Activity implements ViewFactory{
	Handler handler;
	int num;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_img);
		init();
	}

	private void init() {
		handler = new Handler() {

			public void handleMessage(Message msg) {
				switch (msg.arg1) {
				case 0:
					GoZhuYe();
					break;
				}
			};
		};
		MyHandler();

	}

	private void GoZhuYe() {
		Intent intent = new Intent(Img.this, ViewPagerActivity.class);
		startActivity(intent);
		finish();
	}

	// ҳ��ͼƬ��ʱ����
	private void MyHandler() {

		// ������ʱ����
		Timer timer = new Timer();

		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				Message message = new Message();
				message.arg1 = 0;
				handler.sendMessage(message);
			}
		};
		timer.schedule(timerTask, 3000);
	}

	@Override
	public View makeView() {
		ImageView img = new ImageView(this);
		return img;
	}
}
