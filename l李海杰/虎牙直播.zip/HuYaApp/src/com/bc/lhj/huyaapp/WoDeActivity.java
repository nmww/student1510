package com.bc.lhj.huyaapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

/**
 * �ҵ�Activity��
 * 
 * @author Tar
 * 
 */
public class WoDeActivity extends Activity implements OnClickListener {

	LinearLayout layoutSheZhi, layoutKanGuo, layoutUser;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_wode_layout);
		init();
	}

	private void init() {
		layoutSheZhi = (LinearLayout) findViewById(R.id.layout20);//����ID
		layoutSheZhi.setOnClickListener(this);
		layoutKanGuo = (LinearLayout) findViewById(R.id.layout16);//�ҿ�����ID
		layoutKanGuo.setOnClickListener(this);
		layoutUser = (LinearLayout) findViewById(R.id.layout_q);// ������Ϣ
		layoutUser.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch(v.getId()){
		case R.id.layout20:
			Intent i1 = new Intent(WoDeActivity.this, SheZhiActivity.class);
			startActivity(i1);
			break;
			
		case R.id.layout16:
			Intent i3 = new Intent(WoDeActivity.this, KanGuoActivity.class);
			startActivity(i3);
			break;
			
		case R.id.layout_q:
			Intent i2 = new Intent(WoDeActivity.this, UserActivity.class);
			startActivity(i2);
			break;
		}
	}

}
