package com.bc.lhj.huyaapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.bc.lhj.adapter.ZhiBoGalleryAdapter;
import com.bc.lhj.adapter.ZhiBoGridViewAdapter;
import com.bc.lhj.entity.ZhiBoGalleryEntity;
import com.bc.lhj.entity.ZhiBoGridViewEntity;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;

/**
 * ֱ��Activity��
 * 
 * @author Tar
 * 
 */
public class ZhiBoActivity extends Activity implements OnItemClickListener,
		OnClickListener {

	Gallery gallery;
	List<ZhiBoGalleryEntity> datalist;
	List<ZhiBoGridViewEntity> datalist2;
	ZhiBoGalleryAdapter galleryAdapter;
	ZhiBoGridViewAdapter gridViewAdapter;
	Handler handler;
	PopupWindow popupWindow;
	int num;
	GridView gridView;
	ImageButton imgSouSuo, imgPopWindow;
	int[] ZhiBoGaleryImg = { R.drawable.q, R.drawable.qq };
	int[] ZhiBoGridViewImg = { R.drawable.grid_1, R.drawable.grid_2,
			R.drawable.grid_3, R.drawable.grid_4, R.drawable.grid_1,
			R.drawable.grid_2, R.drawable.grid_3, R.drawable.grid_4 };
	String[] ZhiBoGridViewText = { "����  ���Ӣ�ۿ� ! ~", "ؼؼStyle��     ��ʥ",
			"90065ؼ  С����", "�ڹ�:�����������", "����  ���Ӣ�ۿ� ! ~", "ؼؼStyle��     ��ʥ",
			"90065ؼ  С����", "�ڹ�:�����������" };
	int[] ZhiBoPopWindowImg = { R.drawable.p1, R.drawable.p2, R.drawable.p3,
			R.drawable.p4, R.drawable.p5, R.drawable.p6, R.drawable.p7,
			R.drawable.p8, R.drawable.p9 };
	String[] ZhiBoPopWindowText = { "����ֱ��", "������Ϸ", "�黰", "Ӣ������", "ȫ��ֱ��", "����",
			"��Խ����", "���߳�����ʿ", "�ҵ�����" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_zhibo_layout);
		initData();
	}

	private void initData() {
		gallery = (Gallery) findViewById(R.id.tab_zhibo_layout_gallery);
		addGalleryData();// ����Gallery�������ݵķ���
		galleryAdapter = new ZhiBoGalleryAdapter(this, datalist);
		gallery.setAdapter(galleryAdapter);

		gridView = (GridView) findViewById(R.id.tab_zhibo_layout_gridView);
		addGridViewData();
		gridViewAdapter = new ZhiBoGridViewAdapter(this, datalist2);
		gridView.setAdapter(gridViewAdapter);
		gridView.setOnItemClickListener(this);

		imgSouSuo = (ImageButton) findViewById(R.id.tab_zhibo_layout_gallery_imgLeft);
		imgSouSuo.setOnClickListener(this);

		imgPopWindow = (ImageButton) findViewById(R.id.tab_zhibo_layout_gallery_imgRight);
		imgPopWindow.setOnClickListener(this);

		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.arg1) {
				case 0:
					if (num < ZhiBoGaleryImg.length - 1) {
						num++;
					} else {
						num = 0;
					}
					gallery.setSelection(num);// ����GalleryͼƬ����
					break;
				}
			}
		};
		gallertTimer();

	}

	private void gallertTimer() {
		// ������ʱ����
		Timer timer = new Timer();
		// ������ʱ����
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				Message message = new Message();
				message.arg1 = 0;
				handler.sendMessage(message);
			}
		};
		// 1.�̶߳��� 2.����ʱ��. 3.���ʱ��
		timer.schedule(timerTask, 1000, 2000);
	}

	// Gallery�������ݵķ���
	private void addGalleryData() {
		datalist = new ArrayList<ZhiBoGalleryEntity>();
		for (int i = 0; i < ZhiBoGaleryImg.length; i++) {
			ZhiBoGalleryEntity zhiBoGalleryEntity = new ZhiBoGalleryEntity();
			zhiBoGalleryEntity.setImg(ZhiBoGaleryImg[i]);
			datalist.add(zhiBoGalleryEntity);
		}
	}

	// GridView�������ݵķ���
	private void addGridViewData() {
		datalist2 = new ArrayList<ZhiBoGridViewEntity>();
		for (int i = 0; i < ZhiBoPopWindowText.length; i++) {
			ZhiBoGridViewEntity zhiBoGridViewEntity = new ZhiBoGridViewEntity();
			zhiBoGridViewEntity.setImg(ZhiBoPopWindowImg[i]);
			zhiBoGridViewEntity.setText(ZhiBoPopWindowText[i]);
			datalist2.add(zhiBoGridViewEntity);
		}
	}

	// ��ȡPopupWindow������
	private void initPopWindow() {
		if (popupWindow == null) {
			getPopupWindow();// �õ�window����
		} else {
			popupWindow.dismiss();// ��ʧ
		}
	}

	// ����PopupWindow�е�����
	private void getPopupWindow() {
		View v1 = View.inflate(this, R.layout.tab_zhibo_layout_imgright_pop,
				null);
		gridView = (GridView) v1
				.findViewById(R.id.tab_zhibo_layout_gallery_imgRight_gridview);
		gridView();
		gridViewAdapter = new ZhiBoGridViewAdapter(this, datalist2);
		gridView.setAdapter(gridViewAdapter);

		popupWindow = new PopupWindow(v1, 750, 1800);
		popupWindow.setFocusable(true);// ���Ի�ý���
		popupWindow.setOutsideTouchable(true);// ������Դ���
		popupWindow.setBackgroundDrawable(new BitmapDrawable());// �������֮�������ʧ
	}

	// ��GridView�ļ�������������
	private void gridView() {
		datalist2 = new ArrayList<ZhiBoGridViewEntity>();
		for (int i = 0; i < ZhiBoPopWindowImg.length; i++) {
			ZhiBoGridViewEntity zhiBoGridViewEntity = new ZhiBoGridViewEntity();
			zhiBoGridViewEntity.setImg(ZhiBoPopWindowImg[i]);
			zhiBoGridViewEntity.setText(ZhiBoPopWindowText[i]);
			datalist2.add(zhiBoGridViewEntity);
		}
	}

	// GridView������������
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		switch (position) {
		case 0:
			Intent intent = new Intent(ZhiBoActivity.this,
					ZhiBoGridViewItem.class);
			startActivity(intent);
			break;

		case 1:
			Intent intent1 = new Intent(ZhiBoActivity.this,
					ZhiBoGridViewItem.class);
			startActivity(intent1);
			break;

		case 2:
			Intent intent2 = new Intent(ZhiBoActivity.this,
					ZhiBoGridViewItem.class);
			startActivity(intent2);
			break;

		case 3:
			Intent intent3 = new Intent(ZhiBoActivity.this,
					ZhiBoGridViewItem.class);
			startActivity(intent3);
			break;
		}
	}

	// ���Ϸ������Ϸ���ť������������
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.tab_zhibo_layout_gallery_imgLeft:
			Intent in = new Intent(ZhiBoActivity.this, SouSuoButton.class);
			startActivity(in);
			break;

		case R.id.tab_zhibo_layout_gallery_imgRight:
			initPopWindow();
			popupWindow.showAsDropDown(v, 0, -50);//����PopupWindow���ֵ�λ��(x��y)
			break;
		}
	}
}
