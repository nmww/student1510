package com.bc.lhj.huyaapp;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

/**
 * TabHost��
 * 
 * @author Tar
 * 
 */
public class TabHost_S extends TabActivity {

	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_s);

		// �̳� tabActivity���õ�tabHost
		TabHost tabhost = getTabHost();
		// �����һ��tab ������ť
		TabSpec tabSpec01 = tabhost.newTabSpec("tab1");
		// ����tab ������ť�Ĳ���
		tabSpec01.setIndicator(View.inflate(TabHost_S.this, R.layout.tab_main,
				null));
		// ������ͼ��ת
		Intent intent1 = new Intent(TabHost_S.this, ZhiBoActivity.class);
		// ���ñ����Ӧ������
		tabSpec01.setContent(intent1);
		// ���ӵ�tab��
		tabhost.addTab(tabSpec01);

		//
		TabSpec tabSpec02 = tabhost.newTabSpec("tab2");
		tabSpec02.setIndicator(View.inflate(TabHost_S.this, R.layout.tab_ludao,
				null));
		Intent intent2 = new Intent(TabHost_S.this, FaXianActivity.class);
		tabSpec02.setContent(intent2);
		tabhost.addTab(tabSpec02);

		//
		TabSpec tabSpec03 = tabhost.newTabSpec("tab31");
		tabSpec03.setIndicator(View.inflate(TabHost_S.this, R.layout.tab_class,
				null));
		Intent intent3 = new Intent(TabHost_S.this, WoDeActivity.class);
		tabSpec03.setContent(intent3);
		tabhost.addTab(tabSpec03);

	}

}
