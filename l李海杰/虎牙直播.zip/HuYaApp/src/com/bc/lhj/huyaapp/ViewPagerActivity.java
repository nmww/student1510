package com.bc.lhj.huyaapp;

import java.util.ArrayList;

import com.bc.lhj.adapter.ViewPagerAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class ViewPagerActivity extends Activity {

	ViewPager viewPager;
	ViewPagerAdapter viewPagerAdapter;
	ArrayList<ImageView> list;
	Button btn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_pager);
		init();
	}

	private void init() {
		viewPager = (ViewPager) findViewById(R.id.viewPager);
		initData();
		viewPagerAdapter = new ViewPagerAdapter(list);
		viewPager.setAdapter(viewPagerAdapter);

		viewPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				if (arg0 == 0) {
					btn.setVisibility(View.GONE);
				} else if (arg0 == 1) {
					btn.setVisibility(View.GONE);
				} else if (arg0 == 2) {
					btn.setVisibility(View.VISIBLE);
					btn = (Button) findViewById(R.id.btn);
					btn.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							Intent i = new Intent(ViewPagerActivity.this,
									TabHost_S.class);
							startActivity(i);
						}
					});
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});

		btn = (Button) findViewById(R.id.btn);
		btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent i = new Intent(ViewPagerActivity.this,
						ZhiBoActivity.class);
				startActivity(i);
			}
		});
	}

	private void initData() {
		list = new ArrayList<ImageView>();

		ImageView imageView1 = new ImageView(getApplicationContext());
		imageView1.setBackgroundResource(R.drawable.background_guidance_1);

		ImageView imageView2 = new ImageView(getApplicationContext());
		imageView2.setBackgroundResource(R.drawable.background_guidance_2);

		ImageView imageView3 = new ImageView(getApplicationContext());
		imageView3.setBackgroundResource(R.drawable.background_guidance_3);

		list.add(imageView1);
		list.add(imageView2);
		list.add(imageView3);
	}

}
