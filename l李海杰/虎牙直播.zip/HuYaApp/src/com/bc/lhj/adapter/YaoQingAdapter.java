package com.bc.lhj.adapter;

import java.util.ArrayList;

import com.bc.lhj.entity.YaoQingEntity;
import com.bc.lhj.huyaapp.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class YaoQingAdapter extends BaseAdapter {

	Context c;
	ArrayList<YaoQingEntity> datalist;

	public YaoQingAdapter(Context c, ArrayList<YaoQingEntity> datalist) {
		this.c = c;
		this.datalist = datalist;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return datalist.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		GetView gv = null;
		if (convertView == null) {
			gv = new GetView();
			convertView = View.inflate(c,
					R.layout.tab_wode_layout_yaoqing_gridview_item, null);
			gv.img = (ImageView) convertView
					.findViewById(R.id.gridview_item_img);
			gv.tv = (TextView) convertView
					.findViewById(R.id.gridview_item_text);
			convertView.setTag(gv);
		} else {
			gv = (GetView) convertView.getTag();
		}

		gv.img.setBackgroundResource(datalist.get(position).getImg());
		gv.tv.setText(datalist.get(position).getText());
		return convertView;
	}

	class GetView {
		ImageView img;
		TextView tv;
	}

}
