package com.bc.lhj.adapter;

import java.util.ArrayList;

import com.bc.lhj.entity.BangZhuListViewEntity;
import com.bc.lhj.huyaapp.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class BangZhuAdapter extends BaseAdapter {

	Context c;
	ArrayList<BangZhuListViewEntity> datalist;

	public BangZhuAdapter(Context c, ArrayList<BangZhuListViewEntity> datalist) {
		this.c = c;
		this.datalist = datalist;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return datalist.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		GetView gv = null;
		if (convertView == null) {
			gv = new GetView();
			convertView = View.inflate(c,
					R.layout.tab_wode_laayout_bangzhu_listview_item, null);
			gv.tv = (TextView) convertView
					.findViewById(R.id.bangzhu_listview_item_textview);
			gv.img = (ImageView) convertView
					.findViewById(R.id.bangzhu_listview_item_img);
			convertView.setTag(gv);
		} else {
			gv = (GetView) convertView.getTag();
		}
		
		gv.tv.setText(datalist.get(position).getText());
		gv.img.setBackgroundResource(datalist.get(position).getImg());
		return convertView;
	}

	class GetView {
		TextView tv;
		ImageView img;
	}

}
