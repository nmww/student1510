package com.bc.lhj.adapter;

import java.util.List;

import com.bc.lhj.entity.ZhiBoGalleryEntity;
import com.bc.lhj.huyaapp.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ZhiBoGalleryAdapter extends BaseAdapter {

	Context context;
	List<ZhiBoGalleryEntity> datalist;

	public ZhiBoGalleryAdapter(Context context,
			List<ZhiBoGalleryEntity> datalist) {
		this.context = context;
		this.datalist = datalist;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return datalist.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		GetView gv;
		if (convertView == null) {
			gv = new GetView();
			convertView = View.inflate(context,
					R.layout.tab_zhibo_layout_gallery_item, null);
			gv.img = (ImageView) convertView
					.findViewById(R.id.tab_zhibo_layout_gallery_img_imgView);
			convertView.setTag(gv);
		} else {
			gv = (GetView) convertView.getTag();
		}

		gv.img.setBackgroundResource(datalist.get(position).getImg());
		return convertView;
	}

	class GetView {
		ImageView img;
	}

}
