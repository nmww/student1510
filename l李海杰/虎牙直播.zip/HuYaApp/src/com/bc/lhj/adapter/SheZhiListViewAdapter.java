package com.bc.lhj.adapter;

import java.util.List;

import com.bc.lhj.entity.SheZhiListViewEntity;
import com.bc.lhj.huyaapp.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class SheZhiListViewAdapter extends BaseAdapter {

	Context c;
	List<SheZhiListViewEntity> datalist;

	public SheZhiListViewAdapter(Context c, List<SheZhiListViewEntity> datalist) {
		this.c = c;
		this.datalist = datalist;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return datalist.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		GetView gv;
		if (convertView == null) {
			gv = new GetView();
			convertView = View.inflate(c,
					R.layout.tab_wode_layout_shezhi_listview_item, null);
			gv.img = (ImageView) convertView
					.findViewById(R.id.shezhi_listview_item_img);
			gv.tvShang = (TextView) convertView
					.findViewById(R.id.shezhi_listview_item_1);
			gv.tvZhong = (TextView) convertView
					.findViewById(R.id.shezhi_listview_item_2);
			gv.tvXia = (TextView) convertView
					.findViewById(R.id.shezhi_listview_item_3);
			convertView.setTag(gv);
		} else {
			gv = (GetView) convertView.getTag();
		}

		gv.img.setBackgroundResource(datalist.get(position).getImg());
		gv.tvShang.setText(datalist.get(position).getTxtShang());
		gv.tvZhong.setText(datalist.get(position).getTxtZhong());
		gv.tvXia.setText(datalist.get(position).getTxtXia());
		return convertView;
	}

	class GetView {
		ImageView img;
		TextView tvShang, tvZhong, tvXia;
	}

}
