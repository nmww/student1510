package com.beicai.dongqiudi;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

public class ShouYe extends ActivityGroup implements OnTabChangeListener {

	private TabHost tabshou;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.shouyetab);
		//getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.title_main);
        //��ȡ��ҳ�Ĳ��ֲ�����
		tabshou = (TabHost) findViewById(R.id.shouyetab_host);
		tabshou.setup();
         //��ҳ��ť
		 TabSpec shouyeding=tabshou.newTabSpec("ͷ��");
		 shouyeding.setIndicator("ͷ��");
		 Intent intent=new Intent(this,ShouYeItem.class);
		 intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		 View viewding=this.getLocalActivityManager().startActivity("11",
		 intent).getDecorView();
		 LinearLayout shouye1=(LinearLayout)
		 this.findViewById(R.id.shouyeding);
		 shouye1.removeAllViews();
		 shouye1.addView(viewding);
		 shouyeding.setContent(R.id.shouyeding);
		 tabshou.addTab(shouyeding);
         
		 TabSpec jijin=tabshou.newTabSpec("����");
		 jijin.setIndicator("����");
		 Intent jijintent=new Intent(this,JiJin.class);
		 jijintent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		 View viewji=this.getLocalActivityManager().startActivity("12",jijintent).getDecorView();
		 LinearLayout jijinlin=(LinearLayout) this.findViewById(R.id.jijin);
		 jijinlin.removeAllViews();
		 jijinlin.addView(viewji);
		 jijin.setContent(R.id.jijin);
		 tabshou.addTab(jijin);
		
		 TabSpec zhuanti=tabshou.newTabSpec("ר��");
		 zhuanti.setIndicator("ר��");
		 Intent zhuantent=new Intent(this,ZhuanTi.class);
		 zhuantent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		 View viewzhuan=this.getLocalActivityManager().startActivity("13",
		 zhuantent).getDecorView();
		 LinearLayout zhuanlin=(LinearLayout) this.findViewById(R.id.zhuanti);
		 zhuanlin.removeAllViews();
		 zhuanlin.addView(viewzhuan);
		 zhuanti.setContent(R.id.zhuanti);
		 tabshou.addTab(zhuanti);

		tabshou.setOnTabChangedListener(this);
	}

	@Override
	public void onTabChanged(String tabId) {
		// TODO Auto-generated method stub
		Log.e("ShouYe tab host", " onTabChanged   " + tabId);

	}
}
