package com.beicai.dongqiudi;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.TabHost.TabSpec;

public class ZhiBo extends ActivityGroup {

	private TabHost zhibotabhost;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zhibotabhost);
		//��ȡ tabhost���ֲ�����
		zhibotabhost=(TabHost) findViewById(R.id.zhibo_tabhost);
		zhibotabhost.setup();
		//����������ť����������ת
		//��Ҫ
		 TabSpec zhongyao=zhibotabhost.newTabSpec("��Ҫ");
		 zhongyao.setIndicator("��Ҫ");
		 Intent zyintent=new Intent(this,ZhongYaoActivity.class);
		 zyintent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		 View viewzhong=this.getLocalActivityManager().startActivity("1", zyintent).getDecorView();
		 LinearLayout zhonglin= (LinearLayout) this.findViewById(R.id.zhongyao);
		 zhonglin.removeAllViews();
		 zhonglin.addView(viewzhong);
		 zhongyao.setContent(R.id.zhongyao);
		 zhibotabhost.addTab(zhongyao);
		//��Ŀ
		 TabSpec jiemu=zhibotabhost.newTabSpec("��Ŀ");
		 jiemu.setIndicator("��Ŀ");
		 Intent jmintent=new Intent(this,JieMuActivity.class);
		 jmintent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		 View viewjie=this.getLocalActivityManager().startActivity("1", jmintent).getDecorView();
		 LinearLayout jielin= (LinearLayout) this.findViewById(R.id.jiemu);
		 jielin.removeAllViews();
		 jielin.addView(viewjie);
		 jiemu.setContent(R.id.jiemu);
		 zhibotabhost.addTab(jiemu);
		//��ע
		 TabSpec guanzhu=zhibotabhost.newTabSpec("��ע");
		 guanzhu.setIndicator("��ע");
		 Intent gzintent=new Intent(this,GuanZhuActivity.class);
		 gzintent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		 View viewguan=this.getLocalActivityManager().startActivity("1", gzintent).getDecorView();
		 LinearLayout guanlin= (LinearLayout) this.findViewById(R.id.guanzhu);
		 guanlin.removeAllViews();
		 guanlin.addView(viewguan);
		 guanzhu.setContent(R.id.guanzhu);
		 zhibotabhost.addTab(guanzhu);
		
	}
}
