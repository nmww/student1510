package com.beicai.dongqiudi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class ZhuanTi extends Activity {


	ListView zhuantilist;
	ArrayList<Map<String,Object>> listdata;
	SimpleAdapter sadapter;
	ZhuanTiAdapter ztadapter;
	Integer[] img={R.drawable.zhuanti1,R.drawable.zhuanti2,R.drawable.zhuanti3,R.drawable.zhuanti4,};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zhuantixml);
		
		zhuantilist=(ListView) findViewById(R.id.zhuanti_list);
		getImg();
	}
	private void getImg() {
		listdata=new ArrayList<Map<String,Object>>();
		for (int i = 0; i < img.length; i++) {
			Map map=new HashMap<String, Object>();
			map.put("img", img[i]);
			listdata.add(map);
		}
		String[] from={"img"};
		int[] to={R.id.zhuanti_img};
		sadapter=new SimpleAdapter(this, listdata, R.layout.zhauntiimage, from, to);
		zhuantilist.setAdapter(sadapter);
	}
}
