package com.beicai.dongqiudi;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class GalleryAdapter extends BaseAdapter {

	Context mContext;
    Integer[] intData=null;
    
    public GalleryAdapter(Context c,Integer[] str){
    	mContext=c;
    	intData=str;
    }
	@Override
	public int getCount() {
		return intData.length;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	class ViewHoder{
		ImageView iv;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder vh=null;
		if(convertView==null){
			vh=new ViewHoder();
			convertView=View.inflate(mContext, R.layout.imgview, null);
			vh.iv=(ImageView) convertView.findViewById(R.id.iv_img);
			convertView.setTag(vh);
		}else{
			vh=(ViewHoder) convertView.getTag();
		}
		vh.iv.setImageResource(intData[position]);
		return convertView;
	}

}
