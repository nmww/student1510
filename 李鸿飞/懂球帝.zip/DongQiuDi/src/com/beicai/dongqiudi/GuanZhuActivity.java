package com.beicai.dongqiudi;

import android.app.Activity;
import android.os.Bundle;

public class GuanZhuActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.guanzhuxml);
	}
}
