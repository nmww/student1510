package com.beicai.dongqiudi;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class ShouYeTabHost extends ActivityGroup {
	private TabHost tabshou;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.shouyeactivity);
		tabshou=(TabHost) findViewById(R.id.tab_host);
		tabshou.setup();
		
		//ֱ��
				TabSpec zhibo=tabshou.newTabSpec("ֱ��");
				zhibo.setIndicator("ֱ��",this.getResources().getDrawable(R.drawable.tab2_normal));
			    Intent zhibotent=new Intent(this, ShouYeItem.class);
			    zhibotent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			    View viewzhi=this.getLocalActivityManager().startActivity("2", zhibotent).getDecorView();
			    LinearLayout zhibolin=(LinearLayout) this.findViewById(R.id.zhibo);
			    zhibolin.removeAllViews();
			    zhibolin.addView(viewzhi);
			    zhibo.setContent(R.id.zhibo);
			    tabshou.addTab(zhibo);
		
	}
}
