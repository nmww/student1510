package com.beicai.dongqiudi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.text.format.Time;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class ZhongYaoActivity extends Activity {

	ListView zhongyaolist;
	ArrayList<Map<String,Object>> listdata;
	SimpleAdapter simadapter;
	Integer[] imglist={R.drawable.zhongyao1,R.drawable.zhongyao2,R.drawable.zhongyao3,R.drawable.zhongyao4,R.drawable.zhongyao5,
			R.drawable.zhongyao6,R.drawable.zhongyao7,R.drawable.zhongyao8,R.drawable.zhongyao11,R.drawable.zhongyao10,
	};
	TextView timetv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zhongyaoxml);
		
		zhongyaolist=(ListView) findViewById(R.id.zhongyao_list);
		timetv=(TextView) findViewById(R.id.time_tv);
		getData();
		Time time=new Time("GMT+24");
		time.setToNow();
		int minute = time.minute; 
		int hour = time.hour; 
		timetv.setText(hour+":"+minute+"����");
	}
	private void getData() {
		listdata=new ArrayList<Map<String,Object>>();
		for (int i = 0; i < imglist.length; i++) {
			Map map=new HashMap<String, Object>();
			map.put("img", imglist[i]);
			listdata.add(map);
		}
		String[] from={"img"};
		int[] to={R.id.zhongyao_img};
		simadapter=new SimpleAdapter(this, listdata, R.layout.zhongyaolist, from, to);
		zhongyaolist.setAdapter(simadapter);
	}
}
