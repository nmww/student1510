package com.beicai.dongqiudi;
import java.util.ArrayList;
import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;

public class ShuJuActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shujuxml);

		initViewPager();
	}

	private void initViewPager() {
		ViewPager viewPager = (ViewPager)findViewById(R.id.viewPager);
	     
	     View view1 = LayoutInflater.from(this).inflate(R.layout.shujuxml1, null);
	     View view2 = LayoutInflater.from(this).inflate(R.layout.shujuxml2, null);
	     View view3 = LayoutInflater.from(this).inflate(R.layout.shujuxml3, null);
	     View view4 = LayoutInflater.from(this).inflate(R.layout.shujuxml4, null);
	     
	     ArrayList<View> views = new ArrayList<View>();
	     views.add(view1);
	     views.add(view2);
	     views.add(view3);
	     views.add(view4);
	     
	     ShuJuPageAdapter adapter = new ShuJuPageAdapter();
	     adapter.setViews(views);
	     viewPager.setAdapter(adapter);
		
	}
}
