package com.beicai.dongqiudi;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class ZhuCeActivity extends Activity {

	Button login, register;
	AlertDialog.Builder adb = null;
	EditText Name;
	EditText Pwd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zhucedenglu);
		// ������������˽��ƴ�����һ�ξ�ûЧ��
		View bt1 = findViewById(R.id.zhuce_bt);
		View bt2 = findViewById(R.id.denglu_bt);
		bt1.getBackground().setAlpha(50);
		bt2.getBackground().setAlpha(50);

		register = (Button) findViewById(R.id.zhuce_bt);
		register.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				adb = new AlertDialog.Builder(ZhuCeActivity.this);
				adb.setIcon(R.drawable.demo_tab_icon_contact_normal);
				adb.setTitle("ע��");

				View view = View.inflate(ZhuCeActivity.this,
						R.layout.loginregisterdialog, null);
				Name = (EditText) view.findViewById(R.id.ed_name);
				Pwd = (EditText) view.findViewById(R.id.ed_pword);
				adb.setView(view);
				adb.setNegativeButton("ע��", null);

				adb.create();
				adb.show();
			}
		});
		login = (Button) findViewById(R.id.denglu_bt);
		login.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				adb = new AlertDialog.Builder(ZhuCeActivity.this);
				adb.setIcon(R.drawable.demo_tab_icon_contact_normal);
				adb.setTitle("��¼");

				View view = View.inflate(ZhuCeActivity.this,
						R.layout.loginregisterdialog, null);
				Name = (EditText) view.findViewById(R.id.ed_name);
				Pwd = (EditText) view.findViewById(R.id.ed_pword);
				adb.setView(view);
				adb.setNegativeButton("��¼", null);
				
				adb.create();
				adb.show();

			}
		});
	}

}
