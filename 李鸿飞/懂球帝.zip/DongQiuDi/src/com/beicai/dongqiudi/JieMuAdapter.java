package com.beicai.dongqiudi;

import java.util.ArrayList;
import java.util.Map;

import com.beicai.dongqiudi.ShouYeListAdapter.ViewHolder;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class JieMuAdapter extends BaseAdapter {

	private Context mContext;
    private ArrayList<Map<String,Object>> data;
    
    public JieMuAdapter(Context context,ArrayList<Map<String,Object>> DaTa){
    	mContext=context;
    	data=DaTa;
    }
	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	static class ViewHolder{
		ImageView img;
		TextView tvName;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh=null;
		if (null==convertView) {
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.jiemu_grid, null);
			vh.img=(ImageView) convertView.findViewById(R.id.jiemu_image);
			vh.tvName=(TextView) convertView.findViewById(R.id.jiemu_name);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		vh.img.setImageResource((Integer) data.get(position).get("img"));
		vh.tvName.setText((CharSequence) data.get(position).get("txt"));
		return convertView;
	}

}
