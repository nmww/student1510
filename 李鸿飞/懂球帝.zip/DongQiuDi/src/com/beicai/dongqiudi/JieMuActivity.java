package com.beicai.dongqiudi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.SimpleAdapter;

public class JieMuActivity extends Activity {

	GridView jiemugrid;
	JieMuAdapter jiemuadapter;
	Integer[] jiemuimg = { R.drawable.shijie1, R.drawable.xijia2,
			R.drawable.stu3, R.drawable.england4, R.drawable.ouzhou5,
			R.drawable.dejia6, R.drawable.ouguan7, R.drawable.usa8,
			R.drawable.yaguan9, R.drawable.yijia10 };
	String[] name = {" ���籭","��������","��ѧ������","Ӣ������","ŷ�ޱ�","�¼�����","ŷ������","����ְҵ������","�ǹ�����","�������"};
    SimpleAdapter simadapter;
    ArrayList<Map<String,Object>> data;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.jiemuxml);

		jiemugrid = (GridView) findViewById(R.id.jiemu_grid);
		getData();
	}
	private void getData() {
		data=new ArrayList<Map<String,Object>>();
		for (int i = 0; i < jiemuimg.length; i++) {
			Map map=new HashMap<String, Object>();
			map.put("img", jiemuimg[i]);
			map.put("txt", name[i]);
			data.add(map);
		}
		String[] from={"img","txt"};
		int[] to={R.id.jiemu_image,R.id.jiemu_name};
		simadapter=new SimpleAdapter(this, data, R.layout.jiemu_grid, from, to);
		jiemugrid.setAdapter(simadapter);
	}
}
