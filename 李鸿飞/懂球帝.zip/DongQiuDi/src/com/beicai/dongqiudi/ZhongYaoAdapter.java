package com.beicai.dongqiudi;

import java.util.ArrayList;
import java.util.Map;

import com.beicai.dongqiudi.ZhuanTiAdapter.ViesHoder;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ZhongYaoAdapter extends BaseAdapter {

	Context mcontext;
	ArrayList<Map<String,Object>> datalist;
	public ZhongYaoAdapter(Context c,ArrayList<Map<String,Object>> data){
		mcontext=c;
		datalist=data;
	}
	@Override
	public int getCount() {
		return 0;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}
	class ViesHoder{
		ImageView img;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViesHoder vh=null;
		if (null==convertView) {
			vh=new ViesHoder();
			convertView=View.inflate(mcontext, R.layout.zhongyaolist, null);
			vh.img=(ImageView) convertView.findViewById(R.id.zhongyao_img);
			convertView.setTag(vh);
		}else{
			vh=(ViesHoder) convertView.getTag();
		}
		vh.img.setImageResource((Integer) datalist.get(position).get("img"));
		return convertView;
	}

}
