package com.beicai.dongqiudi;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class QuanZiExpandableAdapter extends BaseExpandableListAdapter {

	Context mContext;
	String[] GroupData=null;
	int[][] ChildData=null;
	
	public QuanZiExpandableAdapter(Context c,String[] group,int[][] Child){
		mContext=c;
		GroupData=group;
		ChildData=Child;
	}
	static class ViewHoder{
    	ImageView ivLogo;
    	TextView tvName;
    }
	@Override
	public int getGroupCount() {
		return GroupData.length;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return ChildData[groupPosition].length;
	}

	@Override
	public Object getGroup(int groupPosition) {
		return GroupData[groupPosition];
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return ChildData[groupPosition][childPosition];
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		ViewHoder vh=null;
		if(null==convertView){
			vh=new ViewHoder();
			convertView=(ViewGroup) View.inflate(mContext, R.layout.quanzigroup, null);
			vh.tvName=(TextView) convertView.findViewById(R.id.tv_group_name);
			convertView.setTag(vh);
		}else{
			vh=(ViewHoder) convertView.getTag();
		}
		vh.tvName.setText(GroupData[groupPosition]);
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		ViewHoder vh=null;
		if(null==convertView){
			vh=new ViewHoder();
			convertView=View.inflate(mContext, R.layout.quanzichild, null);
			vh.ivLogo=(ImageView) convertView.findViewById(R.id.ic_child);
			convertView.setTag(vh);
		}else{
			vh=(ViewHoder) convertView.getTag();
		}
		vh.ivLogo.setImageResource(ChildData[groupPosition][childPosition]);
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return false;
	}

}
