package com.beicai.dongqiudi;

import java.util.ArrayList;
import java.util.Map;

import com.beicai.dongqiudi.GalleryAdapter.ViewHoder;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class JiJinAdapter extends BaseAdapter {

	private Context mContext;
	private ArrayList<Map<String, Object>> data;

	public JiJinAdapter(Context c, ArrayList<Map<String, Object>> str) {
		mContext = c;
		data = str;
	}

	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	class ViewHoder {
		ImageView iv;
		TextView tv;
		ImageView imgzuo;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder vh = null;
		if (convertView == null) {
			vh = new ViewHoder();
			convertView = View.inflate(mContext, R.layout.jijinlist, null);
			vh.iv = (ImageView) convertView.findViewById(R.id.iv_jijinimg);
			vh.tv = (TextView) convertView.findViewById(R.id.tv_jijinname);
			vh.imgzuo = (ImageView) convertView.findViewById(R.id.iv_jiimg);
			convertView.setTag(vh);
		} else {
			vh = (ViewHoder) convertView.getTag();
		}
		vh.iv.setImageResource((Integer) data.get(position).get("img"));
		vh.tv.setText((CharSequence) data.get(position).get("txt"));
		vh.imgzuo.setImageResource((Integer) data.get(position).get("imgzuo"));
		return convertView;
	}

}
