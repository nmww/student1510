package com.beicai.dongqiudi;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.Toast;
import android.widget.TabHost.TabSpec;

public class ShouYeActivity extends ActivityGroup {

	private TabHost tabhost;
	private DrawerLayout mDrawerLayout = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//�����õ�������ʧ
		//this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		//���õ������ı���
		setTitle("�����");
		setContentView(R.layout.shouyeactivity);
        //���ӵ���������
		//ActionBar actionbar=getActionBar();
		//actionbar.setDisplayHomeAsUpEnabled(true);
		//��ȡtabhost�Ĳ���
		tabhost=(TabHost) findViewById(R.id.tab_host);
		tabhost.setup();
		//��ò������ӵ���¼�����ת��ÿ����Ӧ����
		TabSpec shouye=tabhost.newTabSpec("��ҳ");
		shouye.setIndicator("��ҳ", this.getResources().getDrawable(R.drawable.tab1_selected));
		Intent intent=new Intent(this,ShouYe.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View viewshou=this.getLocalActivityManager().startActivity("1", intent).getDecorView();
		LinearLayout shouye1=(LinearLayout) this.findViewById(R.id.shouye);
		shouye1.removeAllViews();
		shouye1.addView(viewshou);
		shouye.setContent(R.id.shouye);
		tabhost.addTab(shouye);
		//ֱ��
		TabSpec zhibo=tabhost.newTabSpec("ֱ��");
		zhibo.setIndicator("ֱ��",this.getResources().getDrawable(R.drawable.tab2_normal));
	    Intent zhibotent=new Intent(this, ZhiBo.class);
	    zhibotent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    View viewzhi=this.getLocalActivityManager().startActivity("2", zhibotent).getDecorView();
	    LinearLayout zhibolin=(LinearLayout) this.findViewById(R.id.zhibo);
	    zhibolin.removeAllViews();
	    zhibolin.addView(viewzhi);
	    zhibo.setContent(R.id.zhibo);
	    tabhost.addTab(zhibo);
	    //�Ӻ�
	    TabSpec jiahao=tabhost.newTabSpec("�Ӻ�");
	    jiahao.setIndicator("", this.getResources().getDrawable(R.drawable.jh));
	    Intent jiahaotent=new Intent(this, JiaHaoActivity.class);
	    jiahaotent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    View viewjia=this.getLocalActivityManager().startActivity("3", jiahaotent).getDecorView();
	    LinearLayout jiahaolin=(LinearLayout) this.findViewById(R.id.jiahao);
	    jiahaolin.removeAllViews();
	    jiahaolin.addView(viewjia);
	    jiahao.setContent(R.id.jiahao);
	    tabhost.addTab(jiahao);
	    //Ȧ��
	    TabSpec quanzi=tabhost.newTabSpec("Ȧ��");
	    quanzi.setIndicator("Ȧ��", this.getResources().getDrawable(R.drawable.tab3_normal));
	    Intent quanzitent=new Intent(this, QuanZiActivity.class);
	    quanzitent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    View viewquan=this.getLocalActivityManager().startActivity("4", quanzitent).getDecorView();
	    LinearLayout quanzilin=(LinearLayout) this.findViewById(R.id.quanzi);
	    quanzilin.removeAllViews();
	    quanzilin.addView(viewquan);
	    quanzi.setContent(R.id.quanzi);
	    tabhost.addTab(quanzi);
	    //����
	    TabSpec shuju=tabhost.newTabSpec("����");
	    shuju.setIndicator("����", this.getResources().getDrawable(R.drawable.tab4_normal));
	    Intent shujutent=new Intent(this, ShuJuActivity.class);
	    shujutent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    View viewshu=this.getLocalActivityManager().startActivity("5", shujutent).getDecorView();
	    LinearLayout shujulin=(LinearLayout) this.findViewById(R.id.shuju);
	    shujulin.removeAllViews();
	    shujulin.addView(viewshu);
	    shuju.setContent(R.id.shuju);
	    tabhost.addTab(shuju);    
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		menu.add(1,2,1,"����");
		menu.add(1,3,1,"��ϵ����");
		menu.add(1,4,1,"����");		
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
		if(item.getTitle().equals("��ϵ����")){
			Uri uri=Uri.parse("tel:15011306030");
			Intent intent=new Intent(Intent.ACTION_DIAL,uri);
			startActivity(intent);
		}else if(item.getTitle().equals("�û�")){
			Intent intent=new Intent(this, ZhuCeActivity.class);
			startActivity(intent);
		}else if(item.getTitle().equals("����")){
			Intent intent=new Intent(this, DengLuActivity.class);
			startActivity(intent);
		}else if(item.getTitle().equals("����")){
			Intent intent=new Intent(this, SetingActivity.class);
			startActivity(intent);
		}
		return super.onOptionsItemSelected(item);		
	}	
}














