package com.beicai.dongqiudi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Gallery;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class ShouYeItem extends Activity {

	Gallery gallery;
	Integer[] img = null;
	GalleryAdapter ga;
	int position=0;
	
	ListView listliebiao;
	Integer[] imgdata={R.drawable.list1,R.drawable.list2,R.drawable.list3,R.drawable.list4,R.drawable.list5,};
	String[] biaoti={"�����ʮ�����������������ϣ�������˭��һ��","������£������ɭҪȥ��������","3500��ŷ�����豨������������","���Ͱ�������Ȧ��������������ص�����","�ٷ�����ɣִ���ϸۿ�ս����FC"};
    SimpleAdapter  sadapter;
    ArrayList<Map<String,Object>> sAdapterData;
	
	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.arg1) {
			case 0:
				if (position < img.length - 1) {
					position++;
				} else {
					position = 0;
				}
				gallery.setSelection(position);
				break;
			default:
				break;
			}
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shouye);
		
		getData();
		
		listliebiao=(ListView) findViewById(R.id.lv_shoyelist);
		initAadapter();
		
		gallery=(Gallery) findViewById(R.id.gallery_img);
		ga=new GalleryAdapter(this, img);
		gallery.setAdapter(ga);
		
		Timer timer = new Timer();
		TimerTask tt = new TimerTask() {
			@Override
			public void run() {
				Message msg = new Message();
				msg.arg1 = 0;
				handler.sendMessage(msg);
			}
		};
		timer.schedule(tt, 3000, 3000);
	}
	private void initAadapter() {
		sAdapterData=new ArrayList<Map<String,Object>>();
		Map<String,Object> map=null;
		int position=0;
		for (int i = 0; i < imgdata.length; i++) {
			map=new HashMap<String, Object>();			
				map.put("img", imgdata[i]);
				map.put("text",biaoti[i]);							
			    sAdapterData.add(map);
		
		}
		String[] from={"img","text"};
		int[] to={R.id.iv_imgfang,R.id.tv_namefang};
	    sadapter=new SimpleAdapter(this, sAdapterData, R.layout.shouyeimglist, from, to);
	    listliebiao.setAdapter(sadapter);
		
	}
	private void getData() {
		img=new Integer[]{R.drawable.lun1,R.drawable.lun2,R.drawable.lun3};
	}
}
