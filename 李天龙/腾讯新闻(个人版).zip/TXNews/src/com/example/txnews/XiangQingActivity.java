package com.example.txnews;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

public class XiangQingActivity extends Activity implements OnClickListener{
	
	PopupWindow popupwindow;
	ImageView  popupbtn;
	Button  qxbtn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.xiangqing_layout);
		
		initView();
		
		initpopupwindow();
	}
	
	

	private void initpopupwindow() {
		
		if(popupwindow==null){
			getPopupWindow();
		}else{
			popupwindow.dismiss();
		}
		
		
	}
	private void initView() {
		popupbtn= (ImageView) findViewById(R.id.xq_image3);
		popupbtn.setOnClickListener(this);
		
	}
	private void getPopupWindow() {
		View v=View.inflate(this, R.layout.ppwindow_layout, null);
		qxbtn=(Button) v.findViewById(R.id.qx_btn);
		qxbtn.setOnClickListener(this);
		
		popupwindow =new PopupWindow(v, 700, 400);
		
		popupwindow.setFocusable(true);//���Ի�ý���
		
		
	}
	@Override
	public void onClick(View v) {
		
		switch (v.getId()) {
		case R.id.xq_image3 :
			
			popupwindow.showAtLocation(v, Gravity.CENTER, 0, 400);
			break;
		case R.id.qx_btn :
			
			popupwindow.dismiss();
			break;
		default:
			break;
		}
	}

}
