package com.example.txnews;

import com.example.adapter.ReDianAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReDianActivity extends Activity {
	
	ImageButton imagebtn;
	GridView rdGrid;
	ReDianAdapter myAdapter;
	
	int[] resData={R.drawable.rd_image1,R.drawable.rd_image2,R.drawable.rd_image3,
				   R.drawable.rd_image4,R.drawable.rd_image5,R.drawable.rd_image6};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.redian_layout);
		
		rdGrid=(GridView) findViewById(R.id.rd_grid);
		
		myAdapter=new ReDianAdapter(this, resData);
		
		rdGrid.setAdapter(myAdapter);
		
		imagebtn=(ImageButton) findViewById(R.id.rd_btn02);
		
		imagebtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(ReDianActivity.this, DingYueGuanLiActivity.class);
				
				startActivity(intent);
				
			}
		});
	}

}
