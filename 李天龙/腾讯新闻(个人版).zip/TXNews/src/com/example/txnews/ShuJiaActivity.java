package com.example.txnews;

import com.example.adapter.ShuJiaAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

public class ShuJiaActivity extends Activity {
	
	GridView sjGrid;
	ShuJiaAdapter myAdapter;
	
	int[] resData={R.drawable.xs1,R.drawable.xs2,R.drawable.xs3,R.drawable.xs4,R.drawable.xs5,R.drawable.xs6,
				   R.drawable.xs7,R.drawable.xs8,R.drawable.xs9,R.drawable.xs10,R.drawable.xs11,R.drawable.xs12,
				   R.drawable.xs13,R.drawable.xs14,R.drawable.xs15};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.shujia_layout);
		
		sjGrid=(GridView) findViewById(R.id.sj_gridview);
		
		myAdapter=new ShuJiaAdapter(this, resData);
		
		sjGrid.setAdapter(myAdapter);
		
	}

}
