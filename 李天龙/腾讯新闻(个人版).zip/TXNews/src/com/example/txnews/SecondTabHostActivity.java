package com.example.txnews;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class SecondTabHostActivity extends ActivityGroup {
	
	TabHost tabHost1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.srcondtabhost_layout);
		tabHost1=(TabHost) this.findViewById(R.id.second_tabhost);
		
		tabHost1.setup();
		
		//���õڶ���ҳ����ĵ�һ����ǩ
		TabSpec tabSpec001=tabHost1.newTabSpec("��ǩ1");
		
		tabSpec001.setIndicator("", this.getResources().getDrawable(R.drawable.tabbookcity));
		
		Intent intent001=new Intent(this,BookActivity.class);
		
		intent001.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		
		View view001=this.getLocalActivityManager().startActivity("01",intent001 ).getDecorView();
	        
	    LinearLayout layout001=(LinearLayout) findViewById(R.id.bookcity_layout);
	        
	    layout001.removeAllViews();
	        
	    layout001.addView(view001);
	        
	    tabSpec001.setContent(R.id.bookcity_layout);
	        
	    tabHost1.addTab(tabSpec001);
	    
	    
	  //���õڶ���ҳ����ĵ�һ����ǩ
	  	TabSpec tabSpec002=tabHost1.newTabSpec("��ǩ2");
	  		
	  	tabSpec002.setIndicator("", this.getResources().getDrawable(R.drawable.tabshujia));
	  		
	  	Intent intent002=new Intent(this,ShuJiaActivity.class);
	  		
	  	intent002.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	  		
	  	View view002=this.getLocalActivityManager().startActivity("02",intent002 ).getDecorView();
	  	        
	    LinearLayout layout002=(LinearLayout) findViewById(R.id.mybook_layout);
	  	        
	  	layout002.removeAllViews();
	  	        
	  	layout002.addView(view002);
	  	        
	  	tabSpec002.setContent(R.id.mybook_layout);
	  	        
	  	tabHost1.addTab(tabSpec002);
		
		
	}

}
