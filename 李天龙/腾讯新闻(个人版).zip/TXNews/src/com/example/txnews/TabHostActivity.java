package com.example.txnews;



import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

public class TabHostActivity extends ActivityGroup implements OnTabChangeListener {
	
	TabHost tabHost;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.tabhost_layout);
		
		tabHost=(TabHost) this.findViewById(R.id.first_tabhost);
		
		tabHost.setup();
		
		//���õ�һ����ǩ
		TabSpec tabSpec01=tabHost.newTabSpec("��ǩ1");
		
		tabSpec01.setIndicator("", this.getResources().getDrawable(R.drawable.news));
		
		Intent intent01=new Intent(this,NewsActivity.class);
		
		intent01.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		
		View view01=this.getLocalActivityManager().startActivity("1",intent01 ).getDecorView();
	        
	    LinearLayout layout01=(LinearLayout) findViewById(R.id.news_layout);
	        
	    layout01.removeAllViews();
	        
	    layout01.addView(view01);
	        
	    tabSpec01.setContent(R.id.news_layout);
	        
	    tabHost.addTab(tabSpec01);
	    
	    //���õڶ�����ǩ
	    TabSpec tabSpec02=tabHost.newTabSpec("��ǩ2");
		
		tabSpec02.setIndicator("", this.getResources().getDrawable(R.drawable.book));
		
		Intent intent02=new Intent(this,SecondTabHostActivity.class);
		
		intent02.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		
		View view02=this.getLocalActivityManager().startActivity("2",intent02 ).getDecorView();
	        
	    LinearLayout layout02=(LinearLayout) findViewById(R.id.books_layout);
	        
	    layout02.removeAllViews();
	        
	    layout02.addView(view02);
	        
	    tabSpec02.setContent(R.id.books_layout);
	        
	    tabHost.addTab(tabSpec02);
	    
	    //���õ�������ǩ
		
	    TabSpec tabSpec03=tabHost.newTabSpec("��ǩ3");
		
		tabSpec03.setIndicator("", this.getResources().getDrawable(R.drawable.care));
		
		Intent intent03=new Intent(this,ThreeTabHostActivity.class);
		
		intent03.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		
		View view03=this.getLocalActivityManager().startActivity("3",intent03 ).getDecorView();
	        
	    LinearLayout layout03=(LinearLayout) findViewById(R.id.care_layout);
	        
	    layout03.removeAllViews();
	        
	    layout03.addView(view03);
	        
	    tabSpec03.setContent(R.id.care_layout);
	        
	    tabHost.addTab(tabSpec03);
		
	}
	@Override
	public void onTabChanged(String tabId) {
		
		
	}

}
