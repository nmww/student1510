package com.example.txnews;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class UserActivity extends Activity {
	
	ImageView userimage;
	ImageView userimage1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.user_layout);
		
		userimage=(ImageView) findViewById(R.id.user_shoucang);
		
		userimage.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent01=new Intent(UserActivity.this,ShouCangActivity.class );
				
				startActivity(intent01);
				
			}
		});
		
		userimage1=(ImageView) findViewById(R.id.user_gengduo);
		
		userimage1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent02=new Intent(UserActivity.this,SheZhiActivity.class );
				
				startActivity(intent02);
			}
		});
	}

}
