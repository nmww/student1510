package com.example.adapter;

import java.util.ArrayList;

import com.example.entity.DYGuanLiEntity;
import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class DYGuanLiRightAdapter extends BaseAdapter {

	Context mContext;
	ArrayList<DYGuanLiEntity> resData;
	
	
	
	public DYGuanLiRightAdapter(Context mContext,
			ArrayList<DYGuanLiEntity> resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.dyguanli_listview_item2, null);
			
			vh.gl_image=(ImageView) convertView.findViewById(R.id.gl_item2_image1);
			vh.gl_text1=(TextView) convertView.findViewById(R.id.gl_item2_text1);
			vh.gl_text2=(TextView) convertView.findViewById(R.id.gl_item2_text2);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder) convertView.getTag();
			
		}
			vh.gl_image.setImageResource(resData.get(position).getImage());
			vh.gl_text1.setText(resData.get(position).getText1());
			vh.gl_text2.setText(resData.get(position).getText2());
			
		
		
		return convertView;
	}
	
	class ViewHolder{
		ImageView gl_image;
		TextView gl_text1;
		TextView gl_text2;
		
	}
}
