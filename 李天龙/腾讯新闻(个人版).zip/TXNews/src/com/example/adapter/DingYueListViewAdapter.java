package com.example.adapter;

import java.util.ArrayList;

import com.example.entity.DingYueEntity;
import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class DingYueListViewAdapter extends BaseAdapter {
	
	Context mContext;
	ArrayList<DingYueEntity> resData;
	
	
	
	
	public DingYueListViewAdapter(Context mContext,
			ArrayList<DingYueEntity> resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			
			convertView=View.inflate(mContext, R.layout.dingyue_listview_item, null);
			
			vh.text1=(TextView) convertView.findViewById(R.id.dy_itemtext);
			vh.text2=(TextView) convertView.findViewById(R.id.dy_itemtext1);
			vh.image=(ImageView) convertView.findViewById(R.id.dy_itemimage);
			convertView.setTag(vh);
			
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		
		
		vh.text1.setText((CharSequence) resData.get(position).getText1());
		vh.text2.setText((CharSequence) resData.get(position).getText2());
		vh.image.setImageResource((Integer) resData.get(position).getImage());
		
		
		return convertView;
	}

	class ViewHolder{
		TextView text1;
		TextView text2;
		ImageView image;
		
	}
}
