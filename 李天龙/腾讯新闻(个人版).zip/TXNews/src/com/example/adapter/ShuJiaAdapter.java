package com.example.adapter;

import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ShuJiaAdapter extends BaseAdapter {

	Context mContext;
	int[] resData;
	
	public ShuJiaAdapter(Context mContext, int[] resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.shujia_gridview_item, null);
			
			vh.sjImage=(ImageView) convertView.findViewById(R.id.sj_item_image);
			
			convertView.setTag(vh);
			
			
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		
		vh.sjImage.setImageResource(resData[position]);
		
		
		return convertView;
	}
	
	class ViewHolder{
		
		ImageView  sjImage;
	}
}
