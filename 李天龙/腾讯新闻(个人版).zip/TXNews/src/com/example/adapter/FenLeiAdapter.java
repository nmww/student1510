package com.example.adapter;

import java.util.ArrayList;

import com.example.entity.FenLeiEntity;
import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class FenLeiAdapter extends BaseAdapter {

	Context mContext;
	ArrayList<FenLeiEntity> resDate;

	public FenLeiAdapter(Context mContext, ArrayList<FenLeiEntity> resDate) {
		super();
		this.mContext = mContext;
		this.resDate = resDate;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resDate.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resDate.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			
			convertView=View.inflate(mContext, R.layout.fenlei_listview_item, null);
			
			vh.image=(ImageView) convertView.findViewById(R.id.fl_item_image);
			vh.text1=(TextView) convertView.findViewById(R.id.fl_item_text);
			vh.text2=(TextView) convertView.findViewById(R.id.fl_item_text1);
			convertView.setTag(vh);
			
		}else{
			vh=(ViewHolder) convertView.getTag();
			
		}
		
		vh.image.setImageResource(resDate.get(position).getImage());
		vh.text1.setText(resDate.get(position).getText());
		vh.text2.setText(resDate.get(position).getText1());
		
		return convertView;
	}
	class ViewHolder{
		ImageView image;
		TextView text1;
		TextView text2;
		
	}
}
