package com.example.adapter;

import java.util.ArrayList;

import com.example.entity.ShouYeEntity;
import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ShouYeAdapter extends BaseAdapter {

	Context mContext;
	ArrayList<ShouYeEntity> resData;
	
	
	
	public ShouYeAdapter(Context mContext, ArrayList<ShouYeEntity> resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			
			convertView=View.inflate(mContext, R.layout.shouye_listview_item, null);
			vh.iv_image=(ImageView) convertView.findViewById(R.id.sy_image);
			vh.tv_text=(TextView) convertView.findViewById(R.id.sy_text);
			vh.tv_text1=(TextView) convertView.findViewById(R.id.sy_text1);
			convertView.setTag(vh);
		}else{
			
			vh=(ViewHolder) convertView.getTag();
		}
		
		vh.iv_image.setImageResource((Integer) resData.get(position).getImage());
		vh.tv_text.setText((CharSequence) resData.get(position).getText1());
		vh.tv_text1.setText((CharSequence) resData.get(position).getText2());
		
		
		
		return convertView;
	}
	class ViewHolder{
		ImageView iv_image;
		TextView tv_text;
		TextView tv_text1;
	}

}
