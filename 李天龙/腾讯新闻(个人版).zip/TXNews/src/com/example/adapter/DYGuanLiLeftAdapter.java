package com.example.adapter;

import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class DYGuanLiLeftAdapter extends BaseAdapter {
	
	Context mContext;
	String[] resData;

	public DYGuanLiLeftAdapter(Context mContext, String[] resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			
			convertView=View.inflate(mContext, R.layout.dyguanli_listview_item1, null);
			
			vh.gltext=(TextView) convertView.findViewById(R.id.gl_item1_text);
			
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder) convertView.getTag();
			
		}
		
		
		vh.gltext.setText(resData[position]);
		return convertView;
	}

  class	ViewHolder{
	  TextView gltext;
  }
}
