package com.example.adapter;

import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class DingYueGalleryAdapter extends BaseAdapter {

	Context mContext;
	int[] resData=null;
	
	
	public DingYueGalleryAdapter(Context mContext, int[] resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.dingyue_gallery_item, null);
			
			vh.dyimage=(ImageView) convertView.findViewById(R.id.iv_image);
			
			convertView.setTag(vh);
			
		}else{
			vh=(ViewHolder) convertView.getTag();
		}
		
		vh.dyimage.setImageResource(resData[position]);
		
		return convertView;
	}

	class ViewHolder{
		
		ImageView dyimage;
	}
}
