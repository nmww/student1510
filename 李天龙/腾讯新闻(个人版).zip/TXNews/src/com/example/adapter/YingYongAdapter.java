package com.example.adapter;

import java.util.ArrayList;

import com.example.entity.YingYongEntity;
import com.example.txnews.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class YingYongAdapter extends BaseAdapter {
	
	Context mContext;
	ArrayList<YingYongEntity> resData;
	
	

	public YingYongAdapter(Context mContext, ArrayList<YingYongEntity> resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder vh=null;
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.yy_listview_item, null);
			
			vh.image1=(ImageView) convertView.findViewById(R.id.yy_item_image1);
			vh.text1=(TextView) convertView.findViewById(R.id.yy_item_text1);
			vh.text2=(TextView) convertView.findViewById(R.id.yy_item_text2);
			vh.text3=(TextView) convertView.findViewById(R.id.yy_item_text3);
			
			convertView.setTag(vh);
			
		}else{
			vh=(ViewHolder) convertView.getTag();
			
		}
		
		vh.image1.setImageResource(resData.get(position).getImage1());
		vh.text1.setText(resData.get(position).getText1());
		vh.text2.setText(resData.get(position).getText2());
		vh.text3.setText(resData.get(position).getText3());
		
		
		return convertView;
	}

	
	class ViewHolder{
		
		ImageView image1;
		TextView text1;
		TextView text2;
		TextView text3;
	}
}
