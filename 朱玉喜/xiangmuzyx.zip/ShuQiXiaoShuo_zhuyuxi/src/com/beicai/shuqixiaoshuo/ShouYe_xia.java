package com.beicai.shuqixiaoshuo;

import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class ShouYe_xia extends ActivityGroup {
	private TabHost myTabHost2;
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	this.requestWindowFeature(Window.FEATURE_NO_TITLE);
	//02
		setContentView(R.layout.shouye_tabhost_xia);
		myTabHost2 = (TabHost) findViewById(R.id.tabhost_shouye_xia);
		myTabHost2.setup();
		//���
		TabSpec tabSpec001 = myTabHost2.newTabSpec("��ǩ01");
		tabSpec001.setIndicator("���", this.getResources().getDrawable(R.drawable.icon_mainbottom_item1_d));
		Intent intent001 = new Intent(this, ShuJia_01.class);
		intent001.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View view001=this.getLocalActivityManager().startActivity("01", intent001).getDecorView();
		LinearLayout layout001 = (LinearLayout) findViewById(R.id.shujia_xia);
		layout001.removeAllViews();
		layout001.addView(view001);
		tabSpec001.setContent(R.id.shujia_xia);
		myTabHost2.addTab(tabSpec001);
		//����
		TabSpec tabSpec002 = myTabHost2.newTabSpec("��ǩ02");
		tabSpec002.setIndicator("����", this.getResources().getDrawable(R.drawable.icon_mainbottom_item2_d));
		Intent intent002 = new Intent(this, ShouYe.class);
		intent002.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View view002=this.getLocalActivityManager().startActivity("02", intent002).getDecorView();
		LinearLayout layout002 = (LinearLayout) findViewById(R.id.sousuo_xia);
		layout002.removeAllViews();
		layout002.addView(view002);
		tabSpec002.setContent(R.id.sousuo_xia);
		myTabHost2.addTab(tabSpec002);
		//���
		TabSpec tabSpec003 = myTabHost2.newTabSpec("��ǩ03");
		tabSpec003.setIndicator("���", this.getResources().getDrawable(R.drawable.icon_mainbottom_item3_d));
		Intent intent003 = new Intent(this, ShuCheng_02.class);
		intent003.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View view003=this.getLocalActivityManager().startActivity("03", intent003).getDecorView();
		LinearLayout layout003 = (LinearLayout) findViewById(R.id.shucheng_xia);
		layout003.removeAllViews();
		layout003.addView(view003);
		tabSpec003.setContent(R.id.shucheng_xia);
		myTabHost2.addTab(tabSpec003);
		//�ҵ�
		TabSpec tabSpec004 = myTabHost2.newTabSpec("��ǩ04");
		tabSpec004.setIndicator("�ҵ�", this.getResources().getDrawable(R.drawable.icon_mainbottom_item4_d));
		Intent intent004 = new Intent(this, WoDe_03.class);
		intent004.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View view004=this.getLocalActivityManager().startActivity("04", intent004).getDecorView();
		LinearLayout layout004 = (LinearLayout) findViewById(R.id.wode_xia);
		layout004.removeAllViews();
		layout004.addView(view004);
		tabSpec004.setContent(R.id.wode_xia);
		myTabHost2.addTab(tabSpec004);
		
		myTabHost2.setCurrentTab(1);
		
}
}
