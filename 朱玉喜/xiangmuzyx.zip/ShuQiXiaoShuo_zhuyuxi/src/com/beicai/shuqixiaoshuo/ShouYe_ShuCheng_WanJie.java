package com.beicai.shuqixiaoshuo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.ImageView;

public class ShouYe_ShuCheng_WanJie extends Activity {
	ImageView img;
	//=================
	GridView gvImage;//��������
	ShouYe_shucheng_wanjie_MyAdapter myAdapter;
	Integer[] imageData = { R.drawable.gallery_001, 
			R.drawable.gallery_002,
			R.drawable.gallery_003,
			R.drawable.gallery_004,
			R.drawable.gallery_005, 
			R.drawable.gallery_006,
			 };
@Override
protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.shouye_shucheng_wanjie);
	img=(ImageView) findViewById(R.id.iv_shucheng_wanjie);
	img.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent init=new Intent(ShouYe_ShuCheng_WanJie.this,ShouYe_xia.class);
			startActivity(init);
			
		}
	});
	//=========
	gvImage=(GridView) findViewById(R.id.gv_image_shucheng_wanjie);
	myAdapter=new ShouYe_shucheng_wanjie_MyAdapter(this, imageData);//��������������
	gvImage.setAdapter(myAdapter);
}
}
