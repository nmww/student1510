package com.beicai.shuqixiaoshuo;

import com.beicai.shuqixiaoshuo.view.Image3DSwitchView;
import com.beicai.shuqixiaoshuo.view.Image3DView;
import com.beicai.shuqixiaoshuo.view.Image3DSwitchView.OnImageSwitchListener;


import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.TextView;

public class ShuJia_01 extends Activity {
	Image3DSwitchView im;
	Image3DView imChild;

@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.shouye_shujia);

	imChild = (Image3DView) findViewById(R.id.image1);
	
	im = (Image3DSwitchView) findViewById(R.id.image_switch_view);
	im.setOnImageSwitchListener(new OnImageSwitchListener() {
		
		@Override
		public void onImageSwitch(int currentImage) {
			
			Log.e("setOnImageSwitchListener", "setOnImageSwitchListener");
		}
	});
	

	
}



}
