package com.beicai.shuqixiaoshuo;



import java.util.Timer;
import java.util.TimerTask;





import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewSwitcher.ViewFactory;

public class ShouYe_shouye extends Activity implements ViewFactory{
	//==============================GridView
	GridView gvImage;//��������
	ShouYe_GridView_MyAdapter myAdapter;
	Integer[] imageData = { R.drawable.gallery_01, 
			R.drawable.gallery_02,
			R.drawable.gallery_03,
			R.drawable.gallery_04,
			R.drawable.gallery_05, 
			R.drawable.gallery_06,
			 };
	
	//==============================Gallery
	Integer[] img = null;
	Gallery gallery;
	ShouYe_Gellery garradapter;
	int position = 0;

	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.arg1) {
			case 0:
				if (position < img.length - 1) {
					position++;
				} else {
					position = 0;
				}
				gallery.setSelection(position);
				break;
			default:
				break;
			}
		};
	};
@Override
protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.shouye_shouye);
	getData();

	gallery = (Gallery) findViewById(R.id.garrlery_view);
	garradapter = new ShouYe_Gellery(this, img);
	gallery.setAdapter(garradapter);

	Timer timer = new Timer();
	TimerTask tt = new TimerTask() {
		@Override
		public void run() {
			Message msg = new Message();
			msg.arg1 = 0;
			handler.sendMessage(msg);
		}
	};
	timer.schedule(tt, 2000, 2000);
	//================================GridView
	gvImage=(GridView) findViewById(R.id.gv_image);
	myAdapter=new ShouYe_GridView_MyAdapter(this, imageData);//��������������
	gvImage.setAdapter(myAdapter);
}

private void getData() {
	img = new Integer[] { R.drawable.lunbo, R.drawable.lunbo_02,
			R.drawable.lunbo, R.drawable.lunbo_02};
	
}

@Override
public View makeView() {
	ImageView iv = new ImageView(this);
	return iv;
}
}
