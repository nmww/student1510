package com.beicai.shuqixiaoshuo;



import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.Toast;

public class WoDeYeMian_shezhi extends Activity implements OnClickListener{
	ImageView sz;
	
	ImageView gengxin;//dialog
	AlertDialog.Builder dialog;
	
	PopupWindow popupWindow;// �Զ����������
	ImageView ivpopup;// ��ʾwindow�İ�ť
	
	private void getPopuW() {
		// ��xml������䵽��ǰ��view������
		View pView = View.inflate(getApplication(), R.layout.shezhi_popupwindows, null);
		popupWindow = new PopupWindow(pView, 710, 500);// ����window����
		popupWindow.setFocusable(true);// ���Ի�ý���
		popupWindow.setBackgroundDrawable(new BitmapDrawable());// �������֮�������ʧ
		popupWindow.setOutsideTouchable(true);// ������Դ���

	}
	
	
@Override
protected void onCreate(Bundle savedInstanceState) {
	
	super.onCreate(savedInstanceState);
	setContentView(R.layout.wodeyemian_shezhi);
	getPopuW();
	ivpopup=(ImageView) findViewById(R.id.iv_popupwindows);
	ivpopup.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);
		}
	});
	
	gengxin=(ImageView) findViewById(R.id.wode_shezhi_gengxin);
	gengxin.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			dialog=new AlertDialog.Builder(WoDeYeMian_shezhi.this);
			dialog.setIcon(R.drawable.notification_icon);
			dialog.setTitle("����и���!");
			dialog.setMessage("ȷ���Ƿ����");
			dialog.setNegativeButton("����", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					
				}
			});
			dialog.setPositiveButton("������", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					
				}
			});
			dialog.create();
			dialog.show();
		}
	});
	
	//=======================
	sz=(ImageView) findViewById(R.id.shezhi_shezhi);
	sz.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent in=new Intent(WoDeYeMian_shezhi.this,ShouYe_xia.class);
			startActivity(in);
		}
	});
}
@Override
public boolean onCreateOptionsMenu(Menu menu) {
	menu.add(1, 2, 1, "����");
	menu.add(1, 3, 1, "Ӧ��");
	SubMenu submenu = menu.addSubMenu(2, 4, 1, "����");
	submenu.add(2, 1, 1, "����С˵");
	submenu.add(2, 2, 1, "V9.7.0.31");
	submenu.add(2, 3, 1, "�绰��757848");
	SubMenu submenu2 = menu.addSubMenu(3, 4, 1, "����");
	submenu2.add(3, 1, 1, "����");
	submenu2.add(3, 2, 1, "����");
	submenu2.add(3, 3, 1, "ɫ��");
	return true;
}

@Override
public boolean onOptionsItemSelected(MenuItem item) {
	Log.e("", "item==" + item.getItemId());
	Toast.makeText(getApplicationContext(), "" + item.getItemId(),
			Toast.LENGTH_LONG).show();

	return super.onOptionsItemSelected(item);
}
@Override
public void onClick(View v) {
	// TODO Auto-generated method stub
	
}




}
