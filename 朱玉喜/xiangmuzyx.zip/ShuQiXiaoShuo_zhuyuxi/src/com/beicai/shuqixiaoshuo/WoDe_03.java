package com.beicai.shuqixiaoshuo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class WoDe_03 extends Activity {
	ImageView iv,iv2,shezhi,denglu;
	
@Override
protected void onCreate(Bundle savedInstanceState) {
	
	super.onCreate(savedInstanceState);
	setContentView(R.layout.shouye_wodeyemian);
	iv=(ImageView) findViewById(R.id.wodepinglun);
	iv.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent in=new Intent(WoDe_03.this,WoDeYeMian_wodepinglun.class);
			startActivity(in);
			
		}
	});
	iv2=(ImageView) findViewById(R.id.wodeshoucang);
	iv2.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent in=new Intent(WoDe_03.this,WoDeYeMian_wodeshoucang.class);
			startActivity(in);
			
		}
	});
	shezhi=(ImageView) findViewById(R.id.shezhi_iv);
	shezhi.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent in=new Intent(WoDe_03.this,WoDeYeMian_shezhi.class);
			startActivity(in);
			
		}
	});
	denglu=(ImageView) findViewById(R.id.denglu_001);
	denglu.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent in=new Intent(WoDe_03.this,WoDeYeMian_wodedenglu.class);
			startActivity(in);
			
		}
	});
}
}
