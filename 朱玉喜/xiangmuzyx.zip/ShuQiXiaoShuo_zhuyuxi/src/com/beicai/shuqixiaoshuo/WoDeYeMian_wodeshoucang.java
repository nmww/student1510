package com.beicai.shuqixiaoshuo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;

public class WoDeYeMian_wodeshoucang extends Activity {
	protected static final String TAG = "MainActivity";
	ImageView iv;
	Spinner spinner;
	SimpleAdapter adapter;//����������
	ArrayList<Map<String, Object>> list;
@Override
protected void onCreate(Bundle savedInstanceState) {
	
	super.onCreate(savedInstanceState);
	setContentView(R.layout.wodeyemian_wodeshoucang);
	spinner = (Spinner) findViewById(R.id.sp_listtable);
	phoneSpinner();
	
	
	
	
	
	iv=(ImageView) findViewById(R.id.wodeshoucang_iv);
	iv.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
Intent in=new Intent(WoDeYeMian_wodeshoucang.this,ShouYe_xia.class);
startActivity(in);
			
		}
	});
}
private void phoneSpinner() {
	//��ʼ����Դ
	list=new ArrayList<Map<String,Object>>();
	//����1
	Map<String ,Object> map1=new HashMap<String, Object>();
	map1.put("txt", "̫������");
	map1.put("img", R.drawable.taigushenwang);
	list.add(map1);
	//����2
		Map<String ,Object> map2=new HashMap<String, Object>();
		map2.put("txt", "��������");
		map2.put("img", R.drawable.wanmeishijie);
		list.add(map2);
		//����3
		Map<String ,Object> map3=new HashMap<String, Object>();
		map3.put("txt", "������");
		map3.put("img", R.drawable.dazhuzai);
		list.add(map3);
		
		String[] from={"txt","img"};
		int[] to={R.id.tv_spinner_name,R.id.iv_spinner_img};
		//������Դ���ӵ�������
		adapter=new SimpleAdapter(getApplication(),list,R.layout.wodeyemian_wodeshoucang_spinner_item,from,to);
		spinner.setAdapter(adapter);
		// ���õ���¼�
		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				Map m = (Map) adapter.getItem(position);
				Log.e(TAG, "txt=" + m.get("txt"));
				Log.e(TAG, "img=" + m.get("img"));
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
		});
}
}
















