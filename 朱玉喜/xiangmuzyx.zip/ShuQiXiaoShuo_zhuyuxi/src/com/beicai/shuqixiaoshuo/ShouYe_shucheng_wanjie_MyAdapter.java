package com.beicai.shuqixiaoshuo;

import com.beicai.shuqixiaoshuo.ShouYe_GridView_MyAdapter.ViewHodler;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ShouYe_shucheng_wanjie_MyAdapter extends BaseAdapter {
	Context mContext;//�����Ķ���
	Integer[] imageData=null;//ͼƬ������Դ
	public ShouYe_shucheng_wanjie_MyAdapter (Context context,Integer[] imgdata){
		mContext=context;
		imageData=imgdata;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return imageData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return imageData[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class ViewHodler{
		ImageView ivImage;//����ͼƬ����
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// �ĵ���ͼ����
				ViewHodler viewHodler=null;
				if(null==convertView){
					viewHodler=new ViewHodler();
					convertView=View.inflate(mContext, R.layout.shouye_gridview_shucheng_wanjie_item, null);
					viewHodler.ivImage=(ImageView) convertView.findViewById(R.id.gridview_shucheng_wanjie);
					convertView.setTag(viewHodler);
					
				}else{
					viewHodler=(ViewHodler) convertView.getTag();
					
				}
				viewHodler.ivImage.setImageResource(imageData[position]);
				
				return convertView;
	}

}
