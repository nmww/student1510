package com.beicai.shuqixiaoshuo;



import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.TabHost.TabSpec;

public class ShouYe extends ActivityGroup {
	private TabHost myTabHost;
	EditText et;
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	

	//01
	setContentView(R.layout.shouye_tabhost);
	et=(EditText) findViewById(R.id.et_edittext);
	et.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent in=new Intent(ShouYe.this,ShouYe_SouSuo.class);
			startActivity(in);
			
		}
	} );
	
	
	
	
	myTabHost = (TabHost) findViewById(R.id.tabhost_shouye);
	myTabHost.setup();
	//��ҳ
			TabSpec tabSpec01 = myTabHost.newTabSpec("��ǩ1");
			tabSpec01.setIndicator("��ҳ");
			Intent intent01 = new Intent(this, ShouYe_shouye.class);
			intent01.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			View view01 = this.getLocalActivityManager()
					.startActivity("1", intent01).getDecorView();
			LinearLayout layout01 = (LinearLayout) findViewById(R.id.shouye);
			layout01.removeAllViews();
			layout01.addView(view01);
			tabSpec01.setContent(R.id.shouye);
			myTabHost.addTab(tabSpec01);
			//����
			TabSpec tabSpec02 = myTabHost.newTabSpec("��ǩ2");
			tabSpec02.setIndicator("����");
			Intent intent02 = new Intent(this, ShouYe_fenlei.class);
			intent02.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			View view02 = this.getLocalActivityManager()
					.startActivity("2", intent02).getDecorView();
			LinearLayout layout02 = (LinearLayout) findViewById(R.id.fenlei);
			layout02.removeAllViews();
			layout02.addView(view02);
			tabSpec02.setContent(R.id.fenlei);
			myTabHost.addTab(tabSpec02);
			//�鵥
			TabSpec tabSpec03 = myTabHost.newTabSpec("��ǩ3");
			tabSpec03.setIndicator("�鵥");
			Intent intent03 = new Intent(this, ShouYe_shudan.class);
			intent03.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			View view03 = this.getLocalActivityManager()
					.startActivity("3", intent03).getDecorView();
			LinearLayout layout03 = (LinearLayout) findViewById(R.id.shudan);
			layout03.removeAllViews();
			layout03.addView(view03);
			tabSpec03.setContent(R.id.shudan);
			myTabHost.addTab(tabSpec03);
			
			
			
}
}
