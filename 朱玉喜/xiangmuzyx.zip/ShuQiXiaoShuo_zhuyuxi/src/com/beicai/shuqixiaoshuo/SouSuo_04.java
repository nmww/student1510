package com.beicai.shuqixiaoshuo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class SouSuo_04 extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		TextView tv = new TextView(this);
		setContentView(tv);
	}
}
