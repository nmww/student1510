package com.beicai.shuqixiaoshuo;

import java.util.ArrayList;
import java.util.Map;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ShouYe_FenLei_MyAdater extends BaseAdapter {
	Context mContext;
	ArrayList<Map<String,Object>> datalist;
public ShouYe_FenLei_MyAdater(Context context,ArrayList<Map<String,Object>> data){
	mContext=context;
	datalist=data;
}
//������������
	@Override
	public int getCount() {
		
		return datalist.size();
	}
//���λ��
	@Override
	public Object getItem(int position) {
	
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh=new ViewHolder();
		if(convertView==null){
			convertView=View.inflate(mContext, R.layout.shouye_fenlei_item, null);
			vh.imgView=(ImageView) convertView.findViewById(R.id.iv_logo);
			vh.tvName2= (TextView) convertView.findViewById(R.id.tv_name2);
			vh.tvName= (TextView) convertView.findViewById(R.id.tv_name);
			
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder)convertView.getTag();
		}
		vh.imgView.setImageResource((Integer) datalist.get(position).get("img"));
		vh.tvName2.setText((CharSequence)datalist.get(position).get("txt2"));
		vh.tvName.setText((CharSequence)datalist.get(position).get("txt"));
		
		return convertView;
	}
class ViewHolder{
	ImageView imgView;

	TextView tvName;
	TextView tvName2;
}
}
