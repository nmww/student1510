package com.beicai.shuqixiaoshuo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

public class ShouYe_shudan extends Activity {
	ListView lvlist;//�������
	ArrayList<Map<String,Object>> resDate;//���ݼ���
	ShouYe_ShuDan_MyAdapter myAdater;//����������
	
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.shouye_shudan);
	getRes();
	//������
	lvlist = (ListView) findViewById(R.id.lv_listview_02);
	myAdater=new ShouYe_ShuDan_MyAdapter(ShouYe_shudan.this, resDate);
	lvlist.setAdapter(myAdater);//��ֵ
	
}

private void getRes() {
	resDate=new ArrayList<Map<String,Object>>();
	for (int i = 0; i <4; i++) {
		Map m=new HashMap<String, Object>();
		switch(i){
		case 0:
			m.put("img",R.drawable.listview_01);
			break;
		case 1:
			m.put("img", R.drawable.listview_02);
			break;
		case 2:
			m.put("img", R.drawable.listview_03);
			break;
		case 3:
			m.put("img", R.drawable.listview_04);
			break;
		}
		resDate.add(m);
	}
	
}
}
