package com.beicai.shuqixiaoshuo;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ShouYe_Gellery extends BaseAdapter {
	Context mContext;
	Integer[] inData = null;

	public ShouYe_Gellery(Context c, Integer[] str) {
		mContext = c;
		inData = str;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return inData.length;
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	class ViewHolder {
		ImageView iv;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder viewHolder = null;
		if (convertView == null) {
			viewHolder = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.shouye_gallery, null);
			viewHolder.iv = (ImageView) convertView
					.findViewById(R.id.garrel_img);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		viewHolder.iv.setImageResource(inData[position]);
		return convertView;
	}

}
