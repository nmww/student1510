package com.beicai.shuqixiaoshuo;

import java.util.ArrayList;
import java.util.Map;

import com.beicai.shuqixiaoshuo.ShouYe_FenLei_MyAdater.ViewHolder;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ShouYe_ShuDan_MyAdapter extends BaseAdapter {

	Context mContext;
	ArrayList<Map<String,Object>> datalist;
public ShouYe_ShuDan_MyAdapter(Context context,ArrayList<Map<String,Object>> data){
	mContext=context;
	datalist=data;
}
//������������
	@Override
	public int getCount() {
		
		return datalist.size();
	}
//���λ��
	@Override
	public Object getItem(int position) {
	
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh=new ViewHolder();
		if(convertView==null){
			convertView=View.inflate(mContext, R.layout.shouye_shudan_item, null);
			vh.imgView=(ImageView) convertView.findViewById(R.id.iv_shudan_img);
			
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder)convertView.getTag();
		}
		vh.imgView.setImageResource((Integer) datalist.get(position).get("img"));
		
		
		return convertView;
	}
class ViewHolder{
	ImageView imgView;

	
}

}
