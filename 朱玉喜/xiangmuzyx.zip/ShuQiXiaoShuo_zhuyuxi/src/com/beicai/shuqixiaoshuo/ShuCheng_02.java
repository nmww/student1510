package com.beicai.shuqixiaoshuo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ShuCheng_02 extends Activity {
	Button btn_paihang;
	Button btn_wanjie;
@Override
protected void onCreate(Bundle savedInstanceState) {
	
	super.onCreate(savedInstanceState);
	setContentView(R.layout.shouye_shucheng);
	btn_wanjie=(Button) findViewById(R.id.btn_wanjie);
	btn_wanjie.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent init=new Intent(ShuCheng_02.this,ShouYe_ShuCheng_WanJie.class);
			startActivity(init);
			
		}
	});
	btn_paihang=(Button) findViewById(R.id.btn_paihang);
	btn_paihang.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent init=new Intent(ShuCheng_02.this,ShouYe_ShuCheng_PaiHang.class);
			startActivity(init);
			
		}
	});
}
}
