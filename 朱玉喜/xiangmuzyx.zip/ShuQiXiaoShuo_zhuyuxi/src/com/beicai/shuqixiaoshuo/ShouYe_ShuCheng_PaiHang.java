package com.beicai.shuqixiaoshuo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class ShouYe_ShuCheng_PaiHang extends Activity {
ImageView ivImg;	
@Override
protected void onCreate(Bundle savedInstanceState) {
	
	super.onCreate(savedInstanceState);
	setContentView(R.layout.shouye_shucheng_paihang);
	ivImg=(ImageView) findViewById(R.id.iv_paihang_dianhuiqu);
	ivImg.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent intent=new Intent(ShouYe_ShuCheng_PaiHang.this,ShouYe_xia.class);
			startActivity(intent);
		}
	});
}
}
