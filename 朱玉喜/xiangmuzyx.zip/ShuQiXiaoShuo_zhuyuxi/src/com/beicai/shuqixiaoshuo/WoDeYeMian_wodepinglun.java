package com.beicai.shuqixiaoshuo;



import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RatingBar.OnRatingBarChangeListener;

public class WoDeYeMian_wodepinglun extends Activity {
	ImageView iv;
	RatingBar ratingBartrue;
	TextView tv;
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.wodeyemian_wodepinglun);
	iv=(ImageView) findViewById(R.id.pinglun_iv);
	iv.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent in=new Intent(WoDeYeMian_wodepinglun.this,ShouYe_xia.class);
			startActivity(in);
			
		}
	});
	tv=(TextView) findViewById(R.id.tv_xingxing);
	ratingBartrue=(RatingBar) findViewById(R.id.rb_ratingbar2);
	ratingBartrue.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
		
		@Override
		public void onRatingChanged(RatingBar arg0, float arg1, boolean arg2) {
			
			switch((int)arg1){
			case 1:
				tv.setText("����������:�ǳ�������");
				tv.setTextColor(Color.RED);
				break;
			case 2:
				tv.setText("����������:������");
				tv.setTextColor(Color.RED);
				break;
			case 3:
				tv.setText("����������:һ��");
				tv.setTextColor(Color.RED);
				break;
			case 4:
				tv.setText("����������:����");
				tv.setTextColor(Color.RED);
				break;	
			case 5:
				tv.setText("����������:�ǳ�����");
				tv.setTextColor(Color.RED);
				break;

			}
			
			
		}
	});
}
}
