package com.beicai.shuqixiaoshuo;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ShouYe_GridView_MyAdapter extends BaseAdapter {
Context mContext;//�����Ķ���
Integer[] imageData=null;//ͼƬ������Դ



public ShouYe_GridView_MyAdapter (Context context,Integer[] imgdata){
	mContext=context;
	imageData=imgdata;
}
	@Override
	public int getCount() {//�������
		// TODO Auto-generated method stub
		return imageData.length;
	}

	@Override
	public Object getItem(int position) {//��õ�ǰ����
		// TODO Auto-generated method stub
		return imageData[position];
	}

	@Override
	public long getItemId(int position) {//�õ���ǰ����ID
		// TODO Auto-generated method stub
		return 0;
	}
class ViewHodler{
	ImageView ivImage;//����ͼƬ����
}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// �ĵ���ͼ����
		ViewHodler viewHodler=null;
		if(null==convertView){
			viewHodler=new ViewHodler();
			convertView=View.inflate(mContext, R.layout.shouye_gridview_item, null);
			viewHodler.ivImage=(ImageView) convertView.findViewById(R.id.gv_item);
			convertView.setTag(viewHodler);
			
		}else{
			viewHodler=(ViewHodler) convertView.getTag();
			
		}
		viewHodler.ivImage.setImageResource(imageData[position]);
		
		return convertView;
	}

}
