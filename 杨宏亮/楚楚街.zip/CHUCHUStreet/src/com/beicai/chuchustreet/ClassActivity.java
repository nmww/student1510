package com.beicai.chuchustreet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.beicai.chuchustreet.adapter.GrideViewAdapter;
import com.example.chuchustreet.R;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;

public class ClassActivity extends Activity {
	GridView grideview;
	ArrayList<Map<String,Object>>  arraylist;
	GrideViewAdapter gv_adapter;
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.class_layout);
		grideview=(GridView) findViewById(R.id.gv_class);
		getValues();
		gv_adapter=new GrideViewAdapter(ClassActivity.this,arraylist);
		grideview.setAdapter(gv_adapter);
	}
	private void getValues() {
		// TODO Auto-generated method stub
		arraylist=new ArrayList<Map<String, Object>>();
		for(int i=0;i<18;i++){
			Map<String, Object> map=new HashMap<String, Object>();
			if(i==0){
				map.put("img", R.drawable.class_01);
				map.put("txt_one", "����Ůװ");
				map.put("txt_two", "ֱ���׶�ʱ��");
				
			}else if(i==1){
				map.put("img", R.drawable.class_02);
				map.put("txt_one", "����");
				map.put("txt_two", "��Ϯ������");			
			}else if(i==2){
				map.put("img", R.drawable.class_03);
				map.put("txt_one", "��Ь");
				map.put("txt_two", "ŷ�͵��ۿ۵�Ʒ");
			}else if(i==3){
				map.put("img", R.drawable.class_04);
				map.put("txt_one", "���");
				map.put("txt_two", "���հ�������");
			}else if(i==4){
				map.put("img", R.drawable.class_05);
				map.put("txt_one", "��װ");
				map.put("txt_two", "ŷ����ʱ��");
			}else if(i==5){
				map.put("img", R.drawable.class_06);
				map.put("txt_one", "����");
				map.put("txt_two", "���Ը��»�");
			}else if(i==6){
				map.put("img", R.drawable.class_07);
				map.put("txt_one", "����");
				map.put("txt_two", "��ҫ�ۿۼ�");
			}else if(i==7){
				map.put("img", R.drawable.class_08);
				map.put("txt_one", "�˹�����");
				map.put("txt_two", "���ܰ�����");
			}else if(i==8){
				map.put("img", R.drawable.class_09);
				map.put("txt_one", "����");
				map.put("txt_two", "��ɧ�ĵͼ�");
			}else if(i==9){
				map.put("img", R.drawable.class_10);
				map.put("txt_one", "Ůװ");
				map.put("txt_two", "���ҵ�Ů��");
			}else if(i==10){
				map.put("img", R.drawable.class_11);
				map.put("txt_one", "Ůװ");
				map.put("txt_two", "���ҵ�Ů��");
			}else if(i==11){
				map.put("img", R.drawable.class_12);
				map.put("txt_one", "��ʿ����");
				map.put("txt_two", "������װ");
			}else if(i==12){
				map.put("img", R.drawable.class_13);
				map.put("txt_one", "ʳƷ");
				map.put("txt_two", "�Գ���ʱ��");
			}else if(i==13){
				map.put("img", R.drawable.class_14);
				map.put("txt_one", "ĸӤ");
				map.put("txt_two", "��һ�ۻ�");
			}else if(i==14){
				map.put("img", R.drawable.class_15);
				map.put("txt_one", "�ҵ�");
				map.put("txt_two", "������ܰ����");
			}
			else if(i==15){
				map.put("img", R.drawable.class_16);
				map.put("txt_one", "Ů��");
				map.put("txt_two", "�ż��ϵ�ʱ��");
			}else if(i==16){
				map.put("img", R.drawable.class_17);
				map.put("txt_one", "������Ʒ");
				map.put("txt_two", "�������");
			}else if(i==17){
				map.put("img", R.drawable.class_18);
				map.put("txt_one", "Ů��ĵ�");
				map.put("txt_two", "�󲨶�������");
			}
			
			arraylist.add(map);
			
		}
	}
}
