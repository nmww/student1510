package com.beicai.chuchustreet;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;



import com.example.chuchustreet.R;

public class LoadActivity extends Activity {
	TextView tv_view;
	String changetime[] = {"�����У�0", "�����У�20%", "�����У�40%", "�����У�60%", "�����У�80%",
			"�����У�100%" };
	int position = 0;
	Handler hand = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.arg1) {
			case 0:
				if(position<changetime.length){
				tv_view.setText(changetime[position]);
				}
				position++;
				break;
				
			default:
				break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.laod_layout);
		tv_view = (TextView) findViewById(R.id.tv_txt);
		Timer timer = new Timer();
		TimerTask timertask = new TimerTask() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Message msg = new Message();
				msg.arg1 = 0;
				hand.sendMessage(msg);
			}
		};
		position++;
		timer.schedule(timertask, 0,1000);
		  new Handler().postDelayed(new Runnable() {			
				@Override
				public void run() {
					
					// TODO Auto-generated method stub
					Intent intent=new Intent(LoadActivity.this,WelcomeActivity.class);
					startActivity(intent);
					LoadActivity.this.finish();
				}
			}, 4500);
	}

}
