package com.beicai.chuchustreet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.beicai.chuchustreet.adapter.SetListViewAdapter;
import com.example.chuchustreet.R;

public class SetActivity extends Activity implements View.OnClickListener {
	PopupWindow popupWindow;
	Button btn_friend;// ����
	Button btn_close;// �رյ���
	Button btn_back;
	ListView listview;
	ArrayList<Map<String, Object>> arraylist;
	SetListViewAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.set_layout);
		listview = (ListView) findViewById(R.id.set_list);
		getResults();
		adapter = new SetListViewAdapter(this, arraylist);
		listview.setAdapter(adapter);

		btn_back = (Button) findViewById(R.id.set_back);
		btn_back.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				SetActivity.this.finish();
			}
		});

		initView();
		initPopWindow();
	}

	private void initView() {
		// TODO Auto-generated method stub
		btn_friend = (Button) findViewById(R.id.set_friend);// ��������
		btn_friend.setOnClickListener(this);
	}

	private void initPopWindow() {
		if (popupWindow == null) {
			getPopuW();// �õ�window����

		} else {
			popupWindow.dismiss();// ��ʧ
		}
	}

	private void getPopuW() {
		// TODO Auto-generated method stub
		View pView = View.inflate(getApplication(), R.layout.friend_layout,
				null);
		btn_close = (Button) pView.findViewById(R.id.close_pop);
		TextView tv = (TextView) pView.findViewById(R.id.friend_text);
		ImageView ewm = (ImageView) pView.findViewById(R.id.img_ewm);
		ImageView qq = (ImageView) pView.findViewById(R.id.img_qq);
		ImageView qzone = (ImageView) pView.findViewById(R.id.img_qzone);
		ImageView wx = (ImageView) pView.findViewById(R.id.img_wx);
		ImageView friend = (ImageView) pView.findViewById(R.id.img_cycle);
		btn_close.setOnClickListener(this);
		popupWindow = new PopupWindow(pView,  LayoutParams.WRAP_CONTENT,  LayoutParams.WRAP_CONTENT);//
		popupWindow.setFocusable(true);  
		popupWindow.setOutsideTouchable(true);// ������Դ���

	}

	private void getResults() {
		// TODO Auto-generated method stub
		arraylist = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < 8; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			if (i == 0) {
				map.put("txt", "�����Ż���Ϣ");
				map.put("img", R.drawable.yes);
			} else if (i == 1) {
				map.put("txt", "��Ϣ����");
				map.put("img", R.drawable.yes);
			} else if (i == 2) {
				map.put("txt", "����");
				map.put("img", R.drawable.yes);
			} else if (i == 3) {
				map.put("txt", "��");
				map.put("img", R.drawable.yes);
			} else if (i == 4) {
				map.put("txt", "������");
				map.put("img", R.drawable.arrow_right);
			} else if (i == 5) {
				map.put("txt", "��������");
				map.put("img", R.drawable.arrow_right);
			} else if (i == 6) {
				map.put("txt", "��������");
				map.put("img", R.drawable.arrow_right);
			} else if (i == 7) {
				map.put("txt", "�������������ʹ��Э��");
				map.put("img", R.drawable.arrow_right);
			}
			arraylist.add(map);
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.set_friend:
			popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);
			backgroundAlpha(0.3f); 
			
			break;
		case R.id.close_pop:
			
			popupWindow.dismiss();
			backgroundAlpha(1f); 
			
			break;
		default:
			break;
		}
	}

	public void backgroundAlpha(float bgAlpha){ 
		
	        WindowManager.LayoutParams lp = getWindow().getAttributes();  
	        lp.alpha =bgAlpha; 
	                getWindow().setAttributes(lp);  
	    }
	

}
