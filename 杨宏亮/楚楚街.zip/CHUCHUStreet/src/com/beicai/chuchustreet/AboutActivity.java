package com.beicai.chuchustreet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.beicai.chuchustreet.adapter.AboutAdapter;
import com.example.chuchustreet.R;

public class AboutActivity extends Activity {
	ImageView back;
	ListView listview;
	AboutAdapter aboutadapter;
	ArrayList<Map<String, Object>> list;

	@Override
	protected void onCreate(android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about_our);
		listview = (ListView) findViewById(R.id.about_listview);
		back =  (ImageView) findViewById(R.id.about_back);
		getResults();
		aboutadapter = new AboutAdapter(AboutActivity.this, list);
		listview.setAdapter(aboutadapter);
		back.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(AboutActivity.this,TabHostActivity.class);
				startActivity(intent);
				AboutActivity.this.finish();
			}
		});
		listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				if (position ==0) {
					Toast.makeText(getApplicationContext(), "�Ѿ������°汾", 1000)
							.show();
				}else if(position==1){
					Toast.makeText(getApplicationContext(), "��ע�ɹ�", 1000)
					.show();
				}else if(position==2){
					Toast.makeText(getApplicationContext(), "�Ҳ�������", 1000)
					.show();
				}
			}
		});

	}

	private void getResults() {
		// TODO Auto-generated method stub
		list = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < 3; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			if (i == 0) {
				map.put("txt", "�汾����");
				map.put("img", R.drawable.set_update);
				map.put("imgview", R.drawable.arrow_right);
			} else if (i == 1) {
				map.put("txt", "��ע������");
				map.put("img", R.drawable.chuchujie);
				map.put("imgview", R.drawable.arrow_right);
			} else if (i == 2) {
				map.put("txt", "�Ƽ�Ӧ�ø�����");
				map.put("img", R.drawable.personal_recommend);
				map.put("imgview", R.drawable.arrow_right);
			}
			list.add(map);
		}
	}
}
