package com.beicai.chuchustreet;

import java.util.ArrayList;

import com.example.chuchustreet.R;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

public class ViewPageActivity extends Activity {
	ViewPager viewpager;
	ArrayList<ImageView> list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_page);
		viewpager = (ViewPager) findViewById(R.id.img_background);
		initlist();
		viewpager.setAdapter(new MyAdapter());

	}

	private void initlist() {
		// TODO Auto-generated method stub
		list = new ArrayList<ImageView>();
		ImageView img = new ImageView(this);
		img.setBackgroundResource(R.drawable.view_page1);
		list.add(img);

		ImageView img1 = new ImageView(this);
		img1.setBackgroundResource(R.drawable.view_page2);
		list.add(img1);

		ImageView img2 = new ImageView(this);
		img2.setBackgroundResource(R.drawable.view_page3);
		list.add(img2);
		img2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//Toast.makeText(getApplicationContext(), "mmmm", 1000).show();
				Intent intent=new Intent(ViewPageActivity.this,LoadActivity.class);
				startActivity(intent);
				ViewPageActivity.this.finish();
			}
		});
	}

	class MyAdapter extends PagerAdapter {
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return list.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0==arg1;
		}

		public Object instantiateItem(ViewGroup container, int position) {

			container.addView(list.get(position));
			return list.get(position);
		}

		// ��viewpagerɾ��һ����Ŀ����
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View) object);
		}

	}

}
