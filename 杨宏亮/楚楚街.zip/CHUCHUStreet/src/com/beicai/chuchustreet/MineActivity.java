package com.beicai.chuchustreet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.beicai.chuchustreet.adapter.MineListViewAdapter;
import com.beicai.chuchustreet.img.ImageYuanJiao;
import com.example.chuchustreet.R;

public class MineActivity extends Activity {
	ImageView person;
	ImageView iv_set;
	ImageView iv_collection;// �ղ�
	ImageView iv_shopping;// ���ﳵ
	Button btn_login;
	Button btn_register;
	ListView list_view;
	ArrayList<Map<String, Object>> arraylist;
	MineListViewAdapter mine_adapter;
	ImageView iv_sex;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mine_layout);

		list_view = (ListView) findViewById(R.id.mine_list);
		iv_collection = (ImageView) findViewById(R.id.mine_save);
		iv_shopping = (ImageView) findViewById(R.id.mine_shopping);
		btn_login = (Button) findViewById(R.id.mine_login);
		person = (ImageView) findViewById(R.id.mine_person);
		btn_register = (Button) findViewById(R.id.mine_register);
		iv_set = (ImageView) findViewById(R.id.mine_set);
		getResults();
		mine_adapter = new MineListViewAdapter(MineActivity.this, arraylist);
		list_view.setAdapter(mine_adapter);
		btn_login.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MineActivity.this,
						LoginActivity.class);
				startActivity(intent);
			}
		});
		iv_set.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MineActivity.this, SetActivity.class);
				startActivity(intent);
			}
		});
		btn_register.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MineActivity.this,
						RegisterActivity.class);
				startActivity(intent);
			}
		});
		iv_collection.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MineActivity.this,
						CollectionActivity.class);
				startActivity(intent);
			}
		});
		iv_shopping.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MineActivity.this,
						ShoppingCarActivity.class);
				startActivity(intent);
			}
		});
		person.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
			    intent.addCategory(Intent.CATEGORY_OPENABLE);
			    intent.setType("image/*");
			    intent.putExtra("crop", "true");
			    intent.putExtra("aspectX", 1);
			    intent.putExtra("aspectY", 1);
			    intent.putExtra("outputX", 80);
			    intent.putExtra("outputY", 80);
			    intent.putExtra("return-data", true);

			    startActivityForResult(intent, 0);
				
			}
		});
		list_view.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				if (position == 0 || position == 2 || position == 3) {
					Toast.makeText(getApplicationContext(), "�㻹δ��¼", 1000)
							.show();

				} else if (position == 4) {
					Toast.makeText(getApplicationContext(), "�����뷴��", 1000)
							.show();

				} else if (position == 5) {
					Toast.makeText(getApplicationContext(), "�ҵ�Ͷ��", 1000)
							.show();

				}

			}
		});
	}

	private void getResults() {
		// TODO Auto-generated method stub
		arraylist = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < 7; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			if (i == 0) {
				map.put("txt", "ȫ������");
				map.put("img", R.drawable.arrow_right);

			} else if (i == 1) {
				map.put("txt", "�Ա�ѡ��");
				map.put("img", R.drawable.switch_sex_boy);

			} else if (i == 2) {
				map.put("txt", "�ҵĻ���");
				map.put("img", R.drawable.arrow_right);
			} else if (i == 3) {
				map.put("txt", "�ҵıʼ�");
				map.put("img", R.drawable.arrow_right);
			} else if (i == 4) {
				map.put("txt", "�����뷴��");
				map.put("img", R.drawable.arrow_right);
			} else if (i == 5) {
				map.put("txt", "�ҵ�Ͷ��");
				map.put("img", R.drawable.arrow_right);
			} else if (i == 6) {
				map.put("txt", "�Ƽ�Ӧ�ø�����");
				map.put("img", R.drawable.arrow_right);
			}
			arraylist.add(map);
		}

	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		  System.out.println(resultCode);
		 
		  try {
			Bitmap cameraBitmap = (Bitmap) data.getExtras().get("data");
			  super.onActivityResult(requestCode, resultCode, data);
			  
			  ImageView ivLogo=(ImageView) findViewById(R.id.mine_person);
				//Bitmap btUserLogo=ImageYuanJiao.drawableToBitmap(getResources().getDrawable(R.drawable.user_head));
			  cameraBitmap=ImageYuanJiao.toRoundCorner(cameraBitmap, 1000);
				Drawable draimage=ImageYuanJiao.bitmapToDrawble(cameraBitmap, this);
				ivLogo.setBackgroundDrawable(draimage);

			    	Drawable drawable =new BitmapDrawable(cameraBitmap);
				  person.setBackgroundDrawable(drawable);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		 }



}
