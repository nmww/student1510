package com.beicai.chuchustreet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.chuchustreet.R;

public class LoginActivity extends Activity {
	Button btn_close;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_layout);
		btn_close=(Button) findViewById(R.id.close_login);
		btn_close.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//Intent intent=new Intent(LoginActivity.this,TabHostActivity.class);
				//startActivity(intent);
				LoginActivity.this.finish();
			}
		});
	}
}
