package com.beicai.chuchustreet.adapter;

import java.util.ArrayList;
import java.util.Map;

import com.beicai.chuchustreet.adapter.MineListViewAdapter.ViewHolder;
import com.example.chuchustreet.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AboutAdapter extends BaseAdapter {

	Context mContext;
	ArrayList<Map<String, Object>> list;

	public AboutAdapter(Context context,
			ArrayList<Map<String, Object>> ar_list) {
		mContext = context;
		list = ar_list;

	}

	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	class ViewHolder {
		TextView tvName;
		ImageView imgView;
		ImageView imgview;
	}

	ViewHolder vh = null;
	int i = 0;

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		if (convertView == null) {
			vh = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.about_listview, null);
			vh.imgView = (ImageView) convertView.findViewById(R.id.img_about);
			vh.tvName = (TextView) convertView.findViewById(R.id.txt_about);
			vh.imgview=(ImageView) convertView.findViewById(R.id.img_about_two);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();

		}

		vh.imgView.setBackgroundResource((Integer) list.get(position)
				.get("img"));

		vh.tvName.setText((CharSequence) list.get(position).get("txt"));
		vh.imgview.setBackgroundResource((Integer) list.get(position)
				.get("imgview"));
		return convertView;
		

	}
}
