package com.beicai.chuchustreet.adapter;

import java.util.ArrayList;
import java.util.Map;

import com.example.chuchustreet.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class GrideViewAdapter extends BaseAdapter {

	Context mContext;
	ArrayList<Map<String, Object>> list;

	public GrideViewAdapter(Context context, ArrayList<Map<String, Object>> ar_list) {
		mContext = context;
		list = ar_list;

	}
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	class ViewHolder {
		TextView tvName;
		TextView tvname;
		ImageView imgView;
		
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh =null; 
		if(convertView==null){
			vh=new ViewHolder();
			convertView=View.inflate(mContext, R.layout.class_gridview, null);
			vh.imgView=(ImageView) convertView.findViewById(R.id.iv_image_view);
			vh.tvName=(TextView) convertView.findViewById(R.id.tv_txt);
			vh.tvname=(TextView) convertView.findViewById(R.id.tv_txtview);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolder) convertView.getTag();
			
		}
	
		vh.imgView.setImageResource((Integer)list.get(position).get("img"));
		vh.tvName.setText((CharSequence)list.get(position).get("txt_one"));
		vh.tvname.setText((CharSequence)list.get(position).get("txt_two"));
		
		return convertView;
	}

	
}
