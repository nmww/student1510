package com.beicai.chuchustreet.adapter;



import com.example.chuchustreet.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;

public class GarrleryAdapter extends BaseAdapter {

	
	Context mContext;
	Integer[] imgre = null;
	public GarrleryAdapter(Context c, Integer[] str) {
		mContext = c;
		imgre = str;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return imgre.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class ViewHolder {
		ImageView iv;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder viewHolder = null;
		if (convertView == null) {
			viewHolder = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.gallery, null);
			viewHolder.iv = (ImageView) convertView.findViewById(R.id.iv_image);
			convertView.setTag(viewHolder);
		}else{
			viewHolder = (ViewHolder) convertView.getTag();
		}
		viewHolder.iv.setLayoutParams(new Gallery.LayoutParams(Gallery.LayoutParams.FILL_PARENT,Gallery.LayoutParams.FILL_PARENT));
		
		viewHolder.iv.setImageResource(imgre[position]);
		return convertView;


	}
	

}
