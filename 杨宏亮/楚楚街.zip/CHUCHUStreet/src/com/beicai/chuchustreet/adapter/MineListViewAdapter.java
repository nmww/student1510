package com.beicai.chuchustreet.adapter;

import java.util.ArrayList;
import java.util.Map;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.chuchustreet.R;

public class MineListViewAdapter extends BaseAdapter {

	Context mContext;
	ArrayList<Map<String, Object>> list;

	public MineListViewAdapter(Context context,
			ArrayList<Map<String, Object>> ar_list) {
		mContext = context;
		list = ar_list;

	}

	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	class ViewHolder {
		TextView tvName;
		ImageView imgView;

	}

	ViewHolder vh = null;
	int i = 0;

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		if (convertView == null) {
			vh = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.mine_listview, null);
			vh.imgView = (ImageView) convertView.findViewById(R.id.image_view);
			vh.tvName = (TextView) convertView.findViewById(R.id.text_view);

			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();

		}

		vh.imgView.setBackgroundResource((Integer) list.get(position)
				.get("img"));

		vh.tvName.setText((CharSequence) list.get(position).get("txt"));

		if (position == 1) {
			vh.imgView.setOnClickListener(new View.OnClickListener() {

				public void onClick(View v) {
					i++;
					if (i % 2 == 0) {

						v.setBackgroundResource(R.drawable.switch_sex_boy);
					} else {
						v.setBackgroundResource(R.drawable.switch_sex_girl);
					}

				}

			});

		}
		return convertView;

	}
}
