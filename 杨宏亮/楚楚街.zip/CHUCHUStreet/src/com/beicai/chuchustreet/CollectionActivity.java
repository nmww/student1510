package com.beicai.chuchustreet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.chuchustreet.R;

public class CollectionActivity extends Activity {
	ImageView iv_back;
	Button btn_find;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_collection);
		iv_back=(ImageView) findViewById(R.id.collect_back);
		btn_find=(Button) findViewById(R.id.collec_go_find);
		iv_back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CollectionActivity.this.finish();
			}
		});
		btn_find.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(CollectionActivity.this,TabHostActivity.class);
				startActivity(intent);
			}
		});
	}
}
