package com.beicai.chuchustreet;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.example.chuchustreet.R;

public class WelcomeActivity extends Activity {
	ImageButton btn_boy;
	ImageButton btn_girl;
	ImageButton btn_student;
	ImageButton btn_freshman;
	ImageButton btn_freejib;
	ImageButton btn_worker;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);
		btn_boy = (ImageButton) findViewById(R.id.boy);
		btn_girl = (ImageButton) findViewById(R.id.girl);
		btn_student = (ImageButton) findViewById(R.id.student);
		btn_freshman = (ImageButton) findViewById(R.id.freshman);
		btn_freejib = (ImageButton) findViewById(R.id.freejob);
		btn_worker = (ImageButton) findViewById(R.id.worker);
		// �������ͷ��Ч��
		btn_boy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				btn_boy.setBackgroundResource(R.drawable.sex_choice_boy_pressed);
				btn_girl.setBackgroundResource(R.drawable.sex_choice_girl_normal);
			}
		});
		// ���Ů��ͷ��Ч��
		btn_girl.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				btn_boy.setBackgroundResource(R.drawable.sex_choice_boy_normal);
				btn_girl.setBackgroundResource(R.drawable.sex_choice_girl_pressed);
			}
		});
		// ���ְҵ������������תҳ��
		btn_student.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				btn_student
						.setBackgroundResource(R.drawable.occupation_student_checked);
				Intent intent=new Intent(WelcomeActivity.this,TabHostActivity.class);
				startActivity(intent);
				WelcomeActivity.this.finish();
			}
		});

		btn_freshman.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				btn_freshman
						.setBackgroundResource(R.drawable.occupation_freshman_checked);
				Intent intent=new Intent(WelcomeActivity.this,TabHostActivity.class);
				startActivity(intent);
				WelcomeActivity.this.finish();
			}
		});

		btn_freejib.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				btn_freejib
						.setBackgroundResource(R.drawable.occupation_freejob_checked);
				Intent intent=new Intent(WelcomeActivity.this,TabHostActivity.class);
				startActivity(intent);
				WelcomeActivity.this.finish();
			}
		});
		btn_worker.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				btn_worker
						.setBackgroundResource(R.drawable.occupation_worker_checked);
				Intent intent=new Intent(WelcomeActivity.this,TabHostActivity.class);
				startActivity(intent);
				WelcomeActivity.this.finish();
			}
		});
	}

}
