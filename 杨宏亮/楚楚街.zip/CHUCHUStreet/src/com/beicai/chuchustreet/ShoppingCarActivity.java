package com.beicai.chuchustreet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.chuchustreet.R;

public class ShoppingCarActivity extends Activity {
	ImageView iv_back;
	ImageView iv_home;
	Button btn_shopping;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shoppingcar);
		iv_back=(ImageView) findViewById(R.id.shopping_back);
		iv_home=(ImageView) findViewById(R.id.shopping_home);
		btn_shopping=(Button) findViewById(R.id.shopping);
		iv_back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ShoppingCarActivity.this.finish();
			}
		});
		iv_home.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(ShoppingCarActivity.this,TabHostActivity.class);
				startActivity(intent);
				ShoppingCarActivity.this.finish();
			}
		});
		btn_shopping.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(ShoppingCarActivity.this,TabHostActivity.class);
				startActivity(intent);
				ShoppingCarActivity.this.finish();
			}
		});
	}
}
