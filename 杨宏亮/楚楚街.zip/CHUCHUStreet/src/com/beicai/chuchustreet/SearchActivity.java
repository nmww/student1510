package com.beicai.chuchustreet;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.ImageView;

import com.beicai.chuchustreet.adapter.SearchExpandableAdapter;
import com.example.chuchustreet.R;

public class SearchActivity extends Activity {
	ImageView img_back;
	ExpandableListView expandListView;
	SearchExpandableAdapter search_adapter;
	String Groups[]={"��������","������ʷ"};
	String Childs[][]={{"ŮT��","�п���", "����Ь"},{"�п���","��Ь","�ж���"}};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sarch);
		expandListView=(ExpandableListView) findViewById(R.id.search_expand);
		img_back=(ImageView) findViewById(R.id.search_back);
		search_adapter=new SearchExpandableAdapter(this, Groups, Childs);
		expandListView.setAdapter(search_adapter);
		img_back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				SearchActivity.this.finish();
			}
		});
		
		//�շż���
		expandListView.setOnGroupExpandListener(new OnGroupExpandListener() {
			
			@Override
			public void onGroupExpand(int groupPosition) {
				// TODO Auto-generated method stub
				
			}
		});
	}
}
