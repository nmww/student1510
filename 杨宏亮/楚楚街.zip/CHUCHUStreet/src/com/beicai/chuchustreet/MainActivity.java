package com.beicai.chuchustreet;


import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.Gallery;

import com.beicai.chuchustreet.adapter.GarrleryAdapter;
import com.example.chuchustreet.R;

public class MainActivity extends Activity {
	EditText ed_txt;
	Gallery imgchange;
	GarrleryAdapter garrAdapter;
	
	Integer img[]={R.drawable.change4,R.drawable.change5,
			R.drawable.change6};
	int position=0;
	Handler handler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.arg1) {
			case 0:
				if(position<img.length-1){
					position++;	
				}else{
					position=0;
				}
				imgchange.setSelection(position);
				break;

			default:
				break;
			}		
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		imgchange=(Gallery) findViewById(R.id.img_change);
		ed_txt=(EditText) findViewById(R.id.txt_search);
		garrAdapter=new GarrleryAdapter(MainActivity.this, img);
		imgchange.setAdapter(garrAdapter);
		Timer timer=new Timer();
		TimerTask timertask=new TimerTask(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				Message msg=new Message();
				msg.arg1=0;
				handler.sendMessage(msg);
			}};
			 timer.schedule(timertask, 1000, 1000);
			 imgchange.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					// TODO Auto-generated method stub
					
				}
			});
			 ed_txt.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent=new Intent(MainActivity.this,SearchActivity.class);
					startActivity(intent);
				}
			});
	}
}
