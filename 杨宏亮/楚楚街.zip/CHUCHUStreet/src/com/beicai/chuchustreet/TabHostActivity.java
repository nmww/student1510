package com.beicai.chuchustreet;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

import com.example.chuchustreet.R;

public class TabHostActivity extends TabActivity implements OnTabChangeListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_host);

		TabHost tHost = this.getTabHost();
		TabSpec spec1 = tHost.newTabSpec("Item1");
		// ���ö������
		spec1.setIndicator(View.inflate(TabHostActivity.this,
				R.layout.tab_main, null));

		Intent intent1 = new Intent(TabHostActivity.this, MainActivity.class);
		// ���ñ����Ӧ������
		spec1.setContent(intent1);
		// ���ӵ�tab��
		tHost.addTab(spec1);

		// =================================================================================================
		TabSpec spec2 = tHost.newTabSpec("Item2");
		spec2.setIndicator(View.inflate(TabHostActivity.this,
				R.layout.tab_class, null));
		Intent intent2 = new Intent(TabHostActivity.this, ClassActivity.class);
		spec2.setContent(intent2);
		tHost.addTab(spec2);
		// ===================================================================================================
		TabSpec spec3 = tHost.newTabSpec("Item3");
		spec3.setIndicator(View.inflate(TabHostActivity.this,
				R.layout.tab_ludao, null));
		Intent intent3 = new Intent(TabHostActivity.this, AboutActivity.class);
		spec3.setContent(intent3);
		tHost.addTab(spec3);
		// =========================================================
		TabSpec spec4 = tHost.newTabSpec("Item4");
		spec4.setIndicator(View.inflate(TabHostActivity.this,
				R.layout.tab_mine, null));
		Intent intent4 = new Intent(TabHostActivity.this, MineActivity.class);
		spec4.setContent(intent4);
		tHost.addTab(spec4);
	}

	@Override
	public void onTabChanged(String tabId) {
		// TODO Auto-generated method stub

	}
}
