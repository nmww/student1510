package com.beicai.touping;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class FanKuiActivity extends Activity implements OnClickListener{

	ImageView fanhui;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fankui_main);
		initVew();
	}
	private void initVew() {
		// TODO Auto-generated method stub
		fanhui=(ImageView) findViewById(R.id.iv_fankui_fanhui);
		fanhui.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_fankui_fanhui:
			FanKuiActivity.this.finish();
			break;

		default:
			break;
		}
	}
}
