package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ListView;

import com.beicai.touping.adapter.DaoHangAdapter;
import com.beicai.touping.adapter.GalleryAdapter;
import com.beicai.touping.adapter.JinWanAdapter;
import com.beicai.touping.bean.DaoHangBean;
import com.beicai.touping.bean.JinWanBean;

@SuppressWarnings("deprecation")
public class ShouYeActivity extends Activity {
	
	List<DaoHangBean> listdaohangData;
	List<JinWanBean> listjinwan;
	GridView lvdaohang;
	DaoHangAdapter daohangadapter;
	ListView jinwan;
	JinWanAdapter jinwanadapter;
	Gallery gallery;
	Integer[] galleryData={R.drawable.lun1,R.drawable.lun2,R.drawable.lun3,R.drawable.lun4,R.drawable.lun5,R.drawable.lun6};
	GalleryAdapter ga;
	Handler hd=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.arg1) {
			case 0:
				int i=gallery.getSelectedItemPosition();
				if(i<galleryData.length-1){
					i++;
				}else{
					i=0;
				}
				gallery.setSelection(i);
				break;

			default:
				break;
			}
			
		};
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shouye_item_layout);
		initList();
		initView();
	}

	private void initList() {
		listdaohangData=new ArrayList<DaoHangBean>();
		listdaohangData.add(new DaoHangBean(R.drawable.home_video_history_icon, "��ʷ"));
		listdaohangData.add(new DaoHangBean(R.drawable.home_video_collect_icon, "�ղ�"));
		listdaohangData.add(new DaoHangBean(R.drawable.home_video_local_icon, "����"));
		listdaohangData.add(new DaoHangBean(R.drawable.home_video_sort_icon, "����"));
		
		listjinwan=new ArrayList<JinWanBean>();
		listjinwan.add(new JinWanBean(R.drawable.jian, "���������޵�! ��Ӱ�еļ���", "��Ļ����Ц�����", "��31����Ƶ"));
		listjinwan.add(new JinWanBean(R.drawable.zaoxing, "������磡�����������ľ缯", "�������Щ�����أ�", "��31����Ƶ"));
		listjinwan.add(new JinWanBean(R.drawable.shanying, "ɽӰ��Ʒ��������Ʒ", "�������Ǿ���", "��14����Ƶ"));
	}

	private void initView() {
		// TODO Auto-generated method stub
		lvdaohang=(GridView) findViewById(R.id.lv_daohang);
		daohangadapter=new DaoHangAdapter(this,listdaohangData);
		lvdaohang.setAdapter(daohangadapter);
		lvdaohang.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				switch (position) {
				case 0:
					Intent intlishi=new Intent(ShouYeActivity.this, BoFangLishiActivity.class);
					startActivity(intlishi);
					break;
				case 1:
					Intent intshucang=new Intent(ShouYeActivity.this, ShouCangActivity.class);
					startActivity(intshucang);
					break;
				case 2:
					Intent intbendi=new Intent(ShouYeActivity.this, BenDiShePinActivity.class);
					startActivity(intbendi);
					break;
				case 3:
					Intent intfenlei=new Intent(ShouYeActivity.this, FenLeiActivity.class);
					startActivity(intfenlei);
					break;
				default:
					break;
				}
				
			}
		});
		
		jinwan=(ListView) findViewById(R.id.lv_jinwan);
		jinwanadapter=new JinWanAdapter(this,listjinwan);
		jinwan.setAdapter(jinwanadapter);
		
		gallery=(Gallery) findViewById(R.id.gallery_shouye_image);
		ga=new GalleryAdapter(this, galleryData);
		gallery.setAdapter(ga);
		
		Timer ti=new Timer();
		TimerTask t_image=new TimerTask() {
			
			@Override
			public void run() {
				Message mg=new Message();
				mg.arg1=0;
				hd.sendMessage(mg);
			}
		};ti.schedule(t_image, 3000,3000);
	}

}
