package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;

import com.beicai.touping.adapter.BenDiShiPinListAdapter;
import com.beicai.touping.bean.ImageOneTextFour;

public class BenDiShePinActivity extends Activity {
	
	ListView lv;
	BenDiShiPinListAdapter shipinAdapter;
	List<ImageOneTextFour> list;

	ImageView fanhui;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bendishipin_main);
		initListData();
		initView();
	}

	private void initView() {
		// TODO Auto-generated method stub
		lv=(ListView) findViewById(R.id.bendishipin_listview);
		shipinAdapter=new BenDiShiPinListAdapter(this,list);
		lv.setAdapter(shipinAdapter);
		fanhui=(ImageView) findViewById(R.id.iv_shipin_fanhui);
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				BenDiShePinActivity.this.finish();
			}
		});
	}

	private void initListData() {
		// TODO Auto-generated method stub
		list=new ArrayList<ImageOneTextFour>();
		list.add(new ImageOneTextFour(R.drawable.filter_no_icon, "01:05", "2����Ƶ", "Uc","��555KB"));
		list.add(new ImageOneTextFour(R.drawable.sample_1, "15:05", "4����Ƶ", "360","��15MB"));
		list.add(new ImageOneTextFour(R.drawable.sample_7, "03:04", "1����Ƶ", "��Ƶ","��155KB"));
	}
}
