package com.beicai.touping;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class FaBuJiePingActivity extends Activity {

	ImageView fanhui;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fabujieping_main);
		initView();
	}
	private void initView() {
		// TODO Auto-generated method stub
		fanhui=(ImageView) findViewById(R.id.iv_fabujieping_fanhui);
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				FaBuJiePingActivity.this.finish();
			}
		});
	}
}
