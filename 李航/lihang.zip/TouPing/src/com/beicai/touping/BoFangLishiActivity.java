package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;

import com.beicai.touping.adapter.BoFangLiShiAdapter;
import com.beicai.touping.bean.AppXinXiBean;

public class BoFangLishiActivity extends Activity {

	List<AppXinXiBean> listgrid;
	GridView grid;
	BoFangLiShiAdapter lishigridadapter;
	ImageView fanhui;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bofanglishi_main);
		initListData();
		initView();
	}
	private void initListData() {
		// TODO Auto-generated method stub
		listgrid=new ArrayList<AppXinXiBean>();
		listgrid.add(new AppXinXiBean(R.drawable.lishhi_1,"���Ͱ�ʵϰ��",4.5,38));
		listgrid.add(new AppXinXiBean(R.drawable.lishi_2,"ʮ�����Ц��",7.4,25));
		listgrid.add(new AppXinXiBean(R.drawable.lishi_3,"��Ĺ�ʼ�",5.5,20));
		listgrid.add(new AppXinXiBean(R.drawable.lishi_4,"���ǽ���",6.0,1));
		listgrid.add(new AppXinXiBean(R.drawable.lishi_5,"�ô�һ����",2.5,50));
		listgrid.add(new AppXinXiBean(R.drawable.lishi_6,"ͷ����D",6.5,1));
		listgrid.add(new AppXinXiBean(R.drawable.lishi_7,"�콫��ʨ",8.5,1));
		listgrid.add(new AppXinXiBean(R.drawable.lishi_8,"����ϲ����",8.5,15));
	}
	private void initView() {
		// TODO Auto-generated method stub
		grid=(GridView) findViewById(R.id.gv_lishi_grid);
		lishigridadapter=new BoFangLiShiAdapter(this, listgrid);
		grid.setAdapter(lishigridadapter);
		grid.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String strname=listgrid.get(position).getText();
				double strfenshu=listgrid.get(position).getFenshu();
				int strjishu=listgrid.get(position).getJishu();
				Bundle bu=new Bundle();
				bu.putString("appname", strname);
				bu.putDouble("fenshu", strfenshu);
				bu.putInt("jishu", strjishu);
				Intent in=new Intent(BoFangLishiActivity.this,XinXiActivity.class);
				in.putExtra("Bundle", bu);
				startActivity(in);
			}
		});
		
		fanhui=(ImageView) findViewById(R.id.iv_bofanglishi_fanhui);
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				BoFangLishiActivity.this.finish();
			}
		});
	}
}

