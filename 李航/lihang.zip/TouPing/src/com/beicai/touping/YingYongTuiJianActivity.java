package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Gallery;
import android.widget.GridView;

import com.beicai.touping.adapter.GalleryAdapter;
import com.beicai.touping.adapter.YingYongGridAdapter;
import com.beicai.touping.bean.DaoHangBean;

@SuppressWarnings("deprecation")
public class YingYongTuiJianActivity extends Activity {
	Gallery gallery;
	Integer[] galleryData={R.drawable.yingyong1,R.drawable.yingyong2,R.drawable.yingyong3,R.drawable.yingyong4};
	List<DaoHangBean> listgrid;
	GridView grid;
	YingYongGridAdapter yinggridadapter;
	
	@SuppressLint("HandlerLeak") GalleryAdapter ga;
	Handler hd=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.arg1) {
			case 0:
				int i=gallery.getSelectedItemPosition();
				if(i<galleryData.length-1){
					i++;
				}else{
					i=0;
				}
				gallery.setSelection(i);
				break;

			default:
				break;
			}
			
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.yingyongmain_layout);
		initListData();
		initview();
		
	}
	private void initListData() {
		listgrid=new ArrayList<DaoHangBean>();
		listgrid.add(new DaoHangBean(R.drawable.app_daoudizhu, "С�׶�����"));
		listgrid.add(new DaoHangBean(R.drawable.app_hifi, "HiFi"));
		listgrid.add(new DaoHangBean(R.drawable.app_keige, "K��֮��"));
		listgrid.add(new DaoHangBean(R.drawable.app_kuwo, "����K��"));
		listgrid.add(new DaoHangBean(R.drawable.app_lizhi, "��֦TV"));
		listgrid.add(new DaoHangBean(R.drawable.app_majiang, "С���齫"));
		listgrid.add(new DaoHangBean(R.drawable.app_toutiao, "ͷ��ͷ��"));
		listgrid.add(new DaoHangBean(R.drawable.app_youhua, "�����Ż�"));
		
	}
	private void initview() {
		// TODO Auto-generated method stub
		gallery=(Gallery) findViewById(R.id.gallery_yingyong_image);
		ga=new GalleryAdapter(this, galleryData);
		gallery.setAdapter(ga);
		
		Timer ti=new Timer();
		TimerTask t_image=new TimerTask() {
			
			@Override
			public void run() {
				Message mg=new Message();
				mg.arg1=0;
				hd.sendMessage(mg);
			}
		};ti.schedule(t_image, 3000,3000);
		
		grid=(GridView) findViewById(R.id.gv_yingyong_grid);
		yinggridadapter=new YingYongGridAdapter(this, listgrid);
		grid.setAdapter(yinggridadapter);
	}
}
