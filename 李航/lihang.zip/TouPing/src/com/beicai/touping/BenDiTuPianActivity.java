package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.ImageView;

import com.beicai.touping.adapter.BenDiTuPianAdapter;
import com.beicai.touping.bean.ImageFourTextOne;

public class BenDiTuPianActivity extends Activity {

	GridView gv;
	List<ImageFourTextOne> list;
	BenDiTuPianAdapter tupianadapter;
	ImageView fanhui;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.benditupian);
		initListData();
		initView();
		
	}
	private void initView() {
		// TODO Auto-generated method stub
		gv=(GridView) findViewById(R.id.gv_tupian_grid);
		tupianadapter=new BenDiTuPianAdapter(this,list);
		gv.setAdapter(tupianadapter);
		fanhui=(ImageView) findViewById(R.id.iv_tupian_fanhui);
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				BenDiTuPianActivity.this.finish();
			}
		});
	}
	private void initListData() {
		// TODO Auto-generated method stub
		list=new ArrayList<ImageFourTextOne>();
		list.add(new ImageFourTextOne("cover | 29",R.drawable.sample_0, R.drawable.sample_1, R.drawable.sample_2, R.drawable.sample_3));
		list.add(new ImageFourTextOne("UcDownloads | 6",R.drawable.sample_4, R.drawable.sample_5, R.drawable.sample_6, R.drawable.sample_7));
		list.add(new ImageFourTextOne("QQImages | 49",R.drawable.sample_7, R.drawable.sample_6, R.drawable.sample_5, R.drawable.sample_4));
		list.add(new ImageFourTextOne("Image | 23",R.drawable.sample_3, R.drawable.sample_2, R.drawable.sample_1, R.drawable.sample_0));
		list.add(new ImageFourTextOne("sgame | 92",R.drawable.sample_1, R.drawable.sample_2, R.drawable.sample_3, R.drawable.sample_4));
		list.add(new ImageFourTextOne("΢�� | 64",R.drawable.sample_5, R.drawable.sample_6, R.drawable.sample_7, R.drawable.sample_0));
	}
}
