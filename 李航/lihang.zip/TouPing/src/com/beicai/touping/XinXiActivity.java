package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.adapter.XinXiGridAdapter;
import com.beicai.touping.util.MyGridView;

public class XinXiActivity extends Activity {

	MyGridView gv;
	XinXiGridAdapter gridadapter;
	List<String> list;
	List<String> lists;
	TextView tvBiaoTi;
	TextView tvfenshu;
	Button btnQuanBu;
	ImageView fanhui;
	ImageView search;
	
	Bundle bun;
	String appname;
	double fenshu;
	int jishu;
	
	
	
	boolean shoucangbl=false;
	Button shoucang;
	boolean bl=true;
	Handler hd=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.arg1) {
			case 0:
				gridadapter=new XinXiGridAdapter(XinXiActivity.this, list);
				gv.setAdapter(gridadapter);
				break;
			case 1:
				gridadapter=new XinXiGridAdapter(XinXiActivity.this, lists);
				gv.setAdapter(gridadapter);
				break;
			default:
				break;
			}
			
		}
		;
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xinxi_main);
		
		Intent in=getIntent();
		bun=in.getBundleExtra("Bundle");
		appname=bun.getString("appname");
		fenshu=bun.getDouble("fenshu");
		jishu=bun.getInt("jishu");
		initListData();
		initView();
	}
	private void initView() {
		// TODO Auto-generated method stub
		gv=(MyGridView) findViewById(R.id.gv_xinxi_grid);
		gridadapter=new XinXiGridAdapter(this, lists);
		gv.setAdapter(gridadapter);
		tvBiaoTi=(TextView) findViewById(R.id.tv_xinxi_biaoti);
		tvBiaoTi.setText(appname);
		tvfenshu=(TextView) findViewById(R.id.tv_fenshu);
		tvfenshu.setText(""+fenshu);
		
		btnQuanBu=(Button) findViewById(R.id.btn_quanbu);
		btnQuanBu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(bl){
					Message mg=new Message();
					mg.arg1=0;
					hd.sendMessage(mg);
					bl=false;
				}else{
					Message mg=new Message();
					mg.arg1=1;
					hd.sendMessage(mg);
					bl=true;
				}
			}
		});
		
		shoucang=(Button) findViewById(R.id.xini_shoucang_btn);
		shoucang.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(shoucangbl){
					v.setBackgroundResource(R.drawable.applications_favorites);
					shoucangbl=false;
				}else{
					v.setBackgroundResource(R.drawable.applications_favorites_focus);
					shoucangbl=true;
				}
			}
		});
		
		fanhui=(ImageView) findViewById(R.id.iv_xinxi_fanhui);
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				XinXiActivity.this.finish();
			}
		});
		search=(ImageView) findViewById(R.id.iv_xinxi_search);
		search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(XinXiActivity.this, SousuoActivity.class);
				startActivity(in);
			}
		});
	}
	private void initListData() {
		// TODO Auto-generated method stub
		list=new ArrayList<String>();
		for(int i=1;i<jishu+1;i++){
			list.add(""+i);
		}
		if(list.size()>7){
			lists=list.subList(0, 8);
		}else{
			lists=list;
		}
	}
}
