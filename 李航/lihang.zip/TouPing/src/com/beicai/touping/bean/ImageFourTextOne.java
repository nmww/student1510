package com.beicai.touping.bean;

public class ImageFourTextOne {

	String text;
	int imageOne;
	int imageTwo;
	int imageThree;
	int imageFour;
	
	public ImageFourTextOne(String text, int imageOne, int imageTwo,
			int imageThree, int imageFour) {
		super();
		this.text = text;
		this.imageOne = imageOne;
		this.imageTwo = imageTwo;
		this.imageThree = imageThree;
		this.imageFour = imageFour;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getImageOne() {
		return imageOne;
	}
	public void setImageOne(int imageOne) {
		this.imageOne = imageOne;
	}
	public int getImageTwo() {
		return imageTwo;
	}
	public void setImageTwo(int imageTwo) {
		this.imageTwo = imageTwo;
	}
	public int getImageThree() {
		return imageThree;
	}
	public void setImageThree(int imageThree) {
		this.imageThree = imageThree;
	}
	public int getImageFour() {
		return imageFour;
	}
	public void setImageFour(int imageFour) {
		this.imageFour = imageFour;
	}
	
}
