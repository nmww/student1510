package com.beicai.touping.bean;

public class ImageOneTextFour {

	int logo;
	String textone;
	String texttwo;
	String textthree;
	String textfour;
	public ImageOneTextFour(int logo, String textone, String texttwo,
			String textthree, String textfour) {
		super();
		this.logo = logo;
		this.textone = textone;
		this.texttwo = texttwo;
		this.textthree = textthree;
		this.textfour = textfour;
	}
	public int getLogo() {
		return logo;
	}
	public void setLogo(int logo) {
		this.logo = logo;
	}
	public String getTextone() {
		return textone;
	}
	public void setTextone(String textone) {
		this.textone = textone;
	}
	public String getTexttwo() {
		return texttwo;
	}
	public void setTexttwo(String texttwo) {
		this.texttwo = texttwo;
	}
	public String getTextthree() {
		return textthree;
	}
	public void setTextthree(String textthree) {
		this.textthree = textthree;
	}
	public String getTextfour() {
		return textfour;
	}
	public void setTextfour(String textfour) {
		this.textfour = textfour;
	}
	
}
