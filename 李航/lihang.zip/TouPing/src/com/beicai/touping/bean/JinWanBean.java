package com.beicai.touping.bean;

public class JinWanBean {

	int logo;
	String biaoti;
	String neirongone;
	String neirongtwo;
	
	
	public JinWanBean(int logo, String biaoti, String neirongone,
			String neirongtwo) {
		super();
		this.logo = logo;
		this.biaoti = biaoti;
		this.neirongone = neirongone;
		this.neirongtwo = neirongtwo;
	}
	public int getLogo() {
		return logo;
	}
	public void setLogo(int logo) {
		this.logo = logo;
	}
	public String getBiaoti() {
		return biaoti;
	}
	public void setBiaoti(String biaoti) {
		this.biaoti = biaoti;
	}
	public String getNeirongone() {
		return neirongone;
	}
	public void setNeirongone(String neirongone) {
		this.neirongone = neirongone;
	}
	public String getNeirongtwo() {
		return neirongtwo;
	}
	public void setNeirongtwo(String neirongtwo) {
		this.neirongtwo = neirongtwo;
	}
	
}
