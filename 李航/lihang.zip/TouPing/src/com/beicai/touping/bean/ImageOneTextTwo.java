package com.beicai.touping.bean;

public class ImageOneTextTwo {

	int image;
	String strone;
	String strtwo;
	
	public ImageOneTextTwo(int image, String strone, String strtwo) {
		super();
		this.image = image;
		this.strone = strone;
		this.strtwo = strtwo;
	}
	public int getImage() {
		return image;
	}
	public void setImage(int image) {
		this.image = image;
	}
	public String getStrone() {
		return strone;
	}
	public void setStrone(String strone) {
		this.strone = strone;
	}
	public String getStrtwo() {
		return strtwo;
	}
	public void setStrtwo(String strtwo) {
		this.strtwo = strtwo;
	}
	
	
}
