package com.beicai.touping.bean;

public class ImageTwoTextTwoBean {

	int imageone;
	int imagetwo;
	String textone;
	String texttwo;
	
	
	public ImageTwoTextTwoBean() {
		super();
	}
	public ImageTwoTextTwoBean(int imageone, int imagetwo, String textone,
			String texttwo) {
		super();
		this.imageone = imageone;
		this.imagetwo = imagetwo;
		this.textone = textone;
		this.texttwo = texttwo;
	}
	public int getImageone() {
		return imageone;
	}
	public void setImageone(int imageone) {
		this.imageone = imageone;
	}
	public int getImagetwo() {
		return imagetwo;
	}
	public void setImagetwo(int imagetwo) {
		this.imagetwo = imagetwo;
	}
	public String getTextone() {
		return textone;
	}
	public void setTextone(String textone) {
		this.textone = textone;
	}
	public String getTexttwo() {
		return texttwo;
	}
	public void setTexttwo(String texttwo) {
		this.texttwo = texttwo;
	}
	
}
