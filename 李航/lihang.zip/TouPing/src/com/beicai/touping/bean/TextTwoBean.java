package com.beicai.touping.bean;

public class TextTwoBean {

	String strone;
	String strtwo;
	public TextTwoBean(String strone, String strtwo) {
		super();
		this.strone = strone;
		this.strtwo = strtwo;
	}
	public String getStrone() {
		return strone;
	}
	public void setStrone(String strone) {
		this.strone = strone;
	}
	public String getStrtwo() {
		return strtwo;
	}
	public void setStrtwo(String strtwo) {
		this.strtwo = strtwo;
	}
	
	
}
