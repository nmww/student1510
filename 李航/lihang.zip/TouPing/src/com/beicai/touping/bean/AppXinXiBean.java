package com.beicai.touping.bean;

public class AppXinXiBean {
	private int image;
	private String text;
	private double fenshu;
	private int jishu;
	public AppXinXiBean(int image, String text, double fenshu, int jishu) {
		super();
		this.image = image;
		this.text = text;
		this.fenshu = fenshu;
		this.jishu = jishu;
	}
	public int getImage() {
		return image;
	}
	public void setImage(int image) {
		this.image = image;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public double getFenshu() {
		return fenshu;
	}
	public void setFenshu(double fenshu) {
		this.fenshu = fenshu;
	}
	public int getJishu() {
		return jishu;
	}
	public void setJishu(int jishu) {
		this.jishu = jishu;
	}
	
}
