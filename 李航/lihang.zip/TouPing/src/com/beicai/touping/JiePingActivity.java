package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;

import com.beicai.touping.adapter.JiepingGridAdapter;
import com.beicai.touping.bean.DaoHangBean;

public class JiePingActivity extends Activity {

	GridView grid;
	JiepingGridAdapter jiepingadapter;
	List<DaoHangBean> list;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.jiepingmain_layout);
		initListData();
		initview();
		
	}
	private void initListData() {
		// TODO Auto-generated method stub
		list=new ArrayList<DaoHangBean>();
		list.add(new DaoHangBean(R.drawable.jieping1,"��Ů��"));
		list.add(new DaoHangBean(R.drawable.jieping2,"��ʱ�˿�"));
		list.add(new DaoHangBean(R.drawable.jieping3,"��������"));
		list.add(new DaoHangBean(R.drawable.jieping4,"��������ս����"));
		list.add(new DaoHangBean(R.drawable.jieping5,"������������"));
		list.add(new DaoHangBean(R.drawable.jieping6,"����������"));
	}
	private void initview() {
		// TODO Auto-generated method stub
		grid=(GridView) findViewById(R.id.gv_jieping_grid);
		jiepingadapter=new JiepingGridAdapter(this,list);
		grid.setAdapter(jiepingadapter);
	}
	
	public void fajieping(View v){
		Intent in=new Intent(JiePingActivity.this, FaBuJiePingActivity.class);
		startActivity(in);
	}
	
	public void bendizhaopian(View v){
		Intent in=new Intent(JiePingActivity.this, BenDiTuPianActivity.class);
		startActivity(in);
	}
}
