package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

import com.beicai.touping.adapter.BaoXiangAdapter;
import com.beicai.touping.bean.DaoHangBean;

public class BaoXiangActivity extends Activity {

	List<DaoHangBean> listbao;
	GridView gv;
	BaoXiangAdapter baoada;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.baoxiang);
		initList();
		initView();
	}

	private void initView() {
		// TODO Auto-generated method stub
		gv=(GridView) findViewById(R.id.gv_grid);
		baoada=new BaoXiangAdapter(this,listbao);
		gv.setAdapter(baoada);
		gv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				switch (position) {
				case 3:
					Intent inzhaopian=new Intent(BaoXiangActivity.this, BenDiTuPianActivity.class);
					startActivity(inzhaopian);
					break;
				case 4:
					Intent inshipin=new Intent(BaoXiangActivity.this, BenDiShePinActivity.class);
					startActivity(inshipin);
					break;

				default:
					break;
				}
			}
		});
	}

	private void initList() {
		// TODO Auto-generated method stub
		listbao=new ArrayList<DaoHangBean>();
		listbao.add(new DaoHangBean(R.drawable.xiang_1, "Ѹ�����б�"));
		listbao.add(new DaoHangBean(R.drawable.xiang_2, "������ʦ"));
		listbao.add(new DaoHangBean(R.drawable.xiang_3, "���ٲ���"));
		listbao.add(new DaoHangBean(R.drawable.xiang_4, "Ͷ�䱾����Ƭ"));
		listbao.add(new DaoHangBean(R.drawable.xiang_5, "Ͷ�䱾����Ƶ"));
		listbao.add(new DaoHangBean(R.drawable.xiang_6, "��װ����Ӧ��"));
		listbao.add(new DaoHangBean(R.drawable.xiang_7, "���ӽ�������"));
		listbao.add(new DaoHangBean(R.drawable.xiang_8, "��¼����"));
		listbao.add(new DaoHangBean(R.drawable.xiang_9, "�����ֻ��ȵ�"));
		listbao.add(new DaoHangBean(R.drawable.xiang_10, "������Ļ����"));
		listbao.add(new DaoHangBean(R.drawable.xiang_11, "�Ƽ�Ͷ������"));
		listbao.add(new DaoHangBean(R.drawable.xiang12, "��Ϸģʽ"));
		
		
	}
}
