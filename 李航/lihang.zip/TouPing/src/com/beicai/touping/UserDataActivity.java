package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;

import com.beicai.touping.adapter.UserGridAdapter;
import com.beicai.touping.bean.DaoHangBean;
import com.beicai.touping.util.ImageYuanJiao;
import com.beicai.touping.util.MyGridView;

public class UserDataActivity extends Activity implements OnClickListener{
	
	MyGridView gridUser;
	UserGridAdapter userGridAdapter;
	List<DaoHangBean> listUserGridData;
	ImageView fanhui;
	ImageView userHead;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_data_main_item);
		initListData();
		initView();
	}

	private void initListData() {
		// TODO Auto-generated method stub
		listUserGridData=new ArrayList<DaoHangBean>();
		listUserGridData.add(new DaoHangBean(R.drawable.mine_history,"������ʷ"));
		listUserGridData.add(new DaoHangBean(R.drawable.mine_favorite,"�ҵ��ղ�"));
		listUserGridData.add(new DaoHangBean(R.drawable.mine_application,"�ҵ�Ӧ��"));
		listUserGridData.add(new DaoHangBean(R.drawable.mine_feedback,"��������"));
		listUserGridData.add(new DaoHangBean(R.drawable.mine_setting,"����"));
	}

	private void initView() {
		// TODO Auto-generated method stub
		gridUser=(MyGridView) findViewById(R.id.user_grid_gongneng);
		userGridAdapter=new UserGridAdapter(this,listUserGridData);
		gridUser.setAdapter(userGridAdapter);
		gridUser.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				
				switch (position) {
				case 0:
					Intent lishi=new Intent(UserDataActivity.this, BoFangLishiActivity.class);
					startActivity(lishi);
					break;
				case 1:
					Intent intshucang=new Intent(UserDataActivity.this, ShouCangActivity.class);
					startActivity(intshucang);
					break;
				case 2:
					
					break;
				case 3:
					Intent intfankui=new Intent(UserDataActivity.this, FanKuiActivity.class);
					startActivity(intfankui);
					break;
				case 4:
					Intent intshezhi=new Intent(UserDataActivity.this, SheZhiAcitvity.class);
					startActivity(intshezhi);
					break;
				default:
					break;
				}
			}
		});
		
		ImageView userHead=(ImageView) findViewById(R.id.user_head);
		userHead.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
				intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
//			    intent.addCategory(Intent.CATEGORY_OPENABLE);
//			    intent.setType("image/*");
			    intent.putExtra("crop", "true");
			    intent.putExtra("aspectX", 1);
			    intent.putExtra("aspectY", 1);
			    intent.putExtra("outputX", 80);
			    intent.putExtra("outputY", 80);
			    intent.putExtra("return-data", true);

			    startActivityForResult(intent, 0);

			}
		});
		Bitmap btUserLogo=ImageYuanJiao.drawableToBitmap(getResources().getDrawable(R.drawable.user_head));
		btUserLogo=ImageYuanJiao.toRoundCorner(btUserLogo, 1000);
		Drawable draimage=ImageYuanJiao.bitmapToDrawble(btUserLogo, this);
		userHead.setBackgroundDrawable(draimage);
		
		fanhui=(ImageView) findViewById(R.id.iv_user_fanhui);
		fanhui.setOnClickListener(this);
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		  System.out.println(resultCode);
		 
		  try {
			Bitmap cameraBitmap = (Bitmap) data.getExtras().get("data");
//			  super.onActivityResult(requestCode, resultCode, data);
			  
			  ImageView ivLogo=(ImageView) findViewById(R.id.user_head);
			//Bitmap btUserLogo=ImageYuanJiao.drawableToBitmap(getResources().getDrawable(R.drawable.user_head));
			  cameraBitmap=ImageYuanJiao.toRoundCorner(cameraBitmap, 1000);
				Drawable draimage=ImageYuanJiao.bitmapToDrawble(cameraBitmap, this);
				ivLogo.setBackgroundDrawable(draimage);

			    Drawable drawable =new BitmapDrawable(cameraBitmap);
			    userHead.setBackgroundDrawable(drawable);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		 }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_user_fanhui:
			UserDataActivity.this.finish();
			break;

		default:
			break;
		}
	}
}
