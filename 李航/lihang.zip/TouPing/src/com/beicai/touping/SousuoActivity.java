package com.beicai.touping;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;

import com.beicai.touping.adapter.SouSuoLiShiAdapter;
import com.beicai.touping.adapter.SouSuoReCiAdapter;
import com.beicai.touping.bean.DaoHangBean;

public class SousuoActivity extends Activity {

	String [] strgrid={"�����","��ǧ��","׽����","������","��Ұ����","������","������","HiFi����","K��֮��","���Ӽ�"};
	GridView gridreci;
	SouSuoReCiAdapter sousuogridadapter;
	List<DaoHangBean> listLishi;
	ListView sousuolishi;
	SouSuoLiShiAdapter sousuolishiadapter;
	ImageView imgfanhui;
	EditText dtsousuo;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sousuo_main);
		initListData();
		initView();
	}
	private void initListData() {
		listLishi=new ArrayList<DaoHangBean>();
		listLishi.add(new DaoHangBean(R.drawable.search_lishi, "��ɽս��"));
		listLishi.add(new DaoHangBean(R.drawable.search_lishi, "��ǧ��"));
		listLishi.add(new DaoHangBean(R.drawable.search_lishi, "����ϲ����"));
		listLishi.add(new DaoHangBean(R.drawable.search_lishi, "�ۇ�"));
		listLishi.add(new DaoHangBean(R.drawable.search_lishi, "��ɫ����"));
		listLishi.add(new DaoHangBean(R.drawable.search_lishi, "���Ǹ���"));
	}
	private void initView() {
		// TODO Auto-generated method stub
		gridreci=(GridView) findViewById(R.id.gv_sousuo_grid);
		sousuogridadapter=new SouSuoReCiAdapter(this, strgrid);
		gridreci.setAdapter(sousuogridadapter);
		gridreci.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String str=strgrid[position];
				dtsousuo.setText(str);
			}
		});
		
		dtsousuo=(EditText) findViewById(R.id.edit_sousuo_search);
		
		sousuolishi=(ListView) findViewById(R.id.lv_sousuo_lishi);
		sousuolishiadapter=new SouSuoLiShiAdapter(this, listLishi);
		sousuolishi.setAdapter(sousuolishiadapter);
		sousuolishi.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String str=listLishi.get(position).getText();
				dtsousuo.setText(str);
			}
		});
		
		imgfanhui=(ImageView) findViewById(R.id.iv_sousuo_fanhui);
		imgfanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				SousuoActivity.this.finish();
			}
		});
	}
}

