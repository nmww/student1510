package com.beicai.touping;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;

@SuppressWarnings("deprecation")
public class TabHostMainActivity extends TabActivity implements OnClickListener{
	
	TabHost tabhostMain;
	EditText edit;
	ImageView ivOnUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tabhostMain=getTabHost();
        LayoutInflater.from(this).inflate(R.layout.tab_host_main, tabhostMain.getTabContentView(),true);
        initTabSpec();
        initview();
    }



	private void initview() {
		// TODO Auto-generated method stub
		edit=(EditText) findViewById(R.id.edit_serch);
		edit.setOnClickListener(this);
		ivOnUser=(ImageView) findViewById(R.id.iv_tabhost_user);
		ivOnUser.setOnClickListener(this);
	}



	private void initTabSpec() {
		
		//����ҳ
		 	
			RelativeLayout tabbaoxiang=(RelativeLayout)LayoutInflater.from(this).inflate(R.layout.tabhost_foot_item, null);
	        TextView textbaoxiang=(TextView) tabbaoxiang.findViewById(R.id.foot_tabhost_text);
	        textbaoxiang.setText("����");
	        
	        Intent inbaoxiang=new Intent(this, BaoXiangActivity.class);
			inbaoxiang.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			View viewbaoxiang=this.getLocalActivityManager().startActivity("1", inbaoxiang).getDecorView();
			LinearLayout linBaoXiang=(LinearLayout) findViewById(R.id.lin_baoxiang);
			linBaoXiang.removeAllViews();
			linBaoXiang.addView(viewbaoxiang);
			
	        TabSpec tab1=tabhostMain.newTabSpec("baoxiang");
	        tab1.setIndicator(tabbaoxiang);
	        tab1.setContent(R.id.lin_baoxiang);
	        tabhostMain.addTab(tab1);
		//��ҳ
	        RelativeLayout tabshipin=(RelativeLayout) LayoutInflater.from(this).inflate(R.layout.tabhost_foot_item, null);
	        TextView textshipin=(TextView) tabshipin.findViewById(R.id.foot_tabhost_text);
	        textshipin.setText("��Ƶ");
	        
	        Intent inshipin=new Intent(this, ShouYeActivity.class);
			inshipin.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			View viewshipin=this.getLocalActivityManager().startActivity("2", inshipin).getDecorView();
			LinearLayout linshipin=(LinearLayout) findViewById(R.id.lin_shouye);
			linshipin.removeAllViews();
			linshipin.addView(viewshipin);
			
			TabSpec tab2=tabhostMain.newTabSpec("shipin");
	        tab2.setIndicator(tabshipin);
	        tab2.setContent(R.id.lin_shouye);
	        tabhostMain.addTab(tab2);
		//����ҳ
	        RelativeLayout tabjietu=(RelativeLayout) LayoutInflater.from(this).inflate(R.layout.tabhost_foot_item, null);
	        TextView textjieping=(TextView) tabjietu.findViewById(R.id.foot_tabhost_text);
	        textjieping.setText("����");
	        
	        Intent injieping=new Intent(this, JiePingActivity.class);
	        injieping.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			View viewjieping=this.getLocalActivityManager().startActivity("3", injieping).getDecorView();
			LinearLayout linjieping=(LinearLayout) findViewById(R.id.lin_jieping);
			linjieping.removeAllViews();
			linjieping.addView(viewjieping);
			
			TabSpec tab3=tabhostMain.newTabSpec("jieping");
	        tab3.setIndicator(tabjietu);
	        tab3.setContent(R.id.lin_jieping);
	        tabhostMain.addTab(tab3);
		
		//Ӧ�ý���
	        RelativeLayout tabyingyong=(RelativeLayout) LayoutInflater.from(this).inflate(R.layout.tabhost_foot_item, null);
	        TextView textyingyong=(TextView) tabyingyong.findViewById(R.id.foot_tabhost_text);
	        textyingyong.setText("Ӧ��");
	        
	        Intent inyingyong=new Intent(this, YingYongTuiJianActivity.class);
	        inyingyong.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			View viewyingyong=this.getLocalActivityManager().startActivity("4", inyingyong).getDecorView();
			LinearLayout liyingyong=(LinearLayout) findViewById(R.id.lin_yingyong);
			liyingyong.removeAllViews();
			liyingyong.addView(viewyingyong);
			
			TabSpec tab4=tabhostMain.newTabSpec("yingyong");
	        tab4.setIndicator(tabyingyong);
	        tab4.setContent(R.id.lin_yingyong);
	        tabhostMain.addTab(tab4);
		tabhostMain.setCurrentTab(1);
	}


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.edit_serch:
			Intent editin=new Intent(TabHostMainActivity.this, SousuoActivity.class);
			startActivity(editin);
			break;
		case R.id.iv_tabhost_user:
			Intent userin=new Intent(TabHostMainActivity.this, UserDataActivity.class);
			startActivity(userin);
		default:
			break;
		}
	}
    
}

