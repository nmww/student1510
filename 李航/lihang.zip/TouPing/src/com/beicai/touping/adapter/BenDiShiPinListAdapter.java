package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.ImageOneTextFour;

public class BenDiShiPinListAdapter extends BaseAdapter {

	Context context;
	List<ImageOneTextFour> list;
	
	public BenDiShiPinListAdapter(Context context, List<ImageOneTextFour> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolderBenDiShiPin vh;
		if(convertView==null){
			vh=new ViewHolderBenDiShiPin();
			convertView=View.inflate(context, R.layout.bendishipin_listview_item, null);
			vh.logo=(ImageView) convertView.findViewById(R.id.bendishipin_logo);
			vh.tvone=(TextView) convertView.findViewById(R.id.bendishipin_time);
			vh.tvtwo=(TextView) convertView.findViewById(R.id.bendishipin_geshu);
			vh.tvthree=(TextView) convertView.findViewById(R.id.bendishipin_textname);
			vh.tvfour=(TextView) convertView.findViewById(R.id.bendishipin_textdaxiao);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolderBenDiShiPin) convertView.getTag();
		}
		vh.logo.setImageResource(list.get(position).getLogo());
		vh.tvone.setText(list.get(position).getTextone());
		vh.tvtwo.setText(list.get(position).getTexttwo());
		vh.tvthree.setText(list.get(position).getTextthree());
		vh.tvfour.setText(list.get(position).getTextfour());
		return convertView;
	}

	class ViewHolderBenDiShiPin{
		ImageView logo;
		TextView tvone;
		TextView tvtwo;
		TextView tvthree;
		TextView tvfour;
	}
}
