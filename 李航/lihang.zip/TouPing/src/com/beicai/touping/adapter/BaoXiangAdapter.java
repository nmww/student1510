package com.beicai.touping.adapter;

import java.util.List;

import com.beicai.touping.R;
import com.beicai.touping.adapter.DaoHangAdapter.ViewHolderDaoHang;
import com.beicai.touping.bean.DaoHangBean;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class BaoXiangAdapter extends BaseAdapter{

	private Context context;
	private List<DaoHangBean> list;
	
	public BaoXiangAdapter(Context context, List<DaoHangBean> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		BaoXiangViewHolder vh;
		if(convertView==null){
			vh=new BaoXiangViewHolder();
			convertView=View.inflate(context, R.layout.baoxiang_group_item, null);
			vh.img=(ImageView) convertView.findViewById(R.id.iv_baoxiang_img);
			vh.str=(TextView) convertView.findViewById(R.id.tv_baoxiang_name);
			convertView.setTag(vh);
		}else{
			vh=(BaoXiangViewHolder) convertView.getTag();
		}
		vh.img.setImageResource(list.get(position).getImage());
		vh.str.setText(list.get(position).getText());

		return convertView;
	}
	
	class BaoXiangViewHolder{
		ImageView img;
		TextView str;

	}

}
