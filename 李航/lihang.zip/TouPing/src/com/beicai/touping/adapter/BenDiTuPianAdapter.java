package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.ImageFourTextOne;

public class BenDiTuPianAdapter extends BaseAdapter {

	Context context;
	List<ImageFourTextOne> list;
	
	
	public BenDiTuPianAdapter(Context context, List<ImageFourTextOne> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolderTuPian vh;
		if(convertView==null){
			vh=new ViewHolderTuPian();
			convertView=View.inflate(context, R.layout.benditupian_grid_item, null);
			vh.tv=(TextView) convertView.findViewById(R.id.tv_tupian_biaoti);
			vh.da=(ImageView) convertView.findViewById(R.id.image_tupian_da);
			vh.xiaoOne=(ImageView) convertView.findViewById(R.id.image_tupian_xiao_one);
			vh.xiaoTwo=(ImageView) convertView.findViewById(R.id.image_tupian_xiao_two);
			vh.xiaoThree=(ImageView) convertView.findViewById(R.id.image_tupian_xiao_three);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolderTuPian) convertView.getTag();
		}
		vh.tv.setText(list.get(position).getText());
		vh.da.setImageResource(list.get(position).getImageOne());
		vh.xiaoOne.setImageResource(list.get(position).getImageTwo());
		vh.xiaoTwo.setImageResource(list.get(position).getImageThree());
		vh.xiaoThree.setImageResource(list.get(position).getImageFour());
		return convertView;
	}

	class ViewHolderTuPian{
		TextView tv;
		ImageView da;
		ImageView xiaoOne;
		ImageView xiaoTwo;
		ImageView xiaoThree;
	}
}
