package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.adapter.DaoHangAdapter.ViewHolderDaoHang;
import com.beicai.touping.bean.DaoHangBean;

public class SouSuoLiShiAdapter extends BaseAdapter {

	Context context;
	List<DaoHangBean> list;
	
	
	public SouSuoLiShiAdapter(Context context, List<DaoHangBean> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHoldersousuo vh;
		if(convertView==null){
			vh=new ViewHoldersousuo();
			convertView=View.inflate(context, R.layout.sousuo_listview_lishi_item, null);
			vh.img=(ImageView) convertView.findViewById(R.id.sousuo_lishi_img);
			vh.str=(TextView) convertView.findViewById(R.id.sousuo_lishi_name);
			convertView.setTag(vh);
		}else{
			vh=(ViewHoldersousuo) convertView.getTag();
		}
		vh.img.setImageResource(list.get(position).getImage());
		vh.str.setText(list.get(position).getText());
		return convertView;
	}

	class ViewHoldersousuo{
		ImageView img;
		TextView str;
	}
}
