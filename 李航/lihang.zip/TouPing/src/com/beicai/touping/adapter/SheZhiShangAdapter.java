package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.ImageOneTextTwo;

public class SheZhiShangAdapter extends BaseAdapter {

	Context context;
	List<ImageOneTextTwo> list;
	
	public SheZhiShangAdapter(Context context, List<ImageOneTextTwo> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolderSheZhiShang vh;
		if(convertView==null){
			vh=new ViewHolderSheZhiShang();
			convertView=View.inflate(context, R.layout.shezhi_shang_item, null);
			vh.img=(ImageView) convertView.findViewById(R.id.iv_shezhi_shang_image);
			vh.textone=(TextView) convertView.findViewById(R.id.tv_shezhi_shang_textmax);
			vh.textTwo=(TextView) convertView.findViewById(R.id.tv_shezhi_shang_textmin);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolderSheZhiShang) convertView.getTag();
		}
		int imageid=list.get(position).getImage();
		if(position==1){
			vh.img.setImageResource(imageid);
			
		}else{
			vh.img.setVisibility(View.INVISIBLE);
		}
		vh.textone.setText(list.get(position).getStrone());
		vh.textTwo.setText(list.get(position).getStrtwo());
		return convertView;
	}
class ViewHolderSheZhiShang{
	ImageView img;
	TextView textone;
	TextView textTwo;
}
}
