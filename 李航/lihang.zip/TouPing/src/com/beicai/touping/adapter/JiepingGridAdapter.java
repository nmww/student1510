package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.DaoHangBean;

public class JiepingGridAdapter extends BaseAdapter {
	
	Context context;
	List<DaoHangBean> list;

	public JiepingGridAdapter(Context context, List<DaoHangBean> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolderJiePing vh;
		if(convertView==null){
			vh=new ViewHolderJiePing();
			convertView=View.inflate(context, R.layout.jieping_grid_item, null);
			vh.img=(ImageView) convertView.findViewById(R.id.jieping_grid_image);
			vh.text=(TextView) convertView.findViewById(R.id.jieping_grid_name);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolderJiePing) convertView.getTag();
		}
		vh.img.setImageResource(list.get(position).getImage());
		vh.text.setText(list.get(position).getText());
		return convertView;
	}
	class ViewHolderJiePing{
		ImageView img;
		TextView text;
	}
}
