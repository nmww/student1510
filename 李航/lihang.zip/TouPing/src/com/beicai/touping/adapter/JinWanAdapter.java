package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.JinWanBean;

public class JinWanAdapter extends BaseAdapter {
	
	private Context context;
	private List<JinWanBean>list;

	
	public JinWanAdapter(Context context, List<JinWanBean> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		VeiwHolderJinWan vh;
		if(convertView==null){
			vh=new VeiwHolderJinWan();
			convertView=View.inflate(context, R.layout.jinwan_item, null);
			vh.img=(ImageView) convertView.findViewById(R.id.iv_jinwan_img);
			vh.tvbiaoti=(TextView) convertView.findViewById(R.id.tv_jinwan_biaoti);
			vh.tvneione=(TextView) convertView.findViewById(R.id.tv_jinwan_neirongone);
			vh.tvneitwo=(TextView) convertView.findViewById(R.id.tv_jinwan_neirongtwo);
			convertView.setTag(vh);
		}else{
			vh= (VeiwHolderJinWan) convertView.getTag();
		}
		vh.img.setImageResource(list.get(position).getLogo());
		vh.tvbiaoti.setText(list.get(position).getBiaoti());
		vh.tvneione.setText(list.get(position).getNeirongone());
		vh.tvneitwo.setText(list.get(position).getNeirongtwo());
		return convertView;
	}

	class VeiwHolderJinWan{
		ImageView img;
		TextView tvbiaoti;
		TextView tvneione;
		TextView tvneitwo;
	}
}
