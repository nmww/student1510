package com.beicai.touping.adapter;

import com.beicai.touping.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SouSuoReCiAdapter extends BaseAdapter {

	private Context context;
	private String[]str;
	
	
	public SouSuoReCiAdapter(Context context, String[] str) {
		super();
		this.context = context;
		this.str = str;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return str.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return str[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		TextView tv;
		if(convertView==null){
			convertView=View.inflate(context, R.layout.sousuo_grid_item, null);
			tv=(TextView) convertView.findViewById(R.id.tv_sousuo_grid_text);
			convertView.setTag(tv);
		}else{
			tv=(TextView) convertView.getTag();
		}
		tv.setText(str[position]);
		return convertView;
	}

}
