package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.ImageTwoTextTwoBean;

public class FenleiListAdapter extends BaseAdapter {

	Context context;
	List<ImageTwoTextTwoBean> list;
	
	public FenleiListAdapter(Context context, List<ImageTwoTextTwoBean> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolderFenLei fenlei;
		if(convertView==null){
			fenlei=new ViewHolderFenLei();
			convertView=View.inflate(context, R.layout.fenlei_listview_item, null);
			fenlei.imgOne=(ImageView) convertView.findViewById(R.id.fenlei_item_title_image);
			fenlei.imgtwo=(ImageView) convertView.findViewById(R.id.fenlei_item_logo);
			fenlei.tvone=(TextView) convertView.findViewById(R.id.fenlei_item_text_title);
			fenlei.tvtwo=(TextView) convertView.findViewById(R.id.fenlei_item_text_but);
			convertView.setTag(fenlei);
		}else{
			fenlei=(ViewHolderFenLei) convertView.getTag();
		}
		fenlei.imgOne.setImageResource(list.get(position).getImageone());
		fenlei.imgtwo.setImageResource(list.get(position).getImagetwo());
		fenlei.tvone.setText(list.get(position).getTextone());
		fenlei.tvtwo.setText(list.get(position).getTexttwo());
		return convertView;
	}
	
	class ViewHolderFenLei{
		ImageView imgOne;
		ImageView imgtwo;
		TextView tvone;
		TextView tvtwo;
	}
}
