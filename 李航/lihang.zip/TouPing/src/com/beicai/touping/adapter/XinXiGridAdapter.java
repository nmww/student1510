package com.beicai.touping.adapter;

import java.util.List;

import com.beicai.touping.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;

public class XinXiGridAdapter extends BaseAdapter {

	Context context;
	List<String> list;
	
	public XinXiGridAdapter(Context context, List<String> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		Button but;
		if(convertView==null){
			convertView=View.inflate(context, R.layout.xinxi_grid_item, null);
			but=(Button) convertView.findViewById(R.id.btn_xinxi_grid_juji);
			convertView.setTag(but);
		}else{
			but = (Button) convertView.getTag();
		}
		but.setText(list.get(position));
		return convertView;
	}

}
