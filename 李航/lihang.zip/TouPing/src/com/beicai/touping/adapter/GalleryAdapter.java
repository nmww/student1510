package com.beicai.touping.adapter;

import com.beicai.touping.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class GalleryAdapter extends BaseAdapter {
	Context context;
	Integer[] imageData;

	public GalleryAdapter(Context con,Integer[] imageData){
		this.context=con;
		this.imageData=imageData;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return imageData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return imageData[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		GalleryHolder ga;
		if(convertView==null){
			ga=new GalleryHolder();
			convertView=View.inflate(context, R.layout.gallery_item, null);
			ga.iv=(ImageView) convertView.findViewById(R.id.gallery_image);
			convertView.setTag(ga);
		}else{
			ga=(GalleryHolder) convertView.getTag();
		}
		ga.iv.setImageResource(imageData[position]);
		return convertView;
	}
class GalleryHolder{
	ImageView iv;
}
}

