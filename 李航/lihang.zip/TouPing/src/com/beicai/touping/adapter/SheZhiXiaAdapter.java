package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.TextTwoBean;

public class SheZhiXiaAdapter extends BaseAdapter {

	Context context;
	List<TextTwoBean> list; 
	
	
	public SheZhiXiaAdapter(Context context, List<TextTwoBean> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final ViewHolderSheZhiXia vh;
		if(convertView==null){
			vh=new ViewHolderSheZhiXia();
			convertView=View.inflate(context, R.layout.shezhi_xia_item, null);
			vh.tvone=(TextView) convertView.findViewById(R.id.tv_shezhi_xia_textmax);
			vh.tvTwo=(TextView) convertView.findViewById(R.id.tv_shezhi_xia_textmin);
			vh.rl=(RelativeLayout) convertView.findViewById(R.id.rl_shezhi_xia_button);
			vh.imageViewon=(ImageView) convertView.findViewById(R.id.on);
			vh.imageViewoff=(ImageView) convertView.findViewById(R.id.off);
			vh.bg=(ImageView) convertView.findViewById(R.id.rl);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolderSheZhiXia) convertView.getTag();
		}
		vh.tvone.setText(list.get(position).getStrone());
		vh.tvTwo.setText(list.get(position).getStrtwo());
		vh.rl.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(vh.imageViewon.getVisibility()==0&&vh.imageViewoff.getVisibility()==8){
					vh.imageViewon.setVisibility(8);
					vh.imageViewoff.setVisibility(0);
		        	vh.bg.setBackgroundResource(R.drawable.setting_switch_bg_off);
		        }else if(vh.imageViewon.getVisibility()==8&&vh.imageViewoff.getVisibility()==0){
		        	vh.imageViewon.setVisibility(0);
		        	vh.imageViewoff.setVisibility(8);
		        	vh.bg.setBackgroundResource(R.drawable.setting_switch_bg_on);
		        }
			}
		});
		return convertView;
	}
class ViewHolderSheZhiXia{
	TextView tvone;
	TextView tvTwo;
	RelativeLayout rl;
	ImageView imageViewon;
	ImageView imageViewoff;
	ImageView bg;
}
}
