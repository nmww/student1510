package com.beicai.touping.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.beicai.touping.R;
import com.beicai.touping.bean.AppXinXiBean;

public class BoFangLiShiAdapter extends BaseAdapter {
	Context context;
	List<AppXinXiBean> list;

	public BoFangLiShiAdapter(Context context, List<AppXinXiBean> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolderLiShi vh;
		if(convertView==null){
			vh=new ViewHolderLiShi();
			convertView=View.inflate(context, R.layout.bofanglishi_gird_item, null);
			vh.img=(ImageView) convertView.findViewById(R.id.bofang_gv_image);
			vh.text=(TextView) convertView.findViewById(R.id.bofang_gv_text);
			convertView.setTag(vh);
		}else{
			vh=(ViewHolderLiShi) convertView.getTag();
		}
		vh.img.setImageResource(list.get(position).getImage());
		vh.text.setText(list.get(position).getText());
		return convertView;
	}
	class ViewHolderLiShi{
		ImageView img;
		TextView text;
	}

}
