package com.bc.kugou;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.bc.kugou.Adapter.KanGalleryAdapter;
import com.bc.kugou.Adapter.KanListAdapter;

public class KanActivity extends Activity implements OnClickListener {

	Integer[] ImageData = new Integer[]{//�ֲ�ͼƬ
			R.drawable.kan_lunbo01,R.drawable.kan_lunbo02,R.drawable.kan_lunbo03,R.drawable.kan_lunbo04,R.drawable.kan_lunbo05
	};
	Gallery gallery;//�ֲ�

	KanGalleryAdapter kanGalleryAdapter;
	int position = 0;
	Handler handler = new Handler(){//ÿ�ε�������ķ���  ����ı�ͼƬ
		public void handleMessage(android.os.Message msg) {
			switch (msg.arg1) {
			case 0:
				if(position < ImageData.length - 1){
					position++;
				}else{
					position = 0;
				}
				gallery.setSelection(position);
				break;

			default:
				break;
			}
		};
	};

	ImageView kanMV;//MV
	ImageView kanFxzb;//����ֱ��
	ImageView kanKgLive;//�ṷLIVE
	
	
	ListView listView;
	ArrayList<Map<String,Object>> lvData;
	KanListAdapter kanListAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.kan_layout);

		gallery = (Gallery) findViewById(R.id.kan_gallery_view);
		kanGalleryAdapter = new KanGalleryAdapter(this, ImageData);
		gallery.setAdapter(kanGalleryAdapter);

		Timer timer = new Timer();
		TimerTask timerTask = new TimerTask() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Message msg = new Message();
				msg.arg1 = 0;
				handler.sendMessage(msg);
			}
		};
		timer.schedule(timerTask, 2000, 2000);//���ü���������һ�η���

		kanMV = (ImageView) findViewById(R.id.kan_mv);//MV
		kanMV.setOnClickListener(this);

		kanFxzb = (ImageView) findViewById(R.id.kan_fxzb);//����ֱ��
		kanFxzb.setOnClickListener(this);

		kanKgLive = (ImageView) findViewById(R.id.kan_kglive);//�ṷLIVE
		kanKgLive.setOnClickListener(this);
		
		
		listView = (ListView) findViewById(R.id.kan_lv_listview);
		getLv();
		kanListAdapter = new KanListAdapter(this, lvData);
		listView.setAdapter(kanListAdapter);
	}
	private void getLv() {
		// TODO Auto-generated method stub
		lvData = new ArrayList<Map<String,Object>>();
		for (int i = 0; i < 3; i++) {
			Map<String,Object> map = new HashMap<String,Object>();
			if(i == 0){
				
				map.put("img", R.drawable.kan_fxmv);
				map.put("txt", "����MV");
				lvData.add(map);
			}else if(i == 1){
				map.put("img", R.drawable.kan_mxzx);
				map.put("txt", "��������");
				lvData.add(map);
			}else if(i == 2){
				map.put("img", R.drawable.kan_xxyc);
				map.put("txt", "�����ݳ�");
				lvData.add(map);
			}
		}
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.kan_mv:
			Toast.makeText(this, "MV", Toast.LENGTH_SHORT).show();
			break;
		case R.id.kan_fxzb:
			Toast.makeText(this, "����ֱ��", Toast.LENGTH_SHORT).show();
			break;
		case R.id.kan_kglive:
			Toast.makeText(this, "�ṷLIVE", Toast.LENGTH_SHORT).show();
			break;
		default:
			break;
		}
	}

}
