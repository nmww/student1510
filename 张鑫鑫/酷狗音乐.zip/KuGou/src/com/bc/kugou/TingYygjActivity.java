package com.bc.kugou;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import com.bc.kugou.Adapter.YygjBottomAdapter;
import com.bc.kugou.Adapter.YygjTopAdapter;

public class TingYygjActivity extends Activity {

	ListView lvTop;
	ArrayList<Map<String,Object>> lvTopData;
	YygjTopAdapter topAdapter;
	
	ListView lvBottom;
	ArrayList<Map<String,Object>> lvBottomData;
	YygjBottomAdapter bottomAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ting_yygj_layout);
		lvTop = (ListView) findViewById(R.id.ting_yyjg_lvtop);
		getTopRes();
		topAdapter = new YygjTopAdapter(this, lvTopData);
		lvTop.setAdapter(topAdapter);
		
		lvBottom = (ListView) findViewById(R.id.ting_yyjg_lvbottom);
		getBottomRes();
		bottomAdapter = new YygjBottomAdapter(this, lvBottomData);
		lvBottom.setAdapter(bottomAdapter);
	}
	private void getTopRes() {
		// TODO Auto-generated method stub
		lvTopData = new ArrayList<Map<String,Object>>();
		for (int i = 0; i < 3; i++) {
			Map<String,Object> map = new HashMap<String,Object>();
			if(i == 0){
				
				map.put("img", R.drawable.yygj_img01);
				map.put("txt", "����ʶ��");
				lvTopData.add(map);
			}else if(i == 1){
				map.put("img", R.drawable.yygj_img02);
				map.put("txt", "���ٴ���");
				lvTopData.add(map);
			}else if(i == 2){
				map.put("img", R.drawable.yygj_img03);
				map.put("txt", "����ɨ��");
				lvTopData.add(map);
			}
		}
	}
	private void getBottomRes() {
		// TODO Auto-generated method stub
		lvBottomData = new ArrayList<Map<String,Object>>();
		for (int i = 0; i < 3; i++) {
			Map<String,Object> map = new HashMap<String,Object>();
			if(i == 0){
				
				map.put("img", R.drawable.yygj_img04);
				map.put("txt", "��������");
				lvBottomData.add(map);
			}else if(i == 1){
				map.put("img", R.drawable.yygj_img05);
				map.put("txt", "�߳�����");
				lvBottomData.add(map);
			}else if(i == 2){
				map.put("img", R.drawable.yygj_img06);
				map.put("txt", "�ܲ���̨");
				lvBottomData.add(map);
			}
		}
	}
}
