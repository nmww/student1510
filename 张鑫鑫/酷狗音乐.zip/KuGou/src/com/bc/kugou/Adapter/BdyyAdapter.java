package com.bc.kugou.Adapter;

import java.util.ArrayList;

import com.bc.kugou.R;
import com.bc.kugou.Entity.BdyyEntity;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class BdyyAdapter extends BaseAdapter {
	Context mContext;
	ArrayList<BdyyEntity> resData;
	
	public BdyyAdapter(Context mContext, ArrayList<BdyyEntity> resData) {
		super();
		this.mContext = mContext;
		this.resData = resData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return resData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return resData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	class ViewHolder{
		TextView tvgm;
		TextView tvgs;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if(convertView == null){
			vh = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.ting_bdyy_lv_item, null);
			vh.tvgm = (TextView) convertView.findViewById(R.id.bdyy_gm);
			vh.tvgs = (TextView) convertView.findViewById(R.id.bdyy_gs);
			convertView.setTag(vh);
		}else{
			vh = (ViewHolder) convertView.getTag();
		}
		vh.tvgm.setText(resData.get(position).getMusic());
		vh.tvgs.setText(resData.get(position).getName());
		return convertView;
	}

}
