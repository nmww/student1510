package com.bc.kugou.Adapter;

import com.bc.kugou.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;

public class GdExpandLvAdapter extends BaseExpandableListAdapter {
	
	Context mContext;
	Integer[] GroupData;
	Integer[][] ChildData;

	public GdExpandLvAdapter(Context mContext, Integer[] groupData,
			Integer[][] childs) {
		super();
		this.mContext = mContext;
		GroupData = groupData;
		ChildData = childs;
	}

	@Override
	public int getGroupCount() {
		// TODO Auto-generated method stub
		return GroupData.length;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		// TODO Auto-generated method stub
		return ChildData[groupPosition].length;
	}

	@Override
	public Object getGroup(int groupPosition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return false;
	}
	class GroupViewHolder{
		ImageView imgGedan;
	}
	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		GroupViewHolder gvh = null;
		if(convertView == null){
			gvh = new GroupViewHolder();
			convertView = View.inflate(mContext, R.layout.gd_group_ietm, null);
			gvh.imgGedan = (ImageView) convertView.findViewById(R.id.gd_iv_group);
			convertView.setTag(gvh);
		}else{
			gvh = (GroupViewHolder) convertView.getTag();
		}
		gvh.imgGedan.setImageResource(GroupData[groupPosition]);
		// TODO Auto-generated method stub
		return convertView;
	}

	class ChildViewHolder{
		ImageView ImgLeft;
	}
	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		ChildViewHolder cvh = null;
		if(convertView == null){
			cvh = new ChildViewHolder();
			convertView = View.inflate(mContext, R.layout.gd_child_item, null);
			cvh.ImgLeft = (ImageView) convertView.findViewById(R.id.gd_ivleft_child);
			convertView.setTag(cvh);
		}else {
			cvh = (ChildViewHolder) convertView.getTag();
		}
		cvh.ImgLeft.setImageResource(ChildData[groupPosition][childPosition]);
		// TODO Auto-generated method stub
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
