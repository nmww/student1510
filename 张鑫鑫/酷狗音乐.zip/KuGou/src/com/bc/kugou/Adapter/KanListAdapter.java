package com.bc.kugou.Adapter;

import java.util.ArrayList;
import java.util.Map;

import com.bc.kugou.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class KanListAdapter extends BaseAdapter{

	Context mContext;
	ArrayList<Map<String,Object>> lvData;

	public KanListAdapter(Context mContext,ArrayList<Map<String, Object>> lvData) {
		super();
		this.mContext = mContext;
		this.lvData = lvData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lvData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lvData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if(convertView == null){
			vh = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.kan_listview_item, null);
			vh.imgView = (ImageView) convertView.findViewById(R.id.kan_iv_left);
			vh.txtView = (TextView) convertView.findViewById(R.id.kan_tv_left);
			convertView.setTag(vh);
		}else{
			vh = (ViewHolder) convertView.getTag();
		}
		vh.imgView.setImageResource((Integer) lvData.get(position).get("img"));
		vh.txtView.setText((CharSequence) lvData.get(position).get("txt"));
		return convertView;
	}

	class ViewHolder{
		ImageView imgView;
		TextView txtView;
	}

}
