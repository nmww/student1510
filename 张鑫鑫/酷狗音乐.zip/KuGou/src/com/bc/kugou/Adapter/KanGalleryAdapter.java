package com.bc.kugou.Adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.bc.kugou.R;

public class KanGalleryAdapter extends BaseAdapter {

	Context mContext;
	Integer[] ImageData;
	
	public KanGalleryAdapter(Context mContext, Integer[] imageData) {
		super();
		this.mContext = mContext;
		ImageData = imageData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return ImageData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return ImageData[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if(convertView == null){
			vh = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.kan_gallery_item, null);
			vh.imageView = (ImageView) convertView.findViewById(R.id.kan_iv_image);
			convertView.setTag(vh);
		}else{
			vh = (ViewHolder) convertView.getTag();
		}
		vh.imageView.setImageResource(ImageData[position]);
		return convertView;
	}
	
	class ViewHolder{
		ImageView imageView;
	}

}
