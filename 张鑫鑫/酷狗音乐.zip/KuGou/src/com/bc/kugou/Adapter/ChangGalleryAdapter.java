package com.bc.kugou.Adapter;

import com.bc.kugou.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ChangGalleryAdapter extends BaseAdapter {

	Context mContext;
	Integer[] ImgData;
	
	public ChangGalleryAdapter(Context mContext, Integer[] imgData) {
		super();
		this.mContext = mContext;
		ImgData = imgData;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return ImgData.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return ImgData[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	class ViewHolder{
		ImageView imageView;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if(convertView == null){
			vh = new ViewHolder();
			convertView = View.inflate(mContext, R.layout.chang_gallery_item, null);
			vh.imageView = (ImageView) convertView.findViewById(R.id.chang_iv_image);
			convertView.setTag(vh);
		}else{
			vh = (ViewHolder) convertView.getTag();
		}
		vh.imageView.setImageResource(ImgData[position]);
		return convertView;
	}

}
