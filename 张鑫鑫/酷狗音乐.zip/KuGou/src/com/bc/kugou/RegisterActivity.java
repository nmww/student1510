package com.bc.kugou;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	
	EditText zcZh;//ע���˺�
	EditText zcMm;//ע������
	Button zcBtn;//ע�ᰴť
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zc_layout);
		zcZh = (EditText) findViewById(R.id.zc_et_name);
		zcMm = (EditText) findViewById(R.id.zc_et_pass);
		zcBtn = (Button) findViewById(R.id.zc_btn);
		zcBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String name=zcZh.getText().toString();
				Toast.makeText(getApplication(), "��ע����˺��ǣ�"+name, Toast.LENGTH_SHORT).show();
			}
		});
	}
}
