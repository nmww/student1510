package com.bc.kugou;

import java.util.Timer;
import java.util.TimerTask;

import com.bc.kugou.Adapter.ChangGalleryAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.Toast;

public class ChangActivity extends Activity implements OnClickListener {

	Integer[] ImageData = new Integer[]{//�ֲ�ͼƬ
			R.drawable.chang_lunbo01,R.drawable.chang_lunbo02,R.drawable.chang_lunbo03,R.drawable.chang_lunbo04,R.drawable.chang_lunbo05
	};
	Gallery gallery;//�ֲ�
	ChangGalleryAdapter changGalleryAdapter;

	int position = 0;
	Handler handler = new Handler(){//ÿ�ε�������ķ���  ����ı�ͼƬ
		public void handleMessage(android.os.Message msg) {
			switch (msg.arg1) {
			case 0:
				if(position < ImageData.length - 1){
					position++;
				}else{
					position = 0;
				}
				gallery.setSelection(position);
				break;

			default:
				break;
			}
		};
	};

	ImageView imgFj;//����
	ImageView imgPh;//����
	ImageView imgGz;//��ע
	ImageView imgWd;//�ҵ�
	ImageView imgDs;//����
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chang_layout);
		gallery = (Gallery) findViewById(R.id.chang_gallery_view);
		changGalleryAdapter = new ChangGalleryAdapter(this, ImageData);
		gallery.setAdapter(changGalleryAdapter);

		Timer timer = new Timer();
		TimerTask timerTask = new TimerTask() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Message msg = new Message();
				msg.arg1 = 0;
				handler.sendMessage(msg);
			}
		};
		timer.schedule(timerTask, 2000, 2000);//���ü���������һ�η���

		imgFj = (ImageView) findViewById(R.id.chang_lefttop);//����
		imgFj.setOnClickListener(this);

		imgPh = (ImageView) findViewById(R.id.chang_righttop);//����
		imgPh.setOnClickListener(this);

		imgGz = (ImageView) findViewById(R.id.chang_leftbottom);//��ע
		imgGz.setOnClickListener(this);

		imgWd = (ImageView) findViewById(R.id.chang_rightbottom);//�ҵ�
		imgWd.setOnClickListener(this);

		imgDs = (ImageView) findViewById(R.id.chang_dashai);//����
		imgDs.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.chang_lefttop://����
			Toast.makeText(this, "����", Toast.LENGTH_SHORT).show();
			break;
		case R.id.chang_righttop://����
			Toast.makeText(this, "����", Toast.LENGTH_SHORT).show();
			break;
		case R.id.chang_leftbottom://��ע
			Toast.makeText(this, "��ע", Toast.LENGTH_SHORT).show();
			break;
		case R.id.chang_rightbottom://�ҵ�
			Toast.makeText(this, "�ҵ�", Toast.LENGTH_SHORT).show();
			break;
		case R.id.chang_dashai://����
			Toast.makeText(this, "����", Toast.LENGTH_SHORT).show();
			break;
		default:
			break;
		}
	}
}
