package com.bc.kugou;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class MainActivity extends ActivityGroup {

	TabHost myTabHost;//��ҳTabHost
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_host_layout);
		
		myTabHost = (TabHost) findViewById(R.id.my_host_main);
		myTabHost.setup();
		
		
		TabSpec tabSpecTing = myTabHost.newTabSpec("��");
		tabSpecTing.setIndicator("��");
		Intent intentTing = new Intent(this,TingActivity.class);
		intentTing.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View tingView = this.getLocalActivityManager().startActivity("1", intentTing).getDecorView();
		LinearLayout TingLayout =  (LinearLayout) findViewById(R.id.layout_ting);
		TingLayout.removeAllViews();
		TingLayout.addView(tingView);
		tabSpecTing.setContent(R.id.layout_ting);
		myTabHost.addTab(tabSpecTing);
		
		
		
		TabSpec tabSpecKan = myTabHost.newTabSpec("��");
		tabSpecKan.setIndicator("��");
		Intent intentKan = new Intent(this,KanActivity.class);
		intentKan.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View kanView = this.getLocalActivityManager().startActivity("1", intentKan).getDecorView();
		LinearLayout kanLayout =  (LinearLayout) findViewById(R.id.layout_kan);
		kanLayout.removeAllViews();
		kanLayout.addView(kanView);
		tabSpecKan.setContent(R.id.layout_kan);
		myTabHost.addTab(tabSpecKan);
		
		
		TabSpec tabSpecChang = myTabHost.newTabSpec("��");
		tabSpecChang.setIndicator("��");
		Intent intentChang = new Intent(this,ChangActivity.class);
		intentChang.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View ChangView = this.getLocalActivityManager().startActivity("1", intentChang).getDecorView();
		LinearLayout ChangLayout =  (LinearLayout) findViewById(R.id.layout_chang);
		ChangLayout.removeAllViews();
		ChangLayout.addView(ChangView);
		tabSpecChang.setContent(R.id.layout_chang);
		myTabHost.addTab(tabSpecChang);
		
	}

}
