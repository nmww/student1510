package com.bc.kugou;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class TingActivity extends Activity implements OnClickListener {

	ImageView imgWxh;//��ϲ��

	ImageView imgGd;//�赥
	
	ImageView imgXz;//����
	
	ImageView imgZj;//���
	
	ImageView imgBdyy;//��������
	
	ImageView imgLk;//�ֿ�
	
	ImageView imgDt;//��̨
	
	ImageView imgKq;//��Ⱥ
	
	ImageView imgYygj;//���ֹ���
	
	ImageView imgYx;//��Ϸ
	
	ImageView imgSc;//�̳�
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ting_layout);

		imgWxh = (ImageView) findViewById(R.id.ting_img_wxh);//��ϲ��
		imgWxh.setOnClickListener(this);

		imgGd = (ImageView) findViewById(R.id.ting_img_gd);//�赥
		imgGd.setOnClickListener(this);
		
		imgXz = (ImageView) findViewById(R.id.ting_img_xz);//����
		imgXz.setOnClickListener(this);
		
		imgZj = (ImageView) findViewById(R.id.ting_img_zj);//���
		imgZj.setOnClickListener(this);
		
		imgBdyy = (ImageView) findViewById(R.id.ting_img_bdyy);//��������
		imgBdyy.setOnClickListener(this);
		
		imgLk = (ImageView) findViewById(R.id.ting_img_lk);//�ֿ�
		imgLk.setOnClickListener(this);
		
		imgDt = (ImageView) findViewById(R.id.ting_img_dt);//��̨
		imgDt.setOnClickListener(this);
		
		imgKq = (ImageView) findViewById(R.id.ting_img_kq);//��Ⱥ
		imgKq.setOnClickListener(this);
		
		imgYygj = (ImageView) findViewById(R.id.ting_img_yygj);//���ֹ���
		imgYygj.setOnClickListener(this);
		
		imgYx = (ImageView) findViewById(R.id.ting_img_yx);//��Ϸ
		imgYx.setOnClickListener(this);
		
		imgSc = (ImageView) findViewById(R.id.ting_img_sc);//�̳�
		imgSc.setOnClickListener(this);
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.ting_img_wxh://��ϲ��
			startActivity(new Intent(TingActivity.this, TingTabActivity.class));
			break;
		case R.id.ting_img_gd://�赥
			startActivity(new Intent(TingActivity.this, TingGdActivity.class));
			break;
		case R.id.ting_img_xz://����
			Toast.makeText(getApplication(), "����", Toast.LENGTH_SHORT).show();
			break;
		case R.id.ting_img_zj://���
			startActivity(new Intent(TingActivity.this, TingZjbfActivity.class));
			break;
		case R.id.ting_img_bdyy://��������
			startActivity(new Intent(TingActivity.this, TingBdyyActivity.class));
			break;
		case R.id.ting_img_lk://�ֿ�
			Toast.makeText(getApplication(), "�ֿ�", Toast.LENGTH_SHORT).show();
			break;
		case R.id.ting_img_dt://��̨
			Toast.makeText(getApplication(), "��̨", Toast.LENGTH_SHORT).show();
			break;
		case R.id.ting_img_kq://��Ⱥ
			Toast.makeText(getApplication(), "��Ⱥ", Toast.LENGTH_SHORT).show();
			break;
		case R.id.ting_img_yygj://���ֹ���
			startActivity(new Intent(TingActivity.this, TingYygjActivity.class));
			break;
		case R.id.ting_img_yx://��Ϸ
			Toast.makeText(getApplication(), "��Ϸ", Toast.LENGTH_SHORT).show();
			break;
		case R.id.ting_img_sc://�̳�
			Toast.makeText(getApplication(), "�̳�", Toast.LENGTH_SHORT).show();
			break;
		default:
			break;
		}

	}
}
