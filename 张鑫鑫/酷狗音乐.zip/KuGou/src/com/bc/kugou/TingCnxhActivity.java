package com.bc.kugou;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;

public class TingCnxhActivity extends Activity implements OnClickListener {

	ImageView tingCnxh;
	PopupWindow popuWindow;

	Button btnQd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ting_cnxh_layout);
		initView();
		initPopWindow();
	}

	private void initView() {
		// TODO Auto-generated method stub
		tingCnxh = (ImageView) findViewById(R.id.ting_cnxh_img);
		tingCnxh.setOnClickListener(this);
	}

	private void initPopWindow() {
		// TODO Auto-generated method stub
		if (popuWindow == null) {
			getPopuW();// �õ�window����
		} else {
			popuWindow.dismiss();// ��ʧ
		}
	}

	private void getPopuW() {
		// TODO Auto-generated method stub
		View pView = View.inflate(TingCnxhActivity.this,
				R.layout.cnxh_popu_layout, null);
		btnQd = (Button) pView.findViewById(R.id.popu_btn);
		btnQd.setOnClickListener(this);
		popuWindow = new PopupWindow(pView,400,180);
		popuWindow.setFocusable(true);//���Ի�ý���
		popuWindow.setBackgroundDrawable(new BitmapDrawable());//�������֮�������ʧ
		popuWindow.setOutsideTouchable(true);//������Դ���
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.ting_cnxh_img:
			popuWindow.showAtLocation(v, Gravity.CENTER, 0, 0);
			break;
		case R.id.popu_btn:
			popuWindow.dismiss();
			break;
		default:
			break;
		}

	}
}
