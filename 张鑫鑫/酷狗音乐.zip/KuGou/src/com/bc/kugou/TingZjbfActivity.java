package com.bc.kugou;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class TingZjbfActivity extends Activity implements OnClickListener {
	private DrawerLayout mDrawerLayout = null;
	ImageView grWifi,grZmgc,grSpgc;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.ting_zjbf_layout);
		setContentView(R.layout.drawer_layout);
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		Button button = (Button) findViewById(R.id.btn);
		button.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v)
			{
				// ��ť���£��������
				mDrawerLayout.openDrawer(Gravity.LEFT);
			}
		});
		grWifi = (ImageView) findViewById(R.id.gr_select1);
		grWifi.setOnClickListener(this);
		grZmgc = (ImageView) findViewById(R.id.gr_select2);
		grZmgc.setOnClickListener(this);
		grSpgc = (ImageView) findViewById(R.id.gr_select3);
		grSpgc.setOnClickListener(this);
	}
	int q=0;
	int w=0;
	int e=0;
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.gr_select1:
			if(q==0){
				grWifi.setBackgroundResource(R.drawable.gr_close);
				q++;
			}else{
				q=0;
				grWifi.setBackgroundResource(R.drawable.gr_open);
			}
			break;
		case R.id.gr_select2:
			if(w==0){
				w++;
				grZmgc.setBackgroundResource(R.drawable.gr_close);
			}else{
				w=0;
				grZmgc.setBackgroundResource(R.drawable.gr_open);
			}
			break;
		case R.id.gr_select3:
			if(e==0){
				e++;
				grSpgc.setBackgroundResource(R.drawable.gr_open);
			}else{
				e=0;
				grSpgc.setBackgroundResource(R.drawable.gr_close);
			}
			break;
		default:
			break;
		}
	}

}
