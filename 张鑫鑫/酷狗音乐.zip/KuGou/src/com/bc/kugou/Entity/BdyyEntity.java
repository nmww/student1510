package com.bc.kugou.Entity;

public class BdyyEntity {
	private String music;//����
	private String name;//�質��
	
	public String getMusic() {
		return music;
	}
	public void setMisic(String music) {
		this.music = music;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
