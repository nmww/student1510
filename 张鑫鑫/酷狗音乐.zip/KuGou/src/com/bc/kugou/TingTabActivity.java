package com.bc.kugou;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class TingTabActivity extends ActivityGroup implements OnClickListener {

	TabHost tingWxhTab;
	ImageButton btnDl;//登录
	ImageView imgYy;//音乐
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ting_wxh_tab);

		tingWxhTab = (TabHost) findViewById(R.id.wxh_tab_host);
		tingWxhTab.setup();

		TabSpec tabSpecWxh = tingWxhTab.newTabSpec("我喜欢");
		tabSpecWxh.setIndicator("我喜欢");
		Intent intentWxh = new Intent(TingTabActivity.this,TingWxhActivity.class);
		intentWxh.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View WxhView = this.getLocalActivityManager().startActivity("1", intentWxh).getDecorView();
		LinearLayout WxhLayout =  (LinearLayout) findViewById(R.id.ting_wxh);
		WxhLayout.removeAllViews();
		WxhLayout.addView(WxhView);
		tabSpecWxh.setContent(R.id.ting_wxh);
		tingWxhTab.addTab(tabSpecWxh);

		TabSpec tabSpecCnxh = tingWxhTab.newTabSpec("猜你喜欢");
		tabSpecCnxh.setIndicator("猜你喜欢");
		Intent intentCnxh = new Intent(TingTabActivity.this,TingCnxhActivity.class);
		intentCnxh.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		View CnxhView = this.getLocalActivityManager().startActivity("1", intentCnxh).getDecorView();
		LinearLayout CnxhLayout =  (LinearLayout) findViewById(R.id.ting_cnxh);
		CnxhLayout.removeAllViews();
		CnxhLayout.addView(CnxhView);
		tabSpecCnxh.setContent(R.id.ting_cnxh);
		tingWxhTab.addTab(tabSpecCnxh);

		btnDl = (ImageButton) findViewById(R.id.ting_btndl);//登录
		btnDl.setOnClickListener(this);

		imgYy = (ImageView) findViewById(R.id.tab_ting_img);//音乐
		imgYy.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.ting_btndl://登录 点击 跳转到登录页面
			startActivity(new Intent(TingTabActivity.this, LoginActivity.class));
			break;
		case R.id.tab_ting_img://音乐  点击 跳转到音乐页面
			
			break;
		default:
			break;
		}
	}
}
