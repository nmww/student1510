package com.bc.kugou;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.Toast;

import com.bc.kugou.Adapter.GdExpandLvAdapter;

public class TingGdActivity extends Activity {

	ExpandableListView expandListView;
	GdExpandLvAdapter gdExpandLvAdapter;
	Integer[] Groups={R.drawable.ting_gdimg_group};
	Integer[][] Childs={{R.drawable.ting_gdivleft_child}};

	ImageButton gdDl;
	Button xjBtn;
	AlertDialog.Builder dialog;
	EditText xjName;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ting_gd_layout);
		expandListView = (ExpandableListView) findViewById(R.id.ting_gd_expandlv);
		gdExpandLvAdapter = new GdExpandLvAdapter(this, Groups, Childs);
		expandListView.setAdapter(gdExpandLvAdapter);

		gdDl = (ImageButton) findViewById(R.id.ting_btndl);
		gdDl.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(TingGdActivity.this, LoginActivity.class));
			}
		});
		xjBtn = (Button) findViewById(R.id.ting_xjgd_btn);
		xjBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog = new AlertDialog.Builder(TingGdActivity.this);
				dialog.setTitle("�½��赥");
				View dialogView = View.inflate(TingGdActivity.this, R.layout.gd_self_dailog, null);
				xjName = (EditText) dialogView.findViewById(R.id.gd_self_txt);
				dialog.setView(dialogView);
				dialog.setNegativeButton("ȡ��",new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
				dialog.setPositiveButton("ȷ��", new OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						String txtName = xjName.getText().toString();
						Toast.makeText(TingGdActivity.this,"�½��赥:"+txtName, Toast.LENGTH_SHORT).show();
						dialog.dismiss();
					}
				});
				dialog.create();
				dialog.show();
			}
		});
	}
}
