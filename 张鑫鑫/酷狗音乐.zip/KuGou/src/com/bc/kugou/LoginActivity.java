package com.bc.kugou;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnClickListener {

	EditText dlZh;//��¼�˺�
	EditText dlMm;//��¼����
	Button dlBtn;//��¼��ť
	TextView tvZc;//ע��ҳ�����ת
	ImageView dlWb;//΢����¼
	ImageView dlQq;//QQ��¼
	ImageView dlWx;//΢�ŵ�¼
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dl_layout);
		dlZh = (EditText) findViewById(R.id.dl_et_name);
		dlMm = (EditText) findViewById(R.id.dl_et_pass);
		dlBtn = (Button) findViewById(R.id.dl_btn);
		dlBtn.setOnClickListener(this);
		tvZc = (TextView) findViewById(R.id.tv_zc);
		tvZc.setOnClickListener(this);
		dlWb = (ImageView) findViewById(R.id.dl_wb);
		dlWb.setOnClickListener(this);
		dlQq = (ImageView) findViewById(R.id.dl_qq);
		dlQq.setOnClickListener(this);
		dlWx = (ImageView) findViewById(R.id.dl_wx);
		dlWx.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.dl_btn:
			String name=dlZh.getText().toString();
			Toast.makeText(this, "��ĵ�¼�˺��ǣ�"+name, Toast.LENGTH_SHORT).show();
			break;
		case R.id.tv_zc:
			startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
			break;
		case R.id.dl_wb:
			Toast.makeText(this, "΢����¼", Toast.LENGTH_SHORT).show();
			break;
		case R.id.dl_qq:
			Toast.makeText(this, "QQ��¼", Toast.LENGTH_SHORT).show();
			break;
		case R.id.dl_wx:
			Toast.makeText(this, "΢�ŵ�¼", Toast.LENGTH_SHORT).show();
			break;
		default:
			break;
		}

	}

}
